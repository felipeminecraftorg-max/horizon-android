Transcoded from the user-supplied Glass Lab 7.0 pack for the native Horizon Vorbis decoder. Original pack preserved separately.
