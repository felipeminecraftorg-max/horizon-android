#version 300 es
precision highp float;
out vec4 fragColor;
uniform sampler2D uImage;
uniform vec2 uRes;
uniform int uCount;
uniform vec4 uParts[4]; // centre.xy and halfExtent.zw in framebuffer pixels (bottom-left origin)
uniform vec4 uMeta[4];  // cornerRadius, opticalFactor, opacity, unused
uniform vec4 uFill[4];  // selective material pigmentation + opacity
uniform vec4 uDynamics[4]; // trailing gel.xy, press depth.z, reserved.w
uniform int uStyle;         // 0: liquid dielectric, 1: retro satin/chrome
uniform vec2 uLight;
uniform float uElevation;
uniform float uStrength;
uniform float uRoll;
uniform float uChroma;
uniform float uBlur;
uniform float uShine;
uniform float uDepth;
uniform float uFresnel;
uniform float uGloss;
uniform float uBloom;
uniform float uSpill;
uniform float uTint;
uniform float uShadow;
uniform float uCompare;
// Independent console shader uniforms: four physical surface families.
uniform int uRetroFinish; // 0: graphite satin, 1: PS3 pearl, 2: translucent aero, 3: brushed chrome
uniform float uRetroMetal;
uniform float uRetroGrain;
uniform float uRetroAero;
uniform float uRetroChrome;
uniform float uRetroEdge;
uniform float uRetroAccent;
uniform float uTime;
vec3 sampleScene(vec2 xy){
  return texture(uImage, clamp(xy/uRes, vec2(.001), vec2(.999))).rgb;
}
vec2 normalFor(vec2 loc,vec2 halfSize,float radius){
  vec2 q=abs(loc)-halfSize+vec2(radius);
  vec2 ext=max(q,vec2(0.));
  if(length(ext)>.0001) return normalize(ext)*sign(loc);
  if(q.x>q.y) return vec2(sign(loc.x),0.);
  return vec2(0.,sign(loc.y));
}

// Dark Aero / 2006–2012 console lacquer: physical screen-space fake-3D.
// Actual per-fragment normals, Snell transmission, GGX metallic reflectance,
// analytic studio stripboxes and environment probes from the live backdrop.
float ggxDistribution(float nDotH,float rough){
  float a=rough*rough;float a2=a*a;
  float den=nDotH*nDotH*(a2-1.)+1.;
  return a2/max(3.14159265*den*den,.00008);
}
vec3 shadeConsole(int finish,vec2 pos,vec2 loc,vec2 outward,vec2 halfSize,
                  float radius,float depth,float press,float tailEnergy,
                  vec4 fillColor,vec3 sceneColor){
  // A thin physically curved face, followed by a flat, polished central slab.
  float roll=max(1.2,min(radius*.98,uRoll*(.48+uRetroEdge*.45)));
  float slope=pow(clamp(1.-depth/roll,0.,1.),.72);
  float front=sqrt(max(1.-slope*slope,.0005));
  float polarity=sign(uDepth);
  vec3 N=normalize(vec3(outward*slope*polarity,front));
  vec3 V=vec3(0.,0.,1.);
  vec3 L=normalize(vec3(uLight,max(.25,uElevation)));
  vec3 H=normalize(L+V);
  float nv=max(dot(N,V),.003);
  float nl=max(dot(N,L),.002);
  float nh=max(dot(N,H),0.);
  float metallic=clamp(uRetroMetal,0.,1.);
  float chrome=clamp(uRetroChrome,0.,1.);
  float aero=clamp(uRetroAero,0.,1.);
  float edge=exp(-depth/max(1.2,roll*.11));
  float inner=exp(-pow((depth-roll*.64)/max(1.,roll*.17),2.));
  // Tiny normal-angle anisotropy from real microgrooves (brushed steel only).
  float grain=sin(pos.y*.77+sin(pos.x*.12)*.14)*.58
       +sin(pos.y*2.21+pos.x*.013)*.20;
  float brush=(finish==3?uRetroGrain:0.)*grain;
  N=normalize(N+vec3(0.,brush*.085,0.));
  float rough=clamp(mix(.40,.085,uGloss)+uRetroGrain*.08,.06,.48);
  float D=ggxDistribution(max(dot(N,H),0.),rough);
  float k=rough*rough*.5;
  float geometry=(nv/(nv*(1.-k)+k))*(nl/(nl*(1.-k)+k));
  float GGX=clamp(D*geometry/max(4.*nv,.01),0.,15.);
  // Black lacquer is genuinely near-black; reflectance and white ribbons,
  // not an opaque dull gray tint, define its perceived three-dimensionality.
  vec3 base=vec3(.010,.012,.019);
  vec3 F0=vec3(.034);
  float transmit=.065;
  if(finish==1){base=vec3(.080,.089,.108);F0=vec3(.24,.25,.29);transmit=.16;}
  if(finish==2){base=vec3(.024,.037,.049);F0=vec3(.039);transmit=.72;}
  if(finish==3){base=vec3(.068,.072,.081);F0=vec3(.42,.43,.46);transmit=.035;}
  vec3 F=F0+(vec3(1.)-F0)*pow(1.-nv,5.);
  vec3 T=refract(vec3(0.,0.,-1.),N,1./(finish==2?1.49:1.55));
  float thick=(2.8+roll*.91)*(.42+abs(uDepth));
  vec2 displacement=T.xy/max(-T.z,.16)*thick*uStrength*.93;
  float maxOffset=min(min(halfSize.x,halfSize.y)*.58,45.);
  displacement*=min(1.,maxOffset/max(length(displacement),.001));
  vec3 transmitted=sampleScene(pos+displacement);
  vec3 reflectedRay=reflect(vec3(0.,0.,-1.),N);
  vec2 reflectOffset=reflectedRay.xy*(17.+roll*.76);
  vec3 backdropReflection=sampleScene(pos+reflectOffset);
  // Analytic white strip-softboxes in the material's environment. They follow
  // the *surface normal* and directed light, not static painted strokes.
  vec3 studioA=normalize(vec3(-.75,.34,1.35));
  vec3 studioB=normalize(vec3(.64,-.37,1.07));
  vec3 halfA=normalize(studioA+V);
  vec3 halfB=normalize(studioB+V);
  float stripA=pow(max(dot(N,halfA),0.),mix(16.,97.,uGloss));
  float stripB=pow(max(dot(N,halfB),0.),mix(22.,140.,uGloss));
  // Wide reflection sweep across convex top, brightest on rolled chrome edges.
  float arc=pow(max(dot(outward,normalize(vec2(-.70,.71))),0.),4.);
  float verticalBand=pow(max(1.-abs(N.y+.10)*1.14,0.),13.);
  float horizontalBand=pow(max(1.-abs(N.x-.17)*1.22,0.),17.);
  float studio=clamp(stripA*.64+stripB*.57+verticalBand*.18+horizontalBand*.14,0.,1.);
  // Hollow-looking edge for a rounded embossed fake-3D physical surface.
  float rimKey=pow(max(dot(outward,normalize(vec2(-.74,-.67))),0.),7.);
  float rimFill=pow(max(dot(outward,normalize(vec2(.68,.72))),0.),11.);
  float rimGlow=(rimKey*.65+rimFill*.36)*edge;
  float insideShade=(1.-front)*.19+inner*.12*(1.-rimKey);
  // Real anisotropic microfacet + Fresnel, with a monochrome cold studio light.
  vec3 microSpec=F*GGX*min(1.2,uShine)*(.31+.35*chrome);
  vec3 env=mix(vec3(.10,.13,.18),backdropReflection,.70);
  float reflectWeight=clamp(.25+.56*chrome+.23*metallic,0.,.97);
  vec3 reflected=env*reflectWeight*F;
  vec3 col=mix(base,transmitted,transmit);
  if(finish==2){
    // Aero acrylic is genuinely refractive and stays transparent at its centre.
    col=mix(transmitted,vec3(.09,.12,.16),.10+uTint*.12);
    reflected*=.69;
  }else{
    col+=reflected*.95;
    col+=backdropReflection*(.10+.15*chrome)*max(nv,.10);
  }
  col*=1.-insideShade;
  col+=microSpec;
  col+=vec3(.98,.985,1.)*studio*(.13+.56*chrome)*uShine;
  col+=vec3(.92,.95,1.)*(rimGlow*(.16+.51*uRetroEdge)+inner*.065);
  // Chrome is nearly black at the bottom and gleaming on upper edge.
  col+=vec3(.34,.37,.41)*verticalBand*.12*chrome;
  col+=vec3(.17,.21,.27)*brush*(finish==3?.08:0.);
  // Optional green/cyan instrumentation reflection (Xbox-era nod), not neon.
  vec3 accent=vec3(.13,.62,.32)*uRetroAccent;
  col+=accent*(rimFill*edge*.28+inner*.09);
  // Press changes shape and reflective slope; focus feedback is restrained.
  col*=1.-press*.13;
  col+=vec3(.84,.90,.98)*clamp(tailEnergy,0.,1.)*.031*edge;
  if(fillColor.a>0.){
    float tintFactor=fillColor.a*(finish==2?.36:.30);
    col=mix(col,fillColor.rgb,tintFactor);
  }
  return clamp(col,vec3(0.),vec3(1.));
}

void main(){
  vec2 pos=gl_FragCoord.xy;
  vec3 src=sampleScene(pos);
  // Keep scene detail; the retro shader itself supplies true optical material.
  if(uCompare>.5){fragColor=vec4(src,1.);return;}
  vec3 accum=src;
  for(int i=0;i<4;i++){
    if(i>=uCount)break;
    vec2 center=uParts[i].xy;
    vec2 halfSize=max(uParts[i].zw,vec2(1.));
    float press=clamp(uDynamics[i].z,0.,1.);
    halfSize*=vec2(1.-press*.035,1.-press*.082);
    float radius=clamp(uMeta[i].x,.5,min(halfSize.x,halfSize.y));
    vec2 loc=pos-center;
    // Directional gel, not a symmetric squish: only the trailing half moves.
    // Positive drag along +X extends the left wall, preserving the leading edge.
    vec2 tail=uDynamics[i].xy;
    float tailLength=length(tail);
    if(tailLength>.01){
      vec2 direction=tail/max(tailLength,.001);
      float back=clamp(-dot(loc,direction)/max(dot(halfSize,abs(direction)),1.),0.,1.);
      loc+=tail*pow(back,1.25);
    }
    vec2 q=abs(loc)-halfSize+vec2(radius);
    float d=length(max(q,vec2(0.)))+min(max(q.x,q.y),0.)-radius;
    if(d>34.) continue;
    float aa=max(fwidth(d),.90);
    float mask=1.-smoothstep(-aa,aa,d);
    vec2 outward=normalFor(loc,halfSize,radius);
    float strength=uStrength*uMeta[i].y;
    float haloR=7.+uBloom*13.;
    float shade=max(d,0.);
    float keyAngle=max(dot(outward,uLight),0.);
    float fillAngle=max(dot(outward,-uLight),0.);
    float glow=exp(-pow(shade/max(haloR,.5),2.))*pow(keyAngle,8.)*(uBloom*.24);
    float shadow=exp(-shade/9.)*.29*uShadow*(1.-smoothstep(18.,33.,shade));
    if(mask<.001){
      accum=clamp(accum*(1.-shadow)+vec3(.68,.87,1.)*glow,0.,1.);
      continue;
    }
    float depth=max(-d,0.);
    if(uStyle==1){
      float energy=length(tail)/max(length(halfSize),1.)+uDynamics[i].w*.30;
      // Explicitly solid brushed-metal thumb without changing its translucent track.
      int effectiveFinish=uMeta[i].w>.5?3:uRetroFinish;
      vec3 retro=shadeConsole(effectiveFinish,pos,loc,outward,halfSize,radius,depth,press,
        energy,uFill[i],src);
      // Microfacet metal and acrylic are shaded physically, then composited
      // with the real backdrop. No faux frosted color layer.
      float opacity=clamp(uMeta[i].z*(effectiveFinish==2?.83:1.),0.,1.);
      accum=mix(accum,retro,mask*opacity);
      float contact=exp(-max(d,0.)/7.)*.18*uShadow;
      accum*=1.-contact*(1.-mask);
      accum+=vec3(.76,.82,.90)*glow*(1.-mask)*.44;
      continue;
    }
    float roll=max(1.,min(radius*.98,uRoll));
    float curved=pow(clamp(1.-depth/roll,0.,1.),.71);
    float front=sqrt(max(1.-curved*curved,.0007));
    // Concave presets reverse the lateral surface normal and ray deflection.
    float polarity=abs(uDepth)<.008 ? 0. : sign(uDepth);
    vec3 surfaceNormal=normalize(vec3(outward*curved*polarity,front));
    vec3 ray=refract(vec3(0.,0.,-1.),surfaceNormal,1./1.48);
    float signedDepth=abs(uDepth);
    float medium=(roll*.64+4.)*(.38+signedDepth*.96);
    vec2 bend=ray.xy/max(-ray.z,.16)*medium*strength;
    bend-=loc/max(halfSize,vec2(1.))*(1.-curved)*strength*1.05*polarity;
    float maxBend=min(min(halfSize.x,halfSize.y)*.73,11.+strength*38.);
    bend*=min(1.,maxBend/max(length(bend),.001));
    vec2 lookup=pos+bend;
    vec3 col=sampleScene(lookup);
    float blur=uBlur*(.12+curved*curved)*1.25;
    if(blur>.20){
      vec2 offs=vec2(blur,blur*.66);
      col=col*.40+(sampleScene(lookup+offs)+sampleScene(lookup-offs)
       +sampleScene(lookup+vec2(offs.x,-offs.y))
       +sampleScene(lookup+vec2(-offs.x,offs.y)))*.15;
    }
    float fringe=uChroma*curved*curved;
    if(fringe>.07){
      vec2 chroma=outward*fringe;
      col.r=mix(col.r,sampleScene(lookup+chroma).r,.78);
      col.b=mix(col.b,sampleScene(lookup-chroma).b,.78);
    }
    float fresnel=.038+.962*pow(1.-max(front,0.),5.);
    vec3 environment=sampleScene(pos+outward*(7.+roll*.14));
    col=mix(col,mix(vec3(.66,.81,.92),environment,.50),clamp(fresnel*uFresnel*.82,0.,.62));
    vec3 key=normalize(vec3(uLight,uElevation));
    vec3 fill=normalize(vec3(-uLight*.7,.82));
    vec3 h1=normalize(key+vec3(0.,0.,1.));
    vec3 h2=normalize(fill+vec3(0.,0.,1.));
    float exponent=mix(20.,180.,uGloss);
    float spec=pow(max(dot(surfaceNormal,h1),0.),exponent)*.48
      +pow(max(dot(surfaceNormal,h2),0.),exponent*1.55)*.24;
    float edgeBright=pow(keyAngle,8.)*exp(-depth/3.2)*.54;
    float caustic=exp(-pow((depth-roll*.57)/max(1.,roll*.18),2.))
      *pow(fillAngle,3.)*.14;
    vec3 bleed=sampleScene(pos+outward*max(4.,roll*.39));
    col+=bleed*(curved*curved*.07+caustic*.15)*uSpill;
    float highlight=clamp((spec+edgeBright+caustic)*uShine,0.,.82);
    col=mix(col,vec3(.97,.988,1.),highlight);
    col=mix(col,vec3(.75,.87,.95),curved*.13*uTint);
    // Only functional tracks/indicators receive pigment; free glass buttons
    // retain their original transparent refraction. Apply prior to compositing
    // so the thumb is drawn in front of its track, never merged into the glass.
    if(uStyle==0) col=mix(col,uFill[i].rgb,clamp(uFill[i].a,0.,1.)*(1.-.11*curved));
    float opacity=clamp(uMeta[i].z,0.,1.);
    // Old School opacity is handled in shadeConsole. This pass is Liquid only.
    accum=mix(accum,col,mask*opacity);
    accum=clamp(accum-accum*shadow*(1.-mask),0.,1.);
    accum=clamp(accum+vec3(.62,.80,1.)*glow*(1.-mask),0.,1.);
  }
  fragColor=vec4(clamp(accum,0.,1.),1.);
}
