GLASS LAB 7.0 — PACK DE COMPONENTES E SONS INDIVIDUAIS
Inclui TODOS os 10 componentes de cada um dos 2 estilos (20 presets).
Os componentes não modificados entram com valores padrão.
Alterações no MATERIAL aplicam-se a todos os botões do mesmo estilo;
tamanho, interação e parâmetros físicos de cada componente são individuais.
Liquid Glass e Old School são estilos independentes.
SHADER GLSL REAL (WebGL2) incluído em shaders/glasslab-v7.frag.glsl.
Envie este ZIP inteiro ao ChatGPT para portar ao launcher Horizon.
Cada botão e estilo têm um som próprio; não há mistura nem sons aleatórios.
Uma foto de fundo da galeria NUNCA é incluída neste arquivo.
Gerado: 2026-11-12T19:18:50.360Z
