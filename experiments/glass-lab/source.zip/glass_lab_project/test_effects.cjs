// Tests the actual sound selector engine with 66 real catalog records and a mock Audio.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.join(__dirname,'web-demo');
let t=1000,played=[],paused=[];
class AudioMock {
  constructor(file){this.src=file;this.paused=false;this.volume=0;this.currentTime=0;}
  play(){played.push({file:this.src,volume:this.volume});return Promise.resolve();}
  pause(){paused.push(this.src);this.paused=true;}
}
const context={window:{},performance:{now:()=>t},Audio:AudioMock};
vm.createContext(context);
for(const file of ['sfx/catalog.js','audio.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context);
const audio=context.window.GlassLabAudio;
assert.equal(audio.catalog.length,66);
assert.equal(Object.keys(audio.byGroup).length,8);
let config={volume:35,audioEnabled:true};
assert(audio.playSelected('sfx/modern-2.ogg',config));
assert.equal(played.length,1);
assert.match(played[0].file,/modern-2/);
// No second channel: previous must stop before one new file begins.
t+=300; assert(audio.playSelected('sfx/retro-3.ogg',config));
assert.equal(played.length,2);assert.equal(paused.length,1);assert.match(paused[0],/modern-2/);
assert.equal(audio.playSelected('none',config),false);assert.equal(played.length,2);
assert.equal(audio.playSelected('sfx/missing.ogg',config),false);
config.audioEnabled=false;assert.equal(audio.playSelected('sfx/retro-1.ogg',config),false);
assert(audio.previewFile('sfx/retro-1.ogg',30));assert.equal(played.length,3);
assert.equal(paused.length,2);
assert(played.every(x=>x.volume>=0 && x.volume<=.35));
assert.equal(fs.existsSync(path.join(root,'particles.js')),false);
console.log('GLASS LAB V7 audio: 66 samples / 8 groups; single-file, preview, mute, stop-previous; no particles PASS');
