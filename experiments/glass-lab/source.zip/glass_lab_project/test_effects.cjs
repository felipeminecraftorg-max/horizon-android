// Real app-side FX tests without WebGL. Audio is mocked; samples and routing are not.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=require('node:path').join(__dirname,'web-demo');
let currentTime=10000; const played=[];
class Sample {
  constructor(src){this.src=src;this.paused=true;this.volume=0;this.playbackRate=1;}
  cloneNode(){return new Sample(this.src)}
  play(){this.paused=false;played.push({src:this.src,volume:this.volume,rate:this.playbackRate});return Promise.resolve()}
}
const audioSandbox={window:{},performance:{now:()=>currentTime},Audio:Sample,document:{createElement(){return {canPlayType(){return 'probably'}}}},Math};
vm.createContext(audioSandbox);
for(const file of ['sfx/catalog.js','audio.js']) vm.runInContext(fs.readFileSync(require('node:path').join(root,file),'utf8'),audioSandbox);
const audio=audioSandbox.window.GlassLabAudio;
assert.equal(audioSandbox.window.GLASSLAB_SOUND_CATALOG.length,66);
assert.deepEqual(Object.keys(audio.byGroup).sort(),['abstract','african','coffee','minimalist','modern','retro','ultimate-ui','wood-block'].sort());
const liquid={audioEnabled:true,primary:'modern',secondary:'minimalist',mixEnabled:false,volume:32,blend:50};
const retro={...liquid,primary:'retro',secondary:'ultimate-ui',mixEnabled:true};
assert(audio.play('liquid','press',liquid));
assert.equal(played.length,1);assert.match(played.at(-1).src,/modern-/);
currentTime+=150;assert(audio.play('oldschool','toggle',retro));assert.equal(played.length,3);
assert(played.some(x=>x.src.includes('retro-')));
assert(played.some(x=>x.src.includes('ultimate-ui-')));
const silent={...retro,audioEnabled:false};currentTime+=150;
assert.equal(audio.play('oldschool','press',silent),false);assert.equal(played.length,3);
const invalid={...retro,primary:'unknown',mixEnabled:false};currentTime+=150;
assert.equal(audio.play('oldschool','press',invalid),false);
assert(played.every(x=>x.volume>=0&&x.volume<=.35));
// Particle dynamics: hard cap on count, decreasing lifetime, reduced-motion path.
const strokes=[],canvas={width:0,height:0,getContext(){return {setTransform(){},clearRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){strokes.push(1)}}}};
const partSandbox={window:{},document:{getElementById(){return canvas}},matchMedia(){return {matches:false}},Math};
vm.createContext(partSandbox);vm.runInContext(fs.readFileSync(require('node:path').join(root,'particles.js'),'utf8'),partSandbox);
const particles=partSandbox.window.GlassLabParticles;
particles.resize(900,430,2);assert.equal(canvas.width,1800);
for(let i=0;i<35;i++)particles.emit(340,180,30,-10,'oldschool',100,'spark');
assert(particles.active()<=28);let ticks=0;
while(particles.active()&&ticks<100){particles.tick(.016);ticks++}
assert.equal(particles.active(),0);assert(strokes.length>0);
console.log('Glass Lab 6: 66 audio events, two style mixes, silence, physics particles and decay PASS');
