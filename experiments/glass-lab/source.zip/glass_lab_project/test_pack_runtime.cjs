const vm=require('node:vm'), fs=require('node:fs'), path=require('node:path'),os=require('node:os');
const elements=new Map();
function element(id){if(elements.has(id))return elements.get(id);const e={id,style:{},dataset:{},name:"",classList:{add(){},remove(){},toggle(){}},attributes:{},listeners:{},value:'',checked:true,hidden:false,open:false,clientWidth:900,clientHeight:600,addEventListener(name,cb){this.listeners[name]=cb;},setAttribute(n,v){this.attributes[n]=v;},getBoundingClientRect(){return {width:id==='view'?900:345,height:id==='view'?600:200,left:0,top:0};},closest(){return {hidden:false};},querySelectorAll(){return [];},click(){return this.listeners.click?.();}};elements.set(id,e);return e;}
const g={gradient:{addColorStop(){}}};const ctx={createLinearGradient(){return g.gradient;},createRadialGradient(){return g.gradient;},fillRect(){},strokeRect(){},beginPath(){},closePath(){},moveTo(){},lineTo(){},bezierCurveTo(){},stroke(){},fill(){},roundRect(){},arc(){},save(){},restore(){},clip(){},translate(){},rotate(){},scale(){},fillText(){},getImageData(){return {data:[20,50,80,255]};}};
function canvasMock(id){const v=element(id);v.getContext=(type)=>type==='2d'?ctx:null;return v;}
const doc={addEventListener(){},getElementById(id){return element(id)},querySelector(sel){return element(sel)},querySelectorAll(){return []},createElement(tag){if(tag==='canvas'){const e=canvasMock('scene');e.width=900;e.height=600;return e;}return element('e-'+tag);},body:element('body')};
canvasMock('view');
const saved=new Map();
const window={devicePixelRatio:1,addEventListener(){},GlassLabExport:{savePack(name,b64){globalThis.packBytes=Buffer.from(b64,'base64');globalThis.packName=name;},savePreset(name,data){globalThis.txt=data}},};
const sandbox={window,document:doc,btoa:(s)=>Buffer.from(s,'binary').toString('base64'),location:{search:'?test=1'},navigator:{},console,setTimeout,clearTimeout,Blob,TextEncoder,Uint8Array,Float32Array,DataView,Math,Date,Number,JSON,performance:{now(){return 1}},requestAnimationFrame(){},localStorage:{getItem(k){return saved.get(k)||null;},setItem(k,v){saved.set(k,v);}},URL:{createObjectURL(){return 'data:';},revokeObjectURL(){}},Image:class{},setInterval,clearInterval};
vm.createContext(sandbox);for(const name of ['sfx/catalog.js','audio.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'web-demo',name),'utf8'),sandbox);vm.runInContext(fs.readFileSync(path.join(__dirname,'web-demo','app.js'),'utf8'),sandbox,{timeout:10000});
const api=window.__glassLabV7; if(!api)throw Error('Missing test API');
if(Object.keys(api.getStyles().oldschool).length!==10)throw Error('missing components');
if(api.getStyles().oldschool.bubble.retroChrome===api.getStyles().liquid.bubble.retroChrome)throw Error('styles not independent');
// Example: modifying a chrome parameter in a single component synchronizes 10.
element('switchStyle').click();
const chrome=element('retroChrome');chrome.value='97';chrome.listeners.input({target:chrome});
const original=api.getStyles().oldschool.bubble.retroChrome;
if(original!==97||Object.values(api.getStyles().oldschool).some(x=>x.retroChrome!==97))throw Error('material not synchronized');
const liquid=api.getStyles().liquid.bubble.retroChrome;
if(liquid===97)throw Error('liquid theme unintentionally modified');
const groupHtml=element('soundGroups').innerHTML;
if((groupHtml.match(/class="sound-group"/g)||[]).length!==8)throw Error('Need eight collapsible SFX groups');
if((groupHtml.match(/class="sound-sample"/g)||[]).length!==66)throw Error('Need preview for all 66 SFX');
if((groupHtml.match(/name="componentSound"/g)||[]).length!==67)throw Error('Need 66 radio selectors + silent');
// User's radio assignment must change ONLY the active component in current style.
element('soundGroups').listeners.change({target:{name:'componentSound',value:'sfx/retro-12.ogg'}});
if(api.componentSound('oldschool','bubble')!=='sfx/retro-12.ogg')throw Error('Radio did not persist selection');
if(api.componentSound('oldschool','slider')!=='sfx/retro-5.ogg')throw Error('Radio changed other component');
if(api.componentSound('liquid','bubble')!=='sfx/modern-1.ogg')throw Error('Radio changed other style');
const manifest=api.packFiles();
if(manifest.files.length!==30)throw Error('pack expected 26 files, got '+manifest.files.length);
console.log('PRESET COUNT',manifest.files.filter(x=>x.name.startsWith('presets/')).length);
(async()=>{
 await element('downloadPack').listeners.click();
 if(!globalThis.packBytes)throw Error('Android native export did not trigger');
 fs.writeFileSync(path.join(os.tmpdir(),'GlassLab_6_Runtime_Validation.zip'),globalThis.packBytes);
 console.log('OK ZIP BYTES',globalThis.packBytes.length,globalThis.packName);
 fs.writeFileSync(path.join(os.tmpdir(),'glasslab6_runtime_styles.json'),JSON.stringify({old:original,liquid,all:Object.keys(api.getStyles().oldschool)},null,2));
})().catch(x=>{console.error(x);process.exitCode=1});
