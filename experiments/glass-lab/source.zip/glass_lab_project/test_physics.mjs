// Standalone physics regression: track continuity and understated overshoot.
import fs from 'node:fs';
import vm from 'node:vm';
const src=fs.readFileSync(new URL('./web-demo/app.js',import.meta.url),'utf8');
const start=src.indexOf('  function springStep(');
const end=src.indexOf('  function animate(',start);
if(start<0||end<0)throw Error('springStep not present');
const text=src.slice(start,end);
const box={Math,clamp:(v,min,max)=>Math.min(max,Math.max(min,v))};
vm.createContext(box);vm.runInContext(text+';globalThis.step=springStep;',box);
for(const [k,zeta] of [[42,.76],[100,.76],[115,.82],[180,.81]]){
  for(const fps of [30,60,120]){
    let p=0,v=0,peak=0;
    for(let f=0;f<fps*1.5;f++){
      const goal=f<fps*.55?1:0;
      [p,v]=box.step(p,v,goal,k,zeta,1/fps);
      peak=Math.max(peak,p);
      if(!Number.isFinite(p)||!Number.isFinite(v))throw Error(`NaN at ${fps} ${k}`);
    }
    if(Math.abs(p)>.025||peak>1.04||peak<.85)throw Error(`Unnatural spring ${fps}Hz ${k}: final=${p}, peak=${peak}`);
  }
}
console.log('Physics: stable at 30 / 60 / 120Hz, reversible, restrained overshoot');
