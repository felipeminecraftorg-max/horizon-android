# Glass Lab 6 — SFX credits and distribution

The user supplied `sfx.zip` for integration into the Glass Lab Android app. The sound samples are transcoded into compact 24 kbit/s mono Ogg Opus for interactive preview. They are *not* sold or made available as an independent sample library.

- **Cyrex Studios / Nathan Gibson**, Universal UI Soundpack (Modern, Retro, Minimalist, Abstract, African, Coffee, Wood Block): **Creative Commons Attribution 4.0**. https://cyrex-studios.itch.io/universal-ui-soundpack
- **JDSherbert**, Ultimate UI SFX Pack: royalty-free with attribution required; do not redistribute individual sounds outside an app. https://jdsherbert.itch.io/ultimate-ui-sfx-pack

The Glass Lab Android export of an optical preset pack embeds the compressed samples alongside their attribution only to let the user port the effects into their own application. For public distribution outside your project, review each original license.
