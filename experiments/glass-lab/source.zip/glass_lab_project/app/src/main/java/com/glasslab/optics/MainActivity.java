package com.glasslab.optics;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.WindowManager;

/** Independent Android optical test app. It never reads Horizon files. */
public final class MainActivity extends Activity {
    private static final int PHOTO_REQUEST = 9204;
    private WebView browser;
    private ValueCallback<Uri[]> fileResult;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xff080c14);
        getWindow().setNavigationBarColor(0xff080c14);
        browser = new WebView(this);
        browser.setBackgroundColor(0xff080c14);
        browser.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true); // Android system photo picker URIs
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(
                WebView webView, ValueCallback<Uri[]> filePathCallback,
                WebChromeClient.FileChooserParams fileChooserParams) {
                if (fileResult != null) fileResult.onReceiveValue(null);
                fileResult = filePathCallback;
                try {
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("image/*");
                    startActivityForResult(Intent.createChooser(pick, "Escolha uma foto para o teste"), PHOTO_REQUEST);
                } catch (Exception exception) {
                    fileResult.onReceiveValue(null);
                    fileResult = null;
                }
                return true;
            }
        });
        browser.setWebViewClient(new WebViewClient());
        setContentView(browser);
        browser.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int request, int result, Intent intent) {
        super.onActivityResult(request, result, intent);
        if (request != PHOTO_REQUEST || fileResult == null) return;
        Uri[] selected = (result == RESULT_OK && intent != null && intent.getData() != null)
            ? new Uri[]{intent.getData()} : null;
        fileResult.onReceiveValue(selected);
        fileResult = null;
    }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (browser != null) browser.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null);
    }

    @Override public void onBackPressed() {
        if (browser != null && browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (fileResult != null) { fileResult.onReceiveValue(null); fileResult = null; }
        if (browser != null) { browser.destroy(); browser = null; }
        super.onDestroy();
    }
}
