package com.glasslab.optics;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.util.Base64;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Independent, offline WebGL2 optical editor. The narrow Android bridge only invokes system SAF to export a TXT
 * preset or full ZIP pack.
 * No Horizon data, app files, or general storage permission are accessed.
 */
public final class MainActivity extends Activity {
    private static final int PHOTO_OR_IMPORT_REQUEST = 9204;
    private static final int EXPORT_PRESET_REQUEST = 9205;
    private WebView browser;
    private ValueCallback<Uri[]> fileResult;
    private byte[] pendingPayload;
    private String pendingMime;
    private String pendingFileName;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xff080d15);
        getWindow().setNavigationBarColor(0xff080d15);
        browser = new WebView(this);
        browser.setBackgroundColor(0xff080d15);
        browser.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        browser.addJavascriptInterface(new ExportBridge(), "GlassLabExport");
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(
                    WebView webView, ValueCallback<Uri[]> callback,
                    WebChromeClient.FileChooserParams chooserParams) {
                if (fileResult != null) fileResult.onReceiveValue(null);
                fileResult = callback;
                try {
                    String[] accepts = chooserParams.getAcceptTypes();
                    boolean image = false;
                    if (accepts != null) {
                        for (String accept : accepts) {
                            if (accept != null && accept.startsWith("image/")) image = true;
                        }
                    }
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(image ? "image/*" : "*/*");
                    if (!image) {
                        intent.putExtra(Intent.EXTRA_MIME_TYPES,
                                new String[]{"text/plain", "application/json", "application/octet-stream"});
                    }
                    startActivityForResult(Intent.createChooser(intent,
                            image ? "Escolher foto para refração" : "Importar preset Glass Lab"),
                            PHOTO_OR_IMPORT_REQUEST);
                } catch (Exception e) {
                    fileResult.onReceiveValue(null);
                    fileResult = null;
                }
                return true;
            }
        });
        browser.setWebViewClient(new WebViewClient());
        setContentView(browser);
        browser.loadUrl("file:///android_asset/index.html");
    }

    /** Runs on a WebView bridge thread; all UI interactions go onto the main thread. */
    private final class ExportBridge {
        @JavascriptInterface public void savePreset(String filename, String text) {
            if (text == null || text.length() > 350000 ||
                    !(text.startsWith("GLASS_LAB_PRESET_V2") ||
                      text.startsWith("GLASS_LAB_PRESET_V3") ||
                      text.startsWith("GLASS_LAB_PRESET_V4") ||
                      text.startsWith("GLASS_LAB_PRESET_V5") ||
                      text.startsWith("GLASS_LAB_PRESET_V6"))) {
                runOnUiThread(() -> notifyExport(false, "Preset TXT inválido."));
                return;
            }
            offerExport(filename, text.getBytes(StandardCharsets.UTF_8), "text/plain", ".txt");
        }

        @JavascriptInterface public void savePack(String filename, String base64Zip) {
            if (base64Zip == null || base64Zip.length() > 9000000) {
                runOnUiThread(() -> notifyExport(false, "Pack muito grande."));
                return;
            }
            try {
                byte[] bytes = Base64.decode(base64Zip, Base64.DEFAULT);
                if (bytes.length < 30 || bytes.length > 6500000 ||
                        bytes[0] != 'P' || bytes[1] != 'K' || bytes[2] != 3 || bytes[3] != 4) {
                    runOnUiThread(() -> notifyExport(false, "Arquivo ZIP inválido."));
                    return;
                }
                offerExport(filename, addSfxAssets(bytes), "application/zip", ".zip");
            } catch (Exception exception) {
                runOnUiThread(() -> notifyExport(false, "Erro ao preparar ZIP."));
            }
        }

        /** Bundle the app-owned samples into the user's portable exported ZIP.
         *  This avoids exposing the application storage to JavaScript. The
         *  20 TXT presets, manifests, and per-style SFX maps remain untouched.
         */
        private byte[] addSfxAssets(byte[] packed) throws Exception {
            ByteArrayOutputStream out = new ByteArrayOutputStream(packed.length + 300000);
            byte[] buffer = new byte[8192];
            try (ZipOutputStream zip = new ZipOutputStream(out);
                 ZipInputStream original = new ZipInputStream(new java.io.ByteArrayInputStream(packed))) {
                ZipEntry entry;
                while ((entry = original.getNextEntry()) != null) {
                    String name = entry.getName();
                    if (name.startsWith("/") || name.contains("..") || name.startsWith("audio/files/")) {
                        throw new IllegalArgumentException("ZIP entry invalid: " + name);
                    }
                    zip.putNextEntry(new ZipEntry(name));
                    int n;
                    while ((n = original.read(buffer)) != -1) zip.write(buffer, 0, n);
                    zip.closeEntry();
                    original.closeEntry();
                }
                String[] sounds = getAssets().list("sfx");
                if (sounds != null) for (String name : sounds) {
                    if (!name.matches("[a-z0-9-]+\\.ogg")) continue;
                    try (InputStream source = getAssets().open("sfx/" + name)) {
                        zip.putNextEntry(new ZipEntry("audio/files/" + name));
                        int n;
                        while ((n = source.read(buffer)) != -1) zip.write(buffer, 0, n);
                        zip.closeEntry();
                    }
                }
            }
            byte[] result = out.toByteArray();
            if (result.length > 6500000) throw new IllegalArgumentException("ZIP muito grande");
            return result;
        }

        private void offerExport(String filename, byte[] payload, String mime, String suffix) {
            final String safe = (filename == null ? "GlassLab" + suffix : filename)
                    .replaceAll("[^a-zA-Z0-9_.-]", "_");
            runOnUiThread(() -> {
                if (pendingPayload != null) {
                    notifyExport(false, "Finalize a exportação anterior.");
                    return;
                }
                pendingPayload = payload;
                pendingMime = mime;
                pendingFileName = safe.endsWith(suffix) ? safe : safe + suffix;
                try {
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType(mime);
                    save.putExtra(Intent.EXTRA_TITLE, pendingFileName);
                    startActivityForResult(save, EXPORT_PRESET_REQUEST);
                } catch (Exception exception) {
                    pendingPayload = null;
                    pendingMime = null;
                    pendingFileName = null;
                    notifyExport(false, "Não foi possível abrir o salvamento.");
                }
            });
        }
    }

    private void notifyExport(boolean ok, String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        if (browser != null) {
            browser.evaluateJavascript("window.glassLabOnExport && window.glassLabOnExport("
                    + (ok ? "true" : "false") + "," + JSONObject.quote(text) + ")", null);
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent intent) {
        super.onActivityResult(request, result, intent);
        if (request == PHOTO_OR_IMPORT_REQUEST) {
            if (fileResult == null) return;
            Uri[] selected = (result == RESULT_OK && intent != null && intent.getData() != null)
                    ? new Uri[]{intent.getData()} : null;
            fileResult.onReceiveValue(selected);
            fileResult = null;
        } else if (request == EXPORT_PRESET_REQUEST) {
            byte[] payload = pendingPayload;
            String mime = pendingMime;
            pendingPayload = null;
            pendingMime = null;
            pendingFileName = null;
            if (result != RESULT_OK || intent == null || intent.getData() == null) {
                notifyExport(false, "Exportação cancelada.");
                return;
            }
            if (payload == null) {
                notifyExport(false, "O arquivo não está mais disponível.");
                return;
            }
            try (OutputStream stream = getContentResolver().openOutputStream(intent.getData(), "w")) {
                if (stream == null) throw new IllegalStateException("Arquivo inacessível");
                stream.write(payload);
                stream.flush();
                notifyExport(true, "application/zip".equals(mime)
                        ? "Pack completo ZIP salvo com sucesso."
                        : "Preset TXT salvo com sucesso.");
            } catch (Exception exception) {
                notifyExport(false, "Falha ao gravar o arquivo.");
            }
        }
    }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (browser != null) {
            browser.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null);
        }
    }

    @Override public void onBackPressed() {
        if (browser != null && browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (fileResult != null) { fileResult.onReceiveValue(null); fileResult = null; }
        pendingPayload = null;
        pendingMime = null;
        pendingFileName = null;
        if (browser != null) { browser.destroy(); browser = null; }
        super.onDestroy();
    }
}
