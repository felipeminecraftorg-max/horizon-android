package com.glasslab.optics;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Independent, offline WebGL2 optical editor. Its only Android native bridge
 * launches the system document picker to export a user-authored preset TXT.
 * No Horizon data, app files, or general storage permission are accessed.
 */
public final class MainActivity extends Activity {
    private static final int PHOTO_OR_IMPORT_REQUEST = 9204;
    private static final int EXPORT_PRESET_REQUEST = 9205;
    private WebView browser;
    private ValueCallback<Uri[]> fileResult;
    private String pendingPreset;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xff080d15);
        getWindow().setNavigationBarColor(0xff080d15);
        browser = new WebView(this);
        browser.setBackgroundColor(0xff080d15);
        browser.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        browser.addJavascriptInterface(new ExportBridge(), "GlassLabExport");
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(
                    WebView webView, ValueCallback<Uri[]> callback,
                    WebChromeClient.FileChooserParams chooserParams) {
                if (fileResult != null) fileResult.onReceiveValue(null);
                fileResult = callback;
                try {
                    String[] accepts = chooserParams.getAcceptTypes();
                    boolean image = false;
                    if (accepts != null) {
                        for (String accept : accepts) {
                            if (accept != null && accept.startsWith("image/")) image = true;
                        }
                    }
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(image ? "image/*" : "*/*");
                    if (!image) {
                        intent.putExtra(Intent.EXTRA_MIME_TYPES,
                                new String[]{"text/plain", "application/json", "application/octet-stream"});
                    }
                    startActivityForResult(Intent.createChooser(intent,
                            image ? "Escolher foto para refração" : "Importar preset Glass Lab"),
                            PHOTO_OR_IMPORT_REQUEST);
                } catch (Exception e) {
                    fileResult.onReceiveValue(null);
                    fileResult = null;
                }
                return true;
            }
        });
        browser.setWebViewClient(new WebViewClient());
        setContentView(browser);
        browser.loadUrl("file:///android_asset/index.html");
    }

    /** Runs on a WebView bridge thread; all UI interactions go onto the main thread. */
    private final class ExportBridge {
        @JavascriptInterface public void savePreset(String filename, String text) {
            if (text == null || text.length() > 200000 ||
                    !text.startsWith("GLASS_LAB_PRESET_V2")) {
                runOnUiThread(() -> notifyExport(false, "Preset inválido."));
                return;
            }
            final String safeFilename = (filename == null ? "glasslab.txt" : filename)
                    .replaceAll("[^a-zA-Z0-9_.-]", "_");
            runOnUiThread(() -> {
                if (pendingPreset != null) {
                    notifyExport(false, "Finalize a exportação anterior.");
                    return;
                }
                pendingPreset = text;
                try {
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType("text/plain");
                    save.putExtra(Intent.EXTRA_TITLE,
                            safeFilename.endsWith(".txt") ? safeFilename : safeFilename + ".txt");
                    startActivityForResult(save, EXPORT_PRESET_REQUEST);
                } catch (Exception exception) {
                    pendingPreset = null;
                    notifyExport(false, "Não foi possível abrir o salvamento.");
                }
            });
        }
    }

    private void notifyExport(boolean ok, String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        if (browser != null) {
            browser.evaluateJavascript("window.glassLabOnExport && window.glassLabOnExport("
                    + (ok ? "true" : "false") + "," + JSONObject.quote(text) + ")", null);
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent intent) {
        super.onActivityResult(request, result, intent);
        if (request == PHOTO_OR_IMPORT_REQUEST) {
            if (fileResult == null) return;
            Uri[] selected = (result == RESULT_OK && intent != null && intent.getData() != null)
                    ? new Uri[]{intent.getData()} : null;
            fileResult.onReceiveValue(selected);
            fileResult = null;
        } else if (request == EXPORT_PRESET_REQUEST) {
            String preset = pendingPreset;
            pendingPreset = null;
            if (result != RESULT_OK || intent == null || intent.getData() == null) {
                notifyExport(false, "Exportação cancelada.");
                return;
            }
            if (preset == null) {
                notifyExport(false, "O preset não está mais disponível.");
                return;
            }
            try (OutputStream stream = getContentResolver().openOutputStream(intent.getData(), "w")) {
                if (stream == null) throw new IllegalStateException("Arquivo inacessível");
                stream.write(preset.getBytes(StandardCharsets.UTF_8));
                stream.flush();
                notifyExport(true, "Preset TXT salvo com sucesso.");
            } catch (Exception exception) {
                notifyExport(false, "Falha ao gravar o arquivo TXT.");
            }
        }
    }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (browser != null) {
            browser.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null);
        }
    }

    @Override public void onBackPressed() {
        if (browser != null && browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (fileResult != null) { fileResult.onReceiveValue(null); fileResult = null; }
        pendingPreset = null;
        if (browser != null) { browser.destroy(); browser = null; }
        super.onDestroy();
    }
}
