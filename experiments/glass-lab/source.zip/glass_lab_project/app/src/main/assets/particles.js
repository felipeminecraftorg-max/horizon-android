/* Glass Lab 6 — restrained, physical 2D accent particles.
 * Only the actual metal control/selected component can emit, on touch movement.
 * No fullscreen confetti, no shader impostor and no animation when reduced-motion.
 */
(() => {
  'use strict';
  const canvas=document.getElementById('particleLayer');
  const ctx=canvas?.getContext('2d',{alpha:true});
  if(!canvas||!ctx)return;
  let w=1,h=1,dpr=1,pieces=[];
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  function resize(width,height,scale){
    w=width;h=height;dpr=scale;
    canvas.width=Math.max(1,Math.round(w*dpr));
    canvas.height=Math.max(1,Math.round(h*dpr));
    ctx.setTransform(dpr,0,0,dpr,0,0);
    pieces=[];
  }
  function emit(x,y,dx,dy,style,intensity=35,kind='spark'){
    if(reduced.matches || intensity<=0)return;
    const speed=Math.hypot(dx,dy);
    if(speed<1.6)return;
    const count=clamp(Math.round(speed*.08*intensity/40),0,4);
    if(!count)return;
    for(let i=0;i<count && pieces.length<28;i++){
      const a=Math.atan2(dy,dx)+(Math.random()-.5)*1.8;
      const power=clamp(speed*.35+Math.random()*28,10,75);
      const life=(kind==='spark'?.19:.25)+Math.random()*.14;
      pieces.push({x,y,vx:Math.cos(a)*power-(dx*.26),vy:Math.sin(a)*power-(dy*.26),
        life,age:0,size:(kind==='spark'?1.1:.85)+Math.random()*.5,
        style,kind});
    }
  }
  function tick(dt){
    if(!pieces.length)return false;
    ctx.clearRect(0,0,w,h);
    dt=Math.min(dt,.045);
    for(let i=pieces.length-1;i>=0;i--){
      const p=pieces[i];p.age+=dt;
      if(p.age>=p.life){pieces.splice(i,1);continue;}
      const drag=Math.exp(-3.8*dt);
      p.vx*=drag;p.vy=p.vy*drag+(p.kind==='spark'?115:36)*dt;
      p.x+=p.vx*dt;p.y+=p.vy*dt;
      const t=1-p.age/p.life;
      const alpha=Math.pow(t,1.6)*.76;
      ctx.strokeStyle=p.kind==='spark'?`rgba(244,233,213,${alpha})`:`rgba(220,245,255,${alpha})`;
      ctx.lineWidth=p.size*t+.4;ctx.lineCap='round';
      ctx.beginPath();ctx.moveTo(p.x,p.y);
      ctx.lineTo(p.x-p.vx*.028,p.y-p.vy*.028);ctx.stroke();
    }
    if(!pieces.length)ctx.clearRect(0,0,w,h);
    return pieces.length>0;
  }
  function clear(){pieces=[];ctx.clearRect(0,0,w,h);}
  window.GlassLabParticles=Object.freeze({resize,emit,tick,clear,active:()=>pieces.length});
})();
