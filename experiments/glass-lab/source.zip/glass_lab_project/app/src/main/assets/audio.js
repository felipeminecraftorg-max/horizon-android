/* Glass Lab 6 — independent, event-aware SFX playback. All user supplied audio
 * is bundled with the app and converted to compact Ogg Opus previews.
 * Requires a direct user gesture before playback; never auto-plays background audio.
 */
(() => {
  'use strict';
  const samples = window.GLASSLAB_SOUND_CATALOG || [];
  const byGroup = Object.create(null);
  for(const file of samples) (byGroup[file.group] ||= []).push(file);
  const counters = Object.create(null);
  const lastEvent = Object.create(null);
  const cache = new Map();
  const groupTitles = {
    minimalist:'Minimalist', modern:'Modern', retro:'Retro', abstract:'Abstract',
    'wood-block':'Wood Block', african:'African', coffee:'Coffee', 'ultimate-ui':'Ultimate UI HD'
  };
  const events = {
    press:'select', release:'popup-close', slide:'swipe', tick:'cursor',
    toggle:'select', tab:'cursor', back:'cancel', open:'popup-open', error:'error', select:'select'
  };
  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const audioSupported = !!document.createElement('audio').canPlayType('audio/ogg; codecs="opus"');
  let lastError='';
  function choose(group,event){
    const files=byGroup[group]||[];
    if(!files.length)return null;
    const category=events[event]||'select';
    const candidates=group==='ultimate-ui' ?
      (files.filter(x=>x.event===category).length ? files.filter(x=>x.event===category) : files.filter(x=>x.event==='select')) : files;
    const pool=candidates.length?candidates:files;
    const key=group+':'+category;
    const idx=(counters[key]||0)%pool.length;
    counters[key]=(counters[key]||0)+1;
    // Sweep a list deterministically instead of replaying one loud sample.
    return pool[(idx*3+(category.length%pool.length))%pool.length];
  }
  function playFile(file,gain,rate=1){
    if(!file || gain<.002)return;
    let audio=cache.get(file.file);
    if(!audio){
      audio = new Audio(file.file);
      audio.preload='none';
      cache.set(file.file,audio);
    }
    // Spawn a fresh node only when needed for overlapping UI taps. At most 2 layers.
    if(!audio.paused){audio=audio.cloneNode(false);audio.src=file.file;}
    audio.volume=clamp(gain,0,.35);
    audio.playbackRate=clamp(rate,.82,1.18);
    const result=audio.play();
    if(result && typeof result.catch==='function') result.catch(err=>{
      lastError='SFX indisponível: '+(err?.name||'reprodução bloqueada');
    });
  }
  function play(style,event,config,force=false){
    if(!config || (!config.audioEnabled && !force))return false;
    const now=performance.now();
    const minGap=event==='slide'||event==='tick'?105:55;
    const key=style+':'+event;
    if(now-(lastEvent[key]||-1000)<minGap && !force)return false;
    lastEvent[key]=now;
    const base=clamp(config.volume/100,0,1)*.24;
    const blend=config.mixEnabled && config.secondary!=='none'
      ? clamp(config.blend/100,0,1) : 0;
    const main=choose(config.primary,event);
    playFile(main,base*(1-.48*blend),style==='oldschool'?.95:1.02);
    if(blend>0){
      const second=choose(config.secondary,event);
      if(second && second.file!==main?.file)playFile(second,base*blend*.58,style==='oldschool'?.91:1.05);
    }
    return !!main;
  }
  window.GlassLabAudio = Object.freeze({play,byGroup,groupTitles,audioSupported,get lastError(){return lastError;}});
})();
