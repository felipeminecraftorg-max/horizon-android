/* Glass Lab 7.0: exact, per-component SFX. Never randomize/mix/layer. */
(() => {
  'use strict';
  const catalog=window.GLASSLAB_SOUND_CATALOG||[];
  const byGroup=Object.create(null),byFile=new Map();
  for(const sound of catalog){
    (byGroup[sound.group] ||= []).push(sound);
    byFile.set(sound.file,sound);
  }
  const groupTitles={minimalist:'Minimalist',modern:'Modern',retro:'Retro',abstract:'Abstract',
    'wood-block':'Wood Block',african:'African',coffee:'Coffee','ultimate-ui':'Ultimate UI HD'};
  let current=null,lastError='',lastPlayed=0;
  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  function playFile(file,volume=32,force=false){
    if(file==='none'||!byFile.has(file))return false;
    const now=performance.now();
    // One-shot: terminate previous playback rather than stack sound layers.
    if(current){try{current.pause();current.currentTime=0;}catch(_){}}
    current=new Audio(file);
    current.preload='auto';
    current.volume=clamp(Number(volume)||0,0,100)/100*.28;
    current.playbackRate=1;
    lastPlayed=now;
    const result=current.play();
    if(result && typeof result.catch==='function')result.catch(err=>{
      lastError='Áudio indisponível: '+(err?.name||'não permitido');
    });
    return true;
  }
  function playSelected(file,config,force=false){
    if(!config||(!config.audioEnabled&&!force))return false;
    return playFile(file,config.volume,force);
  }
  window.GlassLabAudio=Object.freeze({catalog,byGroup,groupTitles,playSelected,
    previewFile:(file,volume)=>playFile(file,volume,true),
    get lastError(){return lastError;},get lastPlayed(){return lastPlayed;}});
})();
