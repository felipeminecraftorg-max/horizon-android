/* Glass Lab: real-time, screen-space optical refraction. No baked glass sprites. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const canvas = $('view');
  const label = $('lensContent');
  const controls = document.querySelector('.controls');
  const gpuBadge = $('gpu');
  const params = { strength: 68, thickness: 73, chromatic: 45, blur: 12, shine: 62, size: 52 };
  let shape = 'bubble', background = 'landscape', userPhoto = null;
  let cx = 0, cy = 0, currentW = 0, currentH = 0, dpr = 1;
  let moveOffsetX = 0, moveOffsetY = 0, dragging = false, compare = false;
  let dirty = true, drawCount = 0, sampleTime = performance.now(), previousT = 0;
  const scene = document.createElement('canvas');
  const g2 = scene.getContext('2d', { alpha: false });
  const gl = canvas.getContext('webgl2', { alpha: false, antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: false });
  let program, vertex, texture, uniforms, vbo;
  const vert = `#version 300 es
    precision highp float;
    in vec2 position;
    out vec2 vUv;
    void main(){vUv = position*.5+.5;gl_Position=vec4(position,0.,1.);}`;
  const frag = `#version 300 es
    precision highp float;
    in vec2 vUv;
    out vec4 fragColor;
    uniform sampler2D uImage;
    uniform vec2 uRes;
    uniform vec2 uCenter;
    uniform vec2 uHalf;
    uniform vec2 uLight;
    uniform float uRadius;
    uniform float uStrength;
    uniform float uRoll;
    uniform float uChroma;
    uniform float uBlur;
    uniform float uShine;
    uniform float uCompare;
    float sdBox(vec2 p,vec2 b,float r){
      vec2 q=abs(p)-b+vec2(r);
      return length(max(q,0.))+min(max(q.x,q.y),0.)-r;
    }
    vec3 sceneAt(vec2 p){return texture(uImage,clamp(p/uRes,vec2(.001),vec2(.999))).rgb;}
    void main(){
      vec2 p=vUv*uRes;
      vec3 original=sceneAt(p);
      if(uCompare>.5){fragColor=vec4(original,1.);return;}
      vec2 local=p-uCenter;
      float rad=min(uRadius,min(uHalf.x,uHalf.y));
      vec2 q=abs(local)-uHalf+vec2(rad);
      float d=length(max(q,vec2(0.)))+min(max(q.x,q.y),0.)-rad;
      float aa=max(fwidth(d),1.0);
      float coverage=1.-smoothstep(-aa,aa,d);
      if(d>28.){fragColor=vec4(original,1.);return;}
      vec2 n;
      if(length(max(q,vec2(0.)))>.0001){
        n=normalize(max(q,vec2(0.)))*sign(local);
      }else{
        n=q.x>q.y?vec2(sign(local.x),0.):vec2(0.,sign(local.y));
      }
      float shadow=exp(-max(d,0.)/9.)*.20*(1.-smoothstep(18.,28.,max(d,0.)));
      float spill=exp(-pow(max(d,0.)/7.,2.))
        *(pow(max(dot(n,vec2(-.71,.71)),0.),8.)*.12+pow(max(dot(n,vec2(.8,-.6)),0.),9.)*.045);
      if(coverage<=.001){
        fragColor=vec4(clamp(original*(1.-shadow)+vec3(.67,.85,1.)*spill,0.,1.),1.);return;
      }
      float depth=max(-d,0.);
      float roll=max(uRoll,1.);
      float rim=pow(clamp(1.-depth/roll,0.,1.),.72);
      float front=sqrt(max(1.-rim*rim,.001));
      vec3 normal=normalize(vec3(n*rim,front));
      vec3 refracted=refract(vec3(0.,0.,-1.),normal,1./1.48);
      float medium=(roll*.7+4.)*(.4+.75*uStrength);
      vec2 displacement=refracted.xy/max(-refracted.z,.18)*medium;
      displacement-=local/max(uHalf,vec2(1.))*(1.-rim)*uStrength*1.8;
      displacement*=clamp(uStrength,0.,2.);
      float maxBend=min(uHalf.y*.67,9.+uStrength*32.);
      displacement*=min(1.,maxBend/max(length(displacement),.0001));
      vec2 lookup=p+displacement;
      vec3 col=sceneAt(lookup);
      float softness=uBlur*(.1+rim*rim)*.8;
      if(softness>.15){
        vec2 s=vec2(softness);
        col=col*.42 + sceneAt(lookup+s)*.145+sceneAt(lookup-s)*.145
          +sceneAt(lookup+vec2(s.x,-s.y))*.145
          +sceneAt(lookup+vec2(-s.x,s.y))*.145;
      }
      float fringe=uChroma*rim*rim;
      if(fringe>.07){
        vec2 aberr=n*fringe;
        col.r=mix(col.r,sceneAt(lookup+aberr).r,.82);
        col.b=mix(col.b,sceneAt(lookup-aberr).b,.82);
      }
      float fresnel=.038+(1.-.038)*pow(1.-max(normal.z,0.),5.);
      vec3 reflectedScene=sceneAt(p+n*(11.+roll*.15));
      vec3 environment=mix(vec3(.61,.76,.91),reflectedScene,.47);
      col=mix(col,environment,clamp(fresnel*.63,0.,.47));
      // An actual directional specular response, not a static bright border.
      vec3 key=normalize(vec3(uLight,1.06));
      vec3 fill=normalize(vec3(.66,-.68,.65));
      vec3 h1=normalize(key+vec3(0.,0.,1.));
      vec3 h2=normalize(fill+vec3(0.,0.,1.));
      float bright=pow(max(dot(normal,h1),0.),48.)*.33
         +pow(max(dot(normal,h2),0.),110.)*.22;
      float keyRim=pow(max(dot(n,uLight),0.),7.)*exp(-depth/4.)*.48;
      float innerRing=exp(-pow((depth-roll*.55)/max(roll*.17,1.),2.))
        *pow(max(dot(-n,uLight),0.),3.)*.13;
      vec3 bleed=sceneAt(p+n*max(3.,roll*.4));
      col+=bleed*rim*rim*.036*uShine;
      col=mix(col,vec3(.94,.98,1.),clamp((bright+keyRim+innerRing)*uShine,0.,.68));
      col=mix(col,vec3(.74,.89,1.),exp(-depth/2.2)*.12*uShine);
      // The face stays nearly colourless. Only the rolled rim gets a cool tint.
      col=mix(col,vec3(.63,.79,.91),rim*.045);
      vec3 finalColor=mix(original,col,coverage);
      finalColor-=original*shadow*(1.-coverage);
      finalColor+=vec3(.6,.78,1.)*spill*(1.-coverage);
      fragColor=vec4(clamp(finalColor,0.,1.),1.);
    }
  `;
  function compile(type, src){
    const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);
    if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){
      throw new Error(gl.getShaderInfoLog(s)||'Erro ao compilar shader');
    }return s;
  }
  function setupGL(){
    if(!gl){gpuBadge.textContent='WebGL2 indisponível';return;}
    try{
      program=gl.createProgram();
      gl.attachShader(program,compile(gl.VERTEX_SHADER,vert));
      gl.attachShader(program,compile(gl.FRAGMENT_SHADER,frag));
      gl.linkProgram(program);
      if(!gl.getProgramParameter(program,gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
      gl.useProgram(program);
      uniforms={};for(const key of ['Image','Res','Center','Half','Light','Radius','Strength','Roll','Chroma','Blur','Shine','Compare'])
        uniforms[key]=gl.getUniformLocation(program,'u'+key);
      vbo=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vbo);
      gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
      const loc=gl.getAttribLocation(program,'position');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
      texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.uniform1i(uniforms.Image,0);
      gpuBadge.textContent='GPU • WEBGL2';
    }catch(err){gpuBadge.textContent='Shader: erro';console.error(err);gl.clearColor(.1,.16,.23,1);gl.clear(gl.COLOR_BUFFER_BIT);}
  }
  const noise = v => (Math.sin(v*129.7)*43758.5453)%1;
  function gradientRect(c,x,y,w,h,colors){let g=c.createLinearGradient(x,y,x,y+h);for(let i=0;i<colors.length;i++)g.addColorStop(i/(colors.length-1),colors[i]);c.fillStyle=g;c.fillRect(x,y,w,h);}
  function landscape(c,w,h){
    gradientRect(c,0,0,w,h,['#8cb6d5','#c2d6cf','#c7bd98','#527b73']);
    // Haze and clouds are drawn as overlapping soft elliptical gradients, not sprites.
    const glow=c.createRadialGradient(w*.74,h*.31,5,w*.74,h*.31,w*.63);
    glow.addColorStop(0,'#fff6db9a');glow.addColorStop(.25,'#fff1d042');glow.addColorStop(1,'#fff6d000');
    c.fillStyle=glow;c.fillRect(0,0,w,h);
    for(let i=0;i<20;i++){
      const xx=w*(.03+(i*67%101)/101),yy=h*(.14+(i*27%47)/130),rx=w*(.045+(i%5)*.015);
      c.save();c.translate(xx,yy);c.scale(1,.31);
      let cg=c.createRadialGradient(0,0,0,0,0,rx);cg.addColorStop(0,'#ffffff59');cg.addColorStop(.8,'#f8ffff11');cg.addColorStop(1,'#ffffff00');c.fillStyle=cg;c.beginPath();c.arc(0,0,rx,0,Math.PI*2);c.fill();c.restore();
    }
    function ridge(base, amp, freq, color){c.beginPath();c.moveTo(0,h);
      for(let x=0;x<=w+4;x+=4){let n=Math.sin(x/w*freq*6.28)*amp+Math.sin(x/w*freq*13.2)*amp*.3;
        const yy=h*(base+n);if(x===0)c.lineTo(0,yy);else c.lineTo(x,yy)}
      c.lineTo(w,h);c.closePath();c.fillStyle=color;c.fill();}
    ridge(.49,.06,1.3,'#71898a');ridge(.59,.045,2.2,'#446b63');ridge(.71,.06,2.7,'#315d46');
    c.save();c.beginPath();c.moveTo(w*.31,h);c.bezierCurveTo(w*.53,h*.72,w*.67,h*.59,w*.74,h*.59);
    c.bezierCurveTo(w*.69,h*.74,w*.66,h*.81,w*.79,h);c.closePath();
    let river=c.createLinearGradient(0,h*.6,w,h);river.addColorStop(0,'#457882');river.addColorStop(.48,'#b4c8b2');river.addColorStop(1,'#2c5c65');c.fillStyle=river;c.fill();
    c.clip();for(let k=0;k<50;k++){const y=h*(.59+.41*k/50),x=w*(.4+(Math.sin(k*.7)*.18)),ww=w*(.04+(k/50)*.12);
      c.strokeStyle=`rgba(222,239,224,${.025+(.13*k/50)})`;c.lineWidth=1+k/50*1.5;c.beginPath();c.moveTo(x-ww/2,y);c.lineTo(x+ww/2,y);c.stroke();}c.restore();
    // Trees are soft organic masses, no voxel/pixel texture.
    for(let i=0;i<48;i++){
      const x=w*((i*37%103)/103),y=h*(.59+.13*Math.sin(i*2.7)*.5),r=h*(.035+(i%7)*.004);
      c.fillStyle='rgba(26,64,49,.20)';c.fillRect(x-r*.08,y,r*.16,r*1.4);
      const foliage=c.createRadialGradient(x-r*.2,y-r*.14,r*.02,x,y,r);
      foliage.addColorStop(0,'#70996c');foliage.addColorStop(.65,'#456b4f');foliage.addColorStop(1,'#26513c00');
      c.fillStyle=foliage;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();
    }
    const vignette=c.createRadialGradient(w*.5,h*.46,h*.11,w*.5,h*.45,h*.95);vignette.addColorStop(0,'#10262900');vignette.addColorStop(1,'#091726a6');c.fillStyle=vignette;c.fillRect(0,0,w,h);
  }
  function typography(c,w,h){
    gradientRect(c,0,0,w,h,['#121c2c','#101727','#1a3040']);
    let g=c.createRadialGradient(w*.6,h*.48,0,w*.5,h*.45,w*.75);g.addColorStop(0,'#548eb548');g.addColorStop(1,'#0c152000');c.fillStyle=g;c.fillRect(0,0,w,h);
    c.textAlign='center';
    for(let j=0;j<6;j++){
      let y=h*(.20+j*.11);c.fillStyle=j===2?'rgba(238,249,255,.94)':'rgba(215,238,248,.36)';
      c.font=`${Math.min(65,w*.095)}px system-ui, sans-serif`;
      c.fillText(['REFRAÇÃO REAL','ARRASTE A LENTE','A LUZ MUDA DE DIREÇÃO','SEM IMAGEM PRONTA','O FUNDO SE DEFORMA','GLASS LAB'][j],w*.50,y);
    }
  }
  function grid(c,w,h){
    gradientRect(c,0,0,w,h,['#0c1526','#111f32','#16293b']);
    c.lineWidth=1;
    const step=Math.min(58,Math.max(30,w/13));
    for(let x=0;x<w;x+=step){c.beginPath();c.strokeStyle='rgba(201,237,255,.30)';c.moveTo(x,0);c.lineTo(x,h);c.stroke();}
    for(let y=0;y<h;y+=step){c.beginPath();c.strokeStyle='rgba(201,237,255,.30)';c.moveTo(0,y);c.lineTo(w,y);c.stroke();}
    for(let x=step;x<w;x+=step*2){for(let y=step;y<h;y+=step*2){c.strokeStyle='#d0efff66';c.strokeRect(x-5,y-5,10,10);}}
    c.lineWidth=2;c.strokeStyle='rgba(183,225,245,.6)';c.beginPath();c.moveTo(w*.13,h*.45);c.lineTo(w*.87,h*.45);c.moveTo(w*.5,h*.09);c.lineTo(w*.5,h*.77);c.stroke();
    c.textAlign='center';c.font=`600 ${Math.max(19,Math.min(48,w/16))}px system-ui`;c.fillStyle='#eef9ff';
    c.fillText('TESTE DE DISTORÇÃO',w/2,h*.29);
  }
  function drawBackground(){
    if(!g2)return;
    const w=scene.width,h=scene.height;
    if(background==='typography')typography(g2,w,h);
    else if(background==='grid')grid(g2,w,h);
    else if(userPhoto&&background==='photo'){
      const i=userPhoto,scale=Math.max(w/i.width,h/i.height),sw=i.width*scale,sh=i.height*scale;
      g2.fillStyle='#162334';g2.fillRect(0,0,w,h);g2.drawImage(i,(w-sw)/2,(h-sh)/2,sw,sh);
      const ov=g2.createLinearGradient(0,0,0,h);ov.addColorStop(0,'#040a168a');ov.addColorStop(.22,'#0611240e');ov.addColorStop(1,'#0108166a');g2.fillStyle=ov;g2.fillRect(0,0,w,h);
    } else landscape(g2,w,h);
    // Calibration typography really lives in the source texture, behind the lens.
    if(background==='landscape'||background==='photo'){
      g2.textAlign='center';g2.textBaseline='middle';
      g2.shadowColor='rgba(0,0,0,.39)';g2.shadowBlur=9*dpr;g2.shadowOffsetY=2*dpr;
      g2.font=`700 ${Math.round(Math.max(23,Math.min(46,w*.065)))}px system-ui`;
      g2.fillStyle='rgba(252,254,255,.89)';g2.fillText('O VIDRO DEFORMA O FUNDO',w*.50,h*.42,w*.92);
      g2.font=`500 ${Math.round(Math.max(11,Math.min(19,w*.026)))}px system-ui`;
      g2.fillStyle='rgba(254,254,255,.81)';g2.fillText('Passe a lente por estas letras e pelas margens da paisagem',w*.50,h*.50,w*.90);
      g2.shadowColor='transparent';g2.shadowBlur=0;g2.shadowOffsetY=0;
    }
    if(gl&&program){
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,scene);
    }
    dirty=true;
  }
  function lensMeasures(){
    const base=Math.min(currentW*.50,Math.max(120,Math.min(currentW*.29,currentH*.31)));
    let radius=base*(.64+params.size/100*.65);
    radius=Math.min(radius,currentH*.32,currentW*.45);
    return shape==='bubble'?{w:radius*2,h:radius*2,r:radius}:
      {w:Math.min(currentW*.77,radius*3.3),h:Math.min(currentH*.26,radius*1.18),r:Math.min(radius*.65,currentH*.13)};
  }
  function clampCenter(){
    const {w,h}=lensMeasures();
    const maxY=Math.max(h*.5+6,currentH-controls.getBoundingClientRect().height-34-h*.5);
    cx=Math.min(Math.max(cx,w*.5+7),currentW-w*.5-7);
    cy=Math.min(Math.max(cy,h*.5+65),maxY);
  }
  function updateLabel(){
    const m=lensMeasures();label.style.width=m.w+'px';label.style.height=m.h+'px';
    label.style.transform=`translate3d(${cx-m.w/2}px,${cy-m.h/2}px,0)`;
    label.style.gap=shape==='bubble'?'2px':'0';
    label.style.flexDirection=shape==='bubble'?'column':'row';
    label.style.fontSize=shape==='bubble'?'18px':'16px';
    label.querySelector('.lens-icon').textContent=shape==='bubble'?'⌂':'▶';
    label.querySelector('.lens-icon').style.fontSize=shape==='bubble'?'38px':'24px';
    label.style.visibility=compare?'hidden':'visible';
  }
  function resize(){
    let oldW=currentW,oldH=currentH;
    currentW=canvas.clientWidth;currentH=canvas.clientHeight;
    dpr=Math.min(devicePixelRatio||1,2);
    canvas.width=Math.floor(currentW*dpr);canvas.height=Math.floor(currentH*dpr);
    scene.width=canvas.width;scene.height=canvas.height;
    if(oldW&&oldH){cx=cx/oldW*currentW;cy=cy/oldH*currentH;}
    else{cx=currentW*.49;cy=Math.min(currentH*.43,currentH-controls.offsetHeight-145);}
    clampCenter();updateLabel();
    if(gl){gl.viewport(0,0,canvas.width,canvas.height);}
    drawBackground();
  }
  function draw(now){
    requestAnimationFrame(draw);
    // No continuous busy-loop. React to gestures and UI adjustments, otherwise
    // update the directional reflection occasionally for a living material.
    if(!dirty && now-previousT<125)return;
    if(!gl||!program)return;
    previousT=now;dirty=false;
    const m=lensMeasures(), px=dpr;
    gl.useProgram(program);
    gl.uniform2f(uniforms.Res,canvas.width,canvas.height);
    gl.uniform2f(uniforms.Center,cx*px,(currentH-cy)*px);
    gl.uniform2f(uniforms.Half,m.w*.5*px,m.h*.5*px);
    gl.uniform1f(uniforms.Radius,m.r*px);
    gl.uniform1f(uniforms.Strength,(params.strength/100)*1.65);
    gl.uniform1f(uniforms.Roll,(7+params.thickness*.35)*px);
    gl.uniform1f(uniforms.Chroma,params.chromatic/100*3.5*px);
    gl.uniform1f(uniforms.Blur,params.blur/100*2.7*px);
    gl.uniform1f(uniforms.Shine,params.shine/100*1.8);
    gl.uniform1f(uniforms.Compare,compare?1:0);
    const phase=now*.0003;
    gl.uniform2f(uniforms.Light,Math.cos(phase)*.17-.68,Math.sin(phase)*.17+.72);
    gl.drawArrays(gl.TRIANGLES,0,6);
    if(++drawCount%90===0){
      if(now-sampleTime>0&&gpuBadge.textContent.startsWith('GPU'))gpuBadge.textContent='GPU • WEBGL2';
      sampleTime=now;
    }
  }
  function pointerPosition(event){const r=canvas.getBoundingClientRect();return{x:event.clientX-r.left,y:event.clientY-r.top};}
  canvas.addEventListener('pointerdown',event=>{
    if(event.button!==0&&event.pointerType==='mouse')return;
    const p=pointerPosition(event),m=lensMeasures();
    const near=Math.abs(p.x-cx)<m.w/2+18&&Math.abs(p.y-cy)<m.h/2+18;
    moveOffsetX=near?cx-p.x:0;moveOffsetY=near?cy-p.y:0;
    cx=p.x+moveOffsetX;cy=p.y+moveOffsetY;clampCenter();
    dragging=true;canvas.classList.add('dragging');canvas.setPointerCapture(event.pointerId);
    $('dragHint').classList.add('gone');updateLabel();dirty=true;
  });
  canvas.addEventListener('pointermove',event=>{
    if(!dragging)return;
    const p=pointerPosition(event);cx=p.x+moveOffsetX;cy=p.y+moveOffsetY;
    clampCenter();updateLabel();dirty=true;
  });
  function stop(event){dragging=false;canvas.classList.remove('dragging');dirty=true;}
  canvas.addEventListener('pointerup',stop);canvas.addEventListener('pointercancel',stop);canvas.addEventListener('lostpointercapture',stop);
  function bindSlider(id){
    const el=$(id),out=$(id+'Value');
    const fn=()=>{params[id]=Number(el.value);out.textContent=el.value+'%';clampCenter();updateLabel();dirty=true;};
    el.addEventListener('input',fn);fn();
  }
  Object.keys(params).forEach(bindSlider);
  document.querySelectorAll('[data-scene]').forEach(b=>b.addEventListener('click',()=>{
    background=b.dataset.scene;
    document.querySelectorAll('[data-scene]').forEach(x=>x.classList.toggle('selected',x===b));drawBackground();
  }));
  $('photo').addEventListener('click',()=>$('photoFile').click());
  $('photoFile').addEventListener('change',e=>{
    const file=e.target.files&&e.target.files[0];if(!file)return;
    if(!file.type.startsWith('image/'))return;
    const url=URL.createObjectURL(file);const image=new Image();
    image.onload=()=>{userPhoto=image;background='photo';URL.revokeObjectURL(url);document.querySelectorAll('[data-scene]').forEach(b=>b.classList.remove('selected'));$('photo').classList.add('selected');drawBackground();};
    image.onerror=()=>URL.revokeObjectURL(url);image.src=url;
  });
  $('shape').addEventListener('click',()=>{
    shape=shape==='bubble'?'pill':'bubble';$('shape').textContent='Forma: '+(shape==='bubble'?'bolha':'cápsula');clampCenter();updateLabel();dirty=true;
  });
  $('compare').addEventListener('click',()=>{
    compare=!compare;$('compare').classList.toggle('active',compare);
    $('compare').textContent=compare?'Mostrar vidro':'Ver sem vidro';$('compareMark').hidden=!compare;updateLabel();dirty=true;
  });
  $('reset').addEventListener('click',()=>{
    Object.assign(params,{strength:68,thickness:73,chromatic:45,blur:12,shine:62,size:52});
    Object.keys(params).forEach(id=>{$(id).value=params[id];$(id+'Value').textContent=params[id]+'%';});
    shape='bubble';$('shape').textContent='Forma: bolha';compare=false;$('compare').textContent='Ver sem vidro';$('compareMark').hidden=true;
    background='landscape';document.querySelectorAll('[data-scene]').forEach(x=>x.classList.toggle('selected',x.dataset.scene==='landscape'));
    cx=currentW*.49;cy=Math.min(currentH*.43,currentH-controls.offsetHeight-145);clampCenter();updateLabel();drawBackground();
  });
  window.addEventListener('resize',resize);
  window.addEventListener('orientationchange',()=>setTimeout(resize,180));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)dirty=true;});
  canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();gpuBadge.textContent='GPU reiniciando';});
  canvas.addEventListener('webglcontextrestored',()=>{setupGL();resize();});
  setupGL();resize();requestAnimationFrame(draw);
})();
