/* Glass Lab 6.0: true GPU glass/metal materials, restrained particles and style-scoped SFX. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const canvas = $('view'), stage = $('stage'), overlay = $('componentUi');
  const controls = document.querySelector('.controls'), badge = $('gpu');
  const TYPES = [
    { id:'bubble', name:'Bolha', symbol:'◯', subtitle:'Bolha circular', hint:'Arraste a lente sobre o texto e observe a borda.' },
    { id:'square', name:'Quadrado', symbol:'▢', subtitle:'Quadrado arredondado', hint:'Borda com curvatura ajustável e vidro em toda a superfície.' },
    { id:'pill', name:'Cápsula', symbol:'▬', subtitle:'Botão cápsula', hint:'Uma peça de vidro horizontal, arrastável.' },
    { id:'icon', name:'Ícone', symbol:'⌂', subtitle:'Botão de ícone', hint:'Lente compacta como os controles do iOS.' },
    { id:'slider', name:'Slider', symbol:'↔', subtitle:'Controle deslizante', hint:'Arraste o indicador horizontal para alterar o valor.' },
    { id:'scrollbar', name:'Scroll', symbol:'↕', subtitle:'Barra de rolagem', hint:'Arraste o indicador vertical ou role a tela sobre ele.' },
    { id:'switch', name:'Switch', symbol:'⏻', subtitle:'Ligar / desligar', hint:'Toque ou arraste a bolinha; o vidro acompanha o movimento.' },
    { id:'tabs', name:'Abas', symbol:'▤', subtitle:'Navegação por abas', hint:'Toque Home, Mods ou Shaders para mover a seleção.' },
    { id:'chip', name:'Chip', symbol:'◒', subtitle:'Chip de seleção', hint:'Toque para selecionar; o botão responde elasticamente.' },
    { id:'card', name:'Card', symbol:'▣', subtitle:'Cartão de vidro', hint:'Teste o volume e a distorção nas quatro bordas.' },
  ];
  const PARAMS = [
    {id:'thickness',label:'Espessura da borda',min:0,max:100,default:73},
    {id:'depth',label:'Profundidade ±',min:-100,max:100,default:48,hint:'− côncava · + convexa'},
    {id:'lightAngle',label:'Direção da luz',min:0,max:360,default:305,unit:'°'},
    {id:'lightElevation',label:'Altura da luz',min:0,max:100,default:65},
    {id:'shine',label:'Reflexo especular',min:0,max:100,default:62},
    {id:'fresnel',label:'Reflexão Fresnel',min:0,max:100,default:45},
    {id:'gloss',label:'Polimento / nitidez',min:0,max:100,default:70},
    {id:'bloom',label:'Bloom da borda',min:0,max:100,default:35},
    {id:'spill',label:'Vazamento de luz',min:0,max:100,default:42},
    {id:'chromatic',label:'Aberração cromática',min:0,max:100,default:45},
    {id:'blur',label:'Dispersão / desfoque',min:0,max:100,default:12},
    {id:'tint',label:'Coloração do vidro',min:0,max:100,default:11},
    {id:'shadow',label:'Sombra de contato',min:0,max:100,default:40},
    {id:'size',label:'Tamanho do componente',min:0,max:100,default:52},
    {id:'stretch',label:'Elasticidade / esticar',min:0,max:100,default:38},
    {id:'speed',label:'Resposta / rigidez da mola',min:0,max:100,default:65},
    {id:'viscosity',label:'Viscosidade do arrasto',min:0,max:100,default:52},
    {id:'bounce',label:'Rebote da mola',min:0,max:100,default:28},
    {id:'pressDepth',label:'Profundidade do toque',min:0,max:100,default:40},
    {id:'indicatorOpacity',label:'Opacidade do indicador',min:30,max:100,default:93,hint:'Indicadores sólidos; não altera a bolha de vidro'},
    {id:'trackContrast',label:'Contraste da trilha',min:0,max:100,default:65,hint:'Diferencia o canal do indicador'},
    // Real GPU materials exclusive to Old School, saved per component.
    {id:'retroMetal',label:'Old School · Metalização',min:0,max:100,default:56,retroOnly:true},
    {id:'retroGrain',label:'Old School · Microtextura',min:0,max:100,default:30,retroOnly:true},
    {id:'retroAero',label:'Old School · Reflexos Aero',min:0,max:100,default:53,retroOnly:true},
    {id:'retroChrome',label:'Old School · Espelho cromado',min:0,max:100,default:86,retroOnly:true},
    {id:'retroEdge',label:'Old School · Bevel 3D e bordas',min:0,max:100,default:77,retroOnly:true},
    {id:'retroAccent',label:'Old School · Reflexo esverdeado',min:0,max:100,default:16,retroOnly:true},
  ];
  const DEFAULTS = Object.freeze({strength:68,...Object.fromEntries(PARAMS.map(p=>[p.id,p.default]))});
  const STYLES={
    liquid:{name:'Liquid Glass',description:'Vidro óptico e física de gel: arrastar, pressionar e deslizar têm respostas próprias.',icon:'◉'},
    oldschool:{name:'Old School',description:'Dark Aero real: cromado preto, bevel 3D, reflexos de estúdio e brilho orientado pela luz.',icon:'▣'}
  };
  const makePreset = (id,style='liquid') => ({...DEFAULTS,
    ...(style==='oldschool'?{strength:29,thickness:68,depth:48,lightAngle:305,
      lightElevation:62,shine:70,fresnel:66,gloss:90,bloom:19,spill:24,chromatic:2,
      blur:1,tint:0,shadow:30,stretch:10,speed:82,viscosity:83,bounce:3,pressDepth:24,
      indicatorOpacity:91,trackContrast:43,retroMetal:75,retroGrain:14,retroAero:58,retroChrome:90,retroEdge:79,retroAccent:12}:{}),
    size: id==='scrollbar'?43:id==='card'?62:id==='tabs'?55:52,
    motion:true, particlesEnabled:style==='oldschool' && ['slider','scrollbar'].includes(id),
    metalThumb:style==='oldschool' && ['slider','scrollbar'].includes(id),
    retroFinish:style==='oldschool'?0:2, value:id==='switch'?1:.52, tabIndex:0,selected:false,
    xNorm:.48,yNorm:.49,
  });
  const makeStylePresets=style=>Object.fromEntries(TYPES.map(t=>[t.id,makePreset(t.id,style)]));
  let stylePresets={liquid:makeStylePresets('liquid'),oldschool:makeStylePresets('oldschool')};
  // A single, live material per style. Changes in one button update ALL ten
  // controls of that style; geometry, size and motion remain component-specific.
  const GLOBAL_LOOK=new Set([
    'strength','thickness','depth','lightAngle','lightElevation','shine',
    'fresnel','gloss','bloom','spill','chromatic','blur','tint','shadow',
    'indicatorOpacity','trackContrast','retroMetal','retroGrain','retroAero',
    'retroChrome','retroEdge','retroAccent','retroFinish'
  ]);
  function sharedLook(style){
    const source=stylePresets[style].bubble,look={};
    for(const key of GLOBAL_LOOK)look[key]=source[key];
    return look;
  }
  function setGlobalLook(style,key,value){
    if(!GLOBAL_LOOK.has(key))return false;
    for(const type of TYPES)stylePresets[style][type.id][key]=value;
    return true;
  }
  function unifyStyleLook(style,sourceType='bubble'){
    const source=stylePresets[style][sourceType]||stylePresets[style].bubble;
    for(const key of GLOBAL_LOOK)setGlobalLook(style,key,source[key]);
  }
  // The entire SFX mix and particle identity belong to a *style*, never to
  // a component. Each component can independently opt into the emitted sparks.
  const makeFX=style=>({particleEnabled:style==='oldschool',intensity:style==='oldschool'?34:20,
    audioEnabled:true,primary:style==='oldschool'?'retro':'modern',
    secondary:style==='oldschool'?'ultimate-ui':'minimalist',
    mixEnabled:false,blend:35,volume:32});
  let fxProfiles={liquid:makeFX('liquid'),oldschool:makeFX('oldschool')};
  const fx=()=>fxProfiles[currentStyle];
  const sfx=(event,force=false)=>window.GlassLabAudio?.play(currentStyle,event,fx(),force);
  function particleEmit(pt,dx,dy,kind='spark'){
    if(!fx().particleEnabled||!p().particlesEnabled||compare)return;
    window.GlassLabParticles?.emit(pt.x,pt.y,dx,dy,currentStyle,fx().intensity,
      currentStyle==='oldschool'?'spark':'glint');
  }
  let currentStyle='liquid', presets=stylePresets.liquid;
  let currentType='bubble', background='landscape', userPhoto=null, compare=false;
  let w=0,h=0,dpr=1,cx=0,cy=0,previewW=0,previewH=0,minY=0,maxY=0;
  let dragging=false,pointerDown=false,dragOffset={x:0,y:0},lastPoint=null,velocity=0;
  let springValue=.52,springSpeed=0,dirty=true,prevFrame=0;
  // The physics simulation is independent of the visual shader. Every part has
  // its own DOF: drag gel tail (xy), press depth (z), and indicator travel.
  const motion={dragX:0,dragY:0,vx:0,vy:0,press:0,pressV:0,
    pressTarget:0,interactive:false,dragMoved:false,feedback:0};
  const clamp=(v,min,max)=>Math.min(max,Math.max(min,v));
  const pressable=()=>['square','pill','icon','chip','card'].includes(currentType);
  const dragBody=()=>['bubble','square','pill','icon','card'].includes(currentType);
  const tracking=()=>['slider','scrollbar','switch','tabs'].includes(currentType);
  function applyStyle(){
    document.body.dataset.style=currentStyle;
    const info=STYLES[currentStyle];
    $('switchStyle').innerHTML=`<span aria-hidden="true">${info.icon}</span> ${info.name}`;
    $('switchStyle').setAttribute('aria-label','Estilo atual: '+info.name+'. Trocar estilo');
    $('styleDescription').textContent=info.description;
    $('styleName').textContent=info.name;
    $('advanced').open=false;
    $('presetStatus').textContent='Presets separados para '+info.name;
    $('retroFinish').closest('.retro-materials').hidden=currentStyle!=='oldschool';
    if($('fxPanel'))syncFX();
  }
  function switchStyle(){
    const old=currentStyle;
    p().xNorm=cx/Math.max(previewW,1);p().yNorm=cy/Math.max(previewH,1);
    stylePresets[old]=presets;
    currentStyle=old==='liquid'?'oldschool':'liquid';
    presets=stylePresets[currentStyle];
    springValue=p().value;springSpeed=0;
    Object.assign(motion,{dragX:0,dragY:0,vx:0,vy:0,press:0,pressV:0,pressTarget:0,interactive:false,dragMoved:false});
    if(background==='landscape' && currentStyle==='oldschool')background='aero';
    else if(background==='aero' && currentStyle==='liquid')background='landscape';
    applyStyle();typeChange(currentType,false);constrain();syncSliders();setBackgroundButtons();drawBackground();store();dirty=true;
  }
  let gl,program,texture,buffers={},uniforms={},shaderReady=false;
  const p=()=>presets[currentType];
  const scene=document.createElement('canvas');
  const g2=scene.getContext('2d',{alpha:false});
  try{gl=canvas.getContext('webgl2',{alpha:false,antialias:true,powerPreference:'high-performance'});}catch(err){gl=null;}
  const VERT=`#version 300 es
precision highp float;
in vec2 position;
void main(){gl_Position=vec4(position,0.0,1.0);}`;
  const FRAG=`#version 300 es
precision highp float;
out vec4 fragColor;
uniform sampler2D uImage;
uniform vec2 uRes;
uniform int uCount;
uniform vec4 uParts[4]; // centre.xy and halfExtent.zw in framebuffer pixels (bottom-left origin)
uniform vec4 uMeta[4];  // cornerRadius, opticalFactor, opacity, unused
uniform vec4 uFill[4];  // selective material pigmentation + opacity
uniform vec4 uDynamics[4]; // trailing gel.xy, press depth.z, reserved.w
uniform int uStyle;         // 0: liquid dielectric, 1: retro satin/chrome
uniform vec2 uLight;
uniform float uElevation;
uniform float uStrength;
uniform float uRoll;
uniform float uChroma;
uniform float uBlur;
uniform float uShine;
uniform float uDepth;
uniform float uFresnel;
uniform float uGloss;
uniform float uBloom;
uniform float uSpill;
uniform float uTint;
uniform float uShadow;
uniform float uCompare;
// Independent console shader uniforms: four physical surface families.
uniform int uRetroFinish; // 0: graphite satin, 1: PS3 pearl, 2: translucent aero, 3: brushed chrome
uniform float uRetroMetal;
uniform float uRetroGrain;
uniform float uRetroAero;
uniform float uRetroChrome;
uniform float uRetroEdge;
uniform float uRetroAccent;
uniform float uTime;
vec3 sampleScene(vec2 xy){
  return texture(uImage, clamp(xy/uRes, vec2(.001), vec2(.999))).rgb;
}
vec2 normalFor(vec2 loc,vec2 halfSize,float radius){
  vec2 q=abs(loc)-halfSize+vec2(radius);
  vec2 ext=max(q,vec2(0.));
  if(length(ext)>.0001) return normalize(ext)*sign(loc);
  if(q.x>q.y) return vec2(sign(loc.x),0.);
  return vec2(0.,sign(loc.y));
}

// Dark Aero / 2006–2012 console lacquer: physical screen-space fake-3D.
// Actual per-fragment normals, Snell transmission, GGX metallic reflectance,
// analytic studio stripboxes and environment probes from the live backdrop.
float ggxDistribution(float nDotH,float rough){
  float a=rough*rough;float a2=a*a;
  float den=nDotH*nDotH*(a2-1.)+1.;
  return a2/max(3.14159265*den*den,.00008);
}
vec3 shadeConsole(int finish,vec2 pos,vec2 loc,vec2 outward,vec2 halfSize,
                  float radius,float depth,float press,float tailEnergy,
                  vec4 fillColor,vec3 sceneColor){
  // A thin physically curved face, followed by a flat, polished central slab.
  float roll=max(1.2,min(radius*.98,uRoll*(.48+uRetroEdge*.45)));
  float slope=pow(clamp(1.-depth/roll,0.,1.),.72);
  float front=sqrt(max(1.-slope*slope,.0005));
  float polarity=sign(uDepth);
  vec3 N=normalize(vec3(outward*slope*polarity,front));
  vec3 V=vec3(0.,0.,1.);
  vec3 L=normalize(vec3(uLight,max(.25,uElevation)));
  vec3 H=normalize(L+V);
  float nv=max(dot(N,V),.003);
  float nl=max(dot(N,L),.002);
  float nh=max(dot(N,H),0.);
  float metallic=clamp(uRetroMetal,0.,1.);
  float chrome=clamp(uRetroChrome,0.,1.);
  float aero=clamp(uRetroAero,0.,1.);
  float edge=exp(-depth/max(1.2,roll*.11));
  float inner=exp(-pow((depth-roll*.64)/max(1.,roll*.17),2.));
  // Tiny normal-angle anisotropy from real microgrooves (brushed steel only).
  float grain=sin(pos.y*.77+sin(pos.x*.12)*.14)*.58
       +sin(pos.y*2.21+pos.x*.013)*.20;
  float brush=(finish==3?uRetroGrain:0.)*grain;
  N=normalize(N+vec3(0.,brush*.085,0.));
  float rough=clamp(mix(.40,.085,uGloss)+uRetroGrain*.08,.06,.48);
  float D=ggxDistribution(max(dot(N,H),0.),rough);
  float k=rough*rough*.5;
  float geometry=(nv/(nv*(1.-k)+k))*(nl/(nl*(1.-k)+k));
  float GGX=clamp(D*geometry/max(4.*nv,.01),0.,15.);
  // Black lacquer is genuinely near-black; reflectance and white ribbons,
  // not an opaque dull gray tint, define its perceived three-dimensionality.
  vec3 base=vec3(.010,.012,.019);
  vec3 F0=vec3(.034);
  float transmit=.065;
  if(finish==1){base=vec3(.080,.089,.108);F0=vec3(.24,.25,.29);transmit=.16;}
  if(finish==2){base=vec3(.024,.037,.049);F0=vec3(.039);transmit=.72;}
  if(finish==3){base=vec3(.068,.072,.081);F0=vec3(.42,.43,.46);transmit=.035;}
  vec3 F=F0+(vec3(1.)-F0)*pow(1.-nv,5.);
  vec3 T=refract(vec3(0.,0.,-1.),N,1./(finish==2?1.49:1.55));
  float thick=(2.8+roll*.91)*(.42+abs(uDepth));
  vec2 displacement=T.xy/max(-T.z,.16)*thick*uStrength*.93;
  float maxOffset=min(min(halfSize.x,halfSize.y)*.58,45.);
  displacement*=min(1.,maxOffset/max(length(displacement),.001));
  vec3 transmitted=sampleScene(pos+displacement);
  vec3 reflectedRay=reflect(vec3(0.,0.,-1.),N);
  vec2 reflectOffset=reflectedRay.xy*(17.+roll*.76);
  vec3 backdropReflection=sampleScene(pos+reflectOffset);
  // Analytic white strip-softboxes in the material's environment. They follow
  // the *surface normal* and directed light, not static painted strokes.
  vec3 studioA=normalize(vec3(-.75,.34,1.35));
  vec3 studioB=normalize(vec3(.64,-.37,1.07));
  vec3 halfA=normalize(studioA+V);
  vec3 halfB=normalize(studioB+V);
  float stripA=pow(max(dot(N,halfA),0.),mix(16.,97.,uGloss));
  float stripB=pow(max(dot(N,halfB),0.),mix(22.,140.,uGloss));
  // Wide reflection sweep across convex top, brightest on rolled chrome edges.
  float arc=pow(max(dot(outward,normalize(vec2(-.70,.71))),0.),4.);
  float verticalBand=pow(max(1.-abs(N.y+.10)*1.14,0.),13.);
  float horizontalBand=pow(max(1.-abs(N.x-.17)*1.22,0.),17.);
  float studio=clamp(stripA*.64+stripB*.57+verticalBand*.18+horizontalBand*.14,0.,1.);
  // Hollow-looking edge for a rounded embossed fake-3D physical surface.
  float rimKey=pow(max(dot(outward,normalize(vec2(-.74,-.67))),0.),7.);
  float rimFill=pow(max(dot(outward,normalize(vec2(.68,.72))),0.),11.);
  float rimGlow=(rimKey*.65+rimFill*.36)*edge;
  float insideShade=(1.-front)*.19+inner*.12*(1.-rimKey);
  // Real anisotropic microfacet + Fresnel, with a monochrome cold studio light.
  vec3 microSpec=F*GGX*min(1.2,uShine)*(.31+.35*chrome);
  vec3 env=mix(vec3(.10,.13,.18),backdropReflection,.70);
  float reflectWeight=clamp(.25+.56*chrome+.23*metallic,0.,.97);
  vec3 reflected=env*reflectWeight*F;
  vec3 col=mix(base,transmitted,transmit);
  if(finish==2){
    // Aero acrylic is genuinely refractive and stays transparent at its centre.
    col=mix(transmitted,vec3(.09,.12,.16),.10+uTint*.12);
    reflected*=.69;
  }else{
    col+=reflected*.95;
    col+=backdropReflection*(.10+.15*chrome)*max(nv,.10);
  }
  col*=1.-insideShade;
  col+=microSpec;
  col+=vec3(.98,.985,1.)*studio*(.13+.56*chrome)*uShine;
  col+=vec3(.92,.95,1.)*(rimGlow*(.16+.51*uRetroEdge)+inner*.065);
  // Chrome is nearly black at the bottom and gleaming on upper edge.
  col+=vec3(.34,.37,.41)*verticalBand*.12*chrome;
  col+=vec3(.17,.21,.27)*brush*(finish==3?.08:0.);
  // Optional green/cyan instrumentation reflection (Xbox-era nod), not neon.
  vec3 accent=vec3(.13,.62,.32)*uRetroAccent;
  col+=accent*(rimFill*edge*.28+inner*.09);
  // Press changes shape and reflective slope; focus feedback is restrained.
  col*=1.-press*.13;
  col+=vec3(.84,.90,.98)*clamp(tailEnergy,0.,1.)*.031*edge;
  if(fillColor.a>0.){
    float tintFactor=fillColor.a*(finish==2?.36:.30);
    col=mix(col,fillColor.rgb,tintFactor);
  }
  return clamp(col,vec3(0.),vec3(1.));
}

void main(){
  vec2 pos=gl_FragCoord.xy;
  vec3 src=sampleScene(pos);
  // Keep scene detail; the retro shader itself supplies true optical material.
  if(uCompare>.5){fragColor=vec4(src,1.);return;}
  vec3 accum=src;
  for(int i=0;i<4;i++){
    if(i>=uCount)break;
    vec2 center=uParts[i].xy;
    vec2 halfSize=max(uParts[i].zw,vec2(1.));
    float press=clamp(uDynamics[i].z,0.,1.);
    halfSize*=vec2(1.-press*.035,1.-press*.082);
    float radius=clamp(uMeta[i].x,.5,min(halfSize.x,halfSize.y));
    vec2 loc=pos-center;
    // Directional gel, not a symmetric squish: only the trailing half moves.
    // Positive drag along +X extends the left wall, preserving the leading edge.
    vec2 tail=uDynamics[i].xy;
    float tailLength=length(tail);
    if(tailLength>.01){
      vec2 direction=tail/max(tailLength,.001);
      float back=clamp(-dot(loc,direction)/max(dot(halfSize,abs(direction)),1.),0.,1.);
      loc+=tail*pow(back,1.25);
    }
    vec2 q=abs(loc)-halfSize+vec2(radius);
    float d=length(max(q,vec2(0.)))+min(max(q.x,q.y),0.)-radius;
    if(d>34.) continue;
    float aa=max(fwidth(d),.90);
    float mask=1.-smoothstep(-aa,aa,d);
    vec2 outward=normalFor(loc,halfSize,radius);
    float strength=uStrength*uMeta[i].y;
    float haloR=7.+uBloom*13.;
    float shade=max(d,0.);
    float keyAngle=max(dot(outward,uLight),0.);
    float fillAngle=max(dot(outward,-uLight),0.);
    float glow=exp(-pow(shade/max(haloR,.5),2.))*pow(keyAngle,8.)*(uBloom*.24);
    float shadow=exp(-shade/9.)*.29*uShadow*(1.-smoothstep(18.,33.,shade));
    if(mask<.001){
      accum=clamp(accum*(1.-shadow)+vec3(.68,.87,1.)*glow,0.,1.);
      continue;
    }
    float depth=max(-d,0.);
    if(uStyle==1){
      float energy=length(tail)/max(length(halfSize),1.)+uDynamics[i].w*.30;
      // Explicitly solid brushed-metal thumb without changing its translucent track.
      int effectiveFinish=uMeta[i].w>.5?3:uRetroFinish;
      vec3 retro=shadeConsole(effectiveFinish,pos,loc,outward,halfSize,radius,depth,press,
        energy,uFill[i],src);
      // Microfacet metal and acrylic are shaded physically, then composited
      // with the real backdrop. No faux frosted color layer.
      float opacity=clamp(uMeta[i].z*(effectiveFinish==2?.83:1.),0.,1.);
      accum=mix(accum,retro,mask*opacity);
      float contact=exp(-max(d,0.)/7.)*.18*uShadow;
      accum*=1.-contact*(1.-mask);
      accum+=vec3(.76,.82,.90)*glow*(1.-mask)*.44;
      continue;
    }
    float roll=max(1.,min(radius*.98,uRoll));
    float curved=pow(clamp(1.-depth/roll,0.,1.),.71);
    float front=sqrt(max(1.-curved*curved,.0007));
    // Concave presets reverse the lateral surface normal and ray deflection.
    float polarity=abs(uDepth)<.008 ? 0. : sign(uDepth);
    vec3 surfaceNormal=normalize(vec3(outward*curved*polarity,front));
    vec3 ray=refract(vec3(0.,0.,-1.),surfaceNormal,1./1.48);
    float signedDepth=abs(uDepth);
    float medium=(roll*.64+4.)*(.38+signedDepth*.96);
    vec2 bend=ray.xy/max(-ray.z,.16)*medium*strength;
    bend-=loc/max(halfSize,vec2(1.))*(1.-curved)*strength*1.05*polarity;
    float maxBend=min(min(halfSize.x,halfSize.y)*.73,11.+strength*38.);
    bend*=min(1.,maxBend/max(length(bend),.001));
    vec2 lookup=pos+bend;
    vec3 col=sampleScene(lookup);
    float blur=uBlur*(.12+curved*curved)*1.25;
    if(blur>.20){
      vec2 offs=vec2(blur,blur*.66);
      col=col*.40+(sampleScene(lookup+offs)+sampleScene(lookup-offs)
       +sampleScene(lookup+vec2(offs.x,-offs.y))
       +sampleScene(lookup+vec2(-offs.x,offs.y)))*.15;
    }
    float fringe=uChroma*curved*curved;
    if(fringe>.07){
      vec2 chroma=outward*fringe;
      col.r=mix(col.r,sampleScene(lookup+chroma).r,.78);
      col.b=mix(col.b,sampleScene(lookup-chroma).b,.78);
    }
    float fresnel=.038+.962*pow(1.-max(front,0.),5.);
    vec3 environment=sampleScene(pos+outward*(7.+roll*.14));
    col=mix(col,mix(vec3(.66,.81,.92),environment,.50),clamp(fresnel*uFresnel*.82,0.,.62));
    vec3 key=normalize(vec3(uLight,uElevation));
    vec3 fill=normalize(vec3(-uLight*.7,.82));
    vec3 h1=normalize(key+vec3(0.,0.,1.));
    vec3 h2=normalize(fill+vec3(0.,0.,1.));
    float exponent=mix(20.,180.,uGloss);
    float spec=pow(max(dot(surfaceNormal,h1),0.),exponent)*.48
      +pow(max(dot(surfaceNormal,h2),0.),exponent*1.55)*.24;
    float edgeBright=pow(keyAngle,8.)*exp(-depth/3.2)*.54;
    float caustic=exp(-pow((depth-roll*.57)/max(1.,roll*.18),2.))
      *pow(fillAngle,3.)*.14;
    vec3 bleed=sampleScene(pos+outward*max(4.,roll*.39));
    col+=bleed*(curved*curved*.07+caustic*.15)*uSpill;
    float highlight=clamp((spec+edgeBright+caustic)*uShine,0.,.82);
    col=mix(col,vec3(.97,.988,1.),highlight);
    col=mix(col,vec3(.75,.87,.95),curved*.13*uTint);
    // Only functional tracks/indicators receive pigment; free glass buttons
    // retain their original transparent refraction. Apply prior to compositing
    // so the thumb is drawn in front of its track, never merged into the glass.
    if(uStyle==0) col=mix(col,uFill[i].rgb,clamp(uFill[i].a,0.,1.)*(1.-.11*curved));
    float opacity=clamp(uMeta[i].z,0.,1.);
    // Old School opacity is handled in shadeConsole. This pass is Liquid only.
    accum=mix(accum,col,mask*opacity);
    accum=clamp(accum-accum*shadow*(1.-mask),0.,1.);
    accum=clamp(accum+vec3(.62,.80,1.)*glow*(1.-mask),0.,1.);
  }
  fragColor=vec4(clamp(accum,0.,1.),1.);
}`;
  function compileShader(type,code){
    const shader=gl.createShader(type);
    gl.shaderSource(shader,code);gl.compileShader(shader);
    if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(shader));
    return shader;
  }
  function initGL(){
    shaderReady=false;
    if(!gl){badge.textContent='WebGL2 indisponível';return;}
    try{
      const vs=compileShader(gl.VERTEX_SHADER,VERT),fs=compileShader(gl.FRAGMENT_SHADER,FRAG);
      program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);
      gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
      gl.useProgram(program);
      const names=['Image','Res','Count','Parts[0]','Meta[0]','Fill[0]','Dynamics[0]','Style','Light','Elevation','Strength','Roll','Chroma','Blur','Shine','Depth','Fresnel','Gloss','Bloom','Spill','Tint','Shadow','Compare','RetroFinish','RetroMetal','RetroGrain','RetroAero','RetroChrome','RetroEdge','RetroAccent','Time'];
      for(const id of names){uniforms[id]=gl.getUniformLocation(program,'u'+id);}
      buffers.quad=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffers.quad);
      gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
      const attr=gl.getAttribLocation(program,'position');gl.enableVertexAttribArray(attr);
      gl.vertexAttribPointer(attr,2,gl.FLOAT,false,0,0);
      texture=gl.createTexture();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.uniform1i(uniforms.Image,0);
      shaderReady=true;badge.textContent='GPU · shaders físicos';dirty=true;
    }catch(err){console.error('Glass Lab GLSL:',err);badge.textContent='Erro no shader';}
  }

  function gradientRect(c,x,y,w,h,colors){let g=c.createLinearGradient(x,y,x,y+h);for(let i=0;i<colors.length;i++)g.addColorStop(i/(colors.length-1),colors[i]);c.fillStyle=g;c.fillRect(x,y,w,h);}
  function landscape(c,w,h){
    gradientRect(c,0,0,w,h,['#8cb6d5','#c2d6cf','#c7bd98','#527b73']);
    // Haze and clouds are drawn as overlapping soft elliptical gradients, not sprites.
    const glow=c.createRadialGradient(w*.74,h*.31,5,w*.74,h*.31,w*.63);
    glow.addColorStop(0,'#fff6db9a');glow.addColorStop(.25,'#fff1d042');glow.addColorStop(1,'#fff6d000');
    c.fillStyle=glow;c.fillRect(0,0,w,h);
    for(let i=0;i<20;i++){
      const xx=w*(.03+(i*67%101)/101),yy=h*(.14+(i*27%47)/130),rx=w*(.045+(i%5)*.015);
      c.save();c.translate(xx,yy);c.scale(1,.31);
      let cg=c.createRadialGradient(0,0,0,0,0,rx);cg.addColorStop(0,'#ffffff59');cg.addColorStop(.8,'#f8ffff11');cg.addColorStop(1,'#ffffff00');c.fillStyle=cg;c.beginPath();c.arc(0,0,rx,0,Math.PI*2);c.fill();c.restore();
    }
    function ridge(base, amp, freq, color){c.beginPath();c.moveTo(0,h);
      for(let x=0;x<=w+4;x+=4){let n=Math.sin(x/w*freq*6.28)*amp+Math.sin(x/w*freq*13.2)*amp*.3;
        const yy=h*(base+n);if(x===0)c.lineTo(0,yy);else c.lineTo(x,yy)}
      c.lineTo(w,h);c.closePath();c.fillStyle=color;c.fill();}
    ridge(.49,.06,1.3,'#71898a');ridge(.59,.045,2.2,'#446b63');ridge(.71,.06,2.7,'#315d46');
    c.save();c.beginPath();c.moveTo(w*.31,h);c.bezierCurveTo(w*.53,h*.72,w*.67,h*.59,w*.74,h*.59);
    c.bezierCurveTo(w*.69,h*.74,w*.66,h*.81,w*.79,h);c.closePath();
    let river=c.createLinearGradient(0,h*.6,w,h);river.addColorStop(0,'#457882');river.addColorStop(.48,'#b4c8b2');river.addColorStop(1,'#2c5c65');c.fillStyle=river;c.fill();
    c.clip();for(let k=0;k<50;k++){const y=h*(.59+.41*k/50),x=w*(.4+(Math.sin(k*.7)*.18)),ww=w*(.04+(k/50)*.12);
      c.strokeStyle=`rgba(222,239,224,${.025+(.13*k/50)})`;c.lineWidth=1+k/50*1.5;c.beginPath();c.moveTo(x-ww/2,y);c.lineTo(x+ww/2,y);c.stroke();}c.restore();
    // Trees are soft organic masses, no voxel/pixel texture.
    for(let i=0;i<48;i++){
      const x=w*((i*37%103)/103),y=h*(.59+.13*Math.sin(i*2.7)*.5),r=h*(.035+(i%7)*.004);
      c.fillStyle='rgba(26,64,49,.20)';c.fillRect(x-r*.08,y,r*.16,r*1.4);
      const foliage=c.createRadialGradient(x-r*.2,y-r*.14,r*.02,x,y,r);
      foliage.addColorStop(0,'#70996c');foliage.addColorStop(.65,'#456b4f');foliage.addColorStop(1,'#26513c00');
      c.fillStyle=foliage;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();
    }
    const vignette=c.createRadialGradient(w*.5,h*.46,h*.11,w*.5,h*.45,h*.95);vignette.addColorStop(0,'#10262900');vignette.addColorStop(1,'#091726a6');c.fillStyle=vignette;c.fillRect(0,0,w,h);
  }
  function typography(c,w,h){
    gradientRect(c,0,0,w,h,['#121c2c','#101727','#1a3040']);
    let g=c.createRadialGradient(w*.6,h*.48,0,w*.5,h*.45,w*.75);g.addColorStop(0,'#548eb548');g.addColorStop(1,'#0c152000');c.fillStyle=g;c.fillRect(0,0,w,h);
    c.textAlign='center';
    for(let j=0;j<6;j++){
      let y=h*(.20+j*.11);c.fillStyle=j===2?'rgba(238,249,255,.94)':'rgba(215,238,248,.36)';
      c.font=`${Math.min(65,w*.095)}px system-ui, sans-serif`;
      c.fillText(['REFRAÇÃO REAL','ARRASTE A LENTE','A LUZ MUDA DE DIREÇÃO','SEM IMAGEM PRONTA','O FUNDO SE DEFORMA','GLASS LAB'][j],w*.50,y);
    }
  }
  function grid(c,w,h){
    gradientRect(c,0,0,w,h,['#0c1526','#111f32','#16293b']);
    c.lineWidth=1;
    const step=Math.min(58,Math.max(30,w/13));
    for(let x=0;x<w;x+=step){c.beginPath();c.strokeStyle='rgba(201,237,255,.30)';c.moveTo(x,0);c.lineTo(x,h);c.stroke();}
    for(let y=0;y<h;y+=step){c.beginPath();c.strokeStyle='rgba(201,237,255,.30)';c.moveTo(0,y);c.lineTo(w,y);c.stroke();}
    for(let x=step;x<w;x+=step*2){for(let y=step;y<h;y+=step*2){c.strokeStyle='#d0efff66';c.strokeRect(x-5,y-5,10,10);}}
    c.lineWidth=2;c.strokeStyle='rgba(183,225,245,.6)';c.beginPath();c.moveTo(w*.13,h*.45);c.lineTo(w*.87,h*.45);c.moveTo(w*.5,h*.09);c.lineTo(w*.5,h*.77);c.stroke();
    c.textAlign='center';c.font=`600 ${Math.max(19,Math.min(48,w/16))}px system-ui`;c.fillStyle='#eef9ff';
    c.fillText('TESTE DE DISTORÇÃO',w/2,h*.29);
  }
  function darkAero(c,w,h){
    // Original, procedural chrome environment: the actual GPU material samples
    // these white reflections and dark geometric highlights in real time.
    gradientRect(c,0,0,w,h,['#05060c','#11101b','#060710']);
    let halo=c.createRadialGradient(w*.53,h*.23,0,w*.53,h*.23,w*.65);
    halo.addColorStop(0,'#66617d70');halo.addColorStop(.32,'#2a283b61');halo.addColorStop(1,'#00000000');
    c.fillStyle=halo;c.fillRect(0,0,w,h);
    // Faux-dimensional floating polished chrome shapes inspired by Dark Aero:
    // broad black faces, slender silver bevels and reflected streaks.
    for(let k=0;k<15;k++){
      const x=w*((k*47+13)%107)/107,y=h*(.12+((k*37+9)%73)/115);
      const size=Math.max(28,w*(.058+(k%5)*.013));
      c.save();c.translate(x,y);c.rotate((k%5-2)*.17);
      const g=c.createLinearGradient(-size,-size,size,size);
      g.addColorStop(0,'#8d8da2');g.addColorStop(.08,'#20202c');
      g.addColorStop(.26,'#04060c');g.addColorStop(.70,'#07070d');
      g.addColorStop(.85,'#454658');g.addColorStop(.91,'#f0f0fa');g.addColorStop(1,'#10111e');
      c.fillStyle=g;c.beginPath();c.roundRect(-size*.43,-size*.40,size*.86,size*.80,size*.12);c.fill();
      c.strokeStyle='rgba(226,231,245,.30)';c.lineWidth=Math.max(1,dpr*.55);
      c.stroke();
      let shine=c.createLinearGradient(-size*.3,-size*.5,size*.35,size*.52);
      shine.addColorStop(0,'#ffffff48');shine.addColorStop(.16,'#ffffff00');
      shine.addColorStop(.83,'#ffffff00');shine.addColorStop(1,'#fcfcff48');
      c.fillStyle=shine;c.beginPath();c.roundRect(-size*.35,-size*.30,size*.7,size*.60,size*.10);c.fill();
      c.restore();
    }
    // Layered cool silver light ribbons, console-era rather than neon sci-fi.
    c.save();c.globalCompositeOperation='screen';
    for(let i=0;i<4;i++){
      const y=h*(.19+i*.19);c.beginPath();c.moveTo(-w*.12,y+h*.03);
      c.bezierCurveTo(w*.28,y-h*.17,w*.63,y+h*.10,w*1.15,y-h*.05);
      const grad=c.createLinearGradient(0,y-12,0,y+17);
      grad.addColorStop(0,'rgba(190,192,228,0)');
      grad.addColorStop(.45,'rgba(220,220,243,.15)');
      grad.addColorStop(.51,'rgba(253,252,255,.46)');
      grad.addColorStop(.58,'rgba(212,215,238,.07)');grad.addColorStop(1,'rgba(220,220,240,0)');
      c.strokeStyle=grad;c.lineWidth=(8-i)*dpr;c.stroke();
    }
    c.restore();
    const vig=c.createRadialGradient(w*.5,h*.44,w*.07,w*.5,h*.44,w*.83);
    vig.addColorStop(0,'#00000000');vig.addColorStop(1,'#00020abb');
    c.fillStyle=vig;c.fillRect(0,0,w,h);
  }
  function drawBackground(){
    if(!g2)return;
    const w=scene.width,h=scene.height;
    if(background==='aero')darkAero(g2,w,h);
    else if(background==='typography')typography(g2,w,h);
    else if(background==='grid')grid(g2,w,h);
    else if(userPhoto&&background==='photo'){
      const i=userPhoto,scale=Math.max(w/i.width,h/i.height),sw=i.width*scale,sh=i.height*scale;
      g2.fillStyle='#162334';g2.fillRect(0,0,w,h);g2.drawImage(i,(w-sw)/2,(h-sh)/2,sw,sh);
      const ov=g2.createLinearGradient(0,0,0,h);ov.addColorStop(0,'#040a168a');ov.addColorStop(.22,'#0611240e');ov.addColorStop(1,'#0108166a');g2.fillStyle=ov;g2.fillRect(0,0,w,h);
    } else landscape(g2,w,h);
    // Calibration typography really lives in the source texture, behind the lens.
    if(background==='landscape'||background==='photo'||background==='aero'){
      g2.textAlign='center';g2.textBaseline='middle';
      g2.shadowColor='rgba(0,0,0,.39)';g2.shadowBlur=9*dpr;g2.shadowOffsetY=2*dpr;
      g2.font=`700 ${Math.round(Math.max(23,Math.min(46,w*.065)))}px system-ui`;
      g2.fillStyle='rgba(252,254,255,.89)';g2.fillText('O VIDRO DEFORMA O FUNDO',w*.50,h*.42,w*.92);
      g2.font=`500 ${Math.round(Math.max(11,Math.min(19,w*.026)))}px system-ui`;
      g2.fillStyle='rgba(254,254,255,.81)';g2.fillText('Passe a lente por estas letras e pelas margens da paisagem',w*.50,h*.50,w*.90);
      g2.shadowColor='transparent';g2.shadowBlur=0;g2.shadowOffsetY=0;
    }
    if(gl&&program){
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,scene);
    }
    dirty=true;
  }
  function asNumber(v,fallback,min,max){
    const n=Number(v);return Number.isFinite(n)?Math.min(max,Math.max(min,n)):fallback;
  }
  function restore(){
    try{
      const recent=JSON.parse(localStorage.getItem('glasslab-v6-presets')||'null') || JSON.parse(localStorage.getItem('glasslab-v5-presets')||'null') || JSON.parse(localStorage.getItem('glasslab-v4-presets')||'null') || JSON.parse(localStorage.getItem('glasslab-v3-presets')||'null');
      const legacy=JSON.parse(localStorage.getItem('glasslab-v2-presets')||'null');
      const saved=[3,4,5,6].includes(recent?.schemaVersion)?recent:legacy?.schemaVersion===2?legacy:null;
      if(!saved)return;
      for(const style of ['liquid','oldschool']){
        const src=[3,4,5,6].includes(saved.schemaVersion)?saved.styles?.[style]:style==='liquid'?saved.presets:null;
        if(!src)continue;
        for(const type of TYPES){
          const data=src[type.id];if(!data)continue;
          const target=makePreset(type.id,style);
          for(const def of [{id:'strength',min:0,max:100,default:68},...PARAMS])
            target[def.id]=asNumber(data[def.id],target[def.id],def.min,def.max);
          target.value=asNumber(data.value,target.value,0,1);
          target.tabIndex=Math.round(asNumber(data.tabIndex,0,0,2));
          target.selected=Boolean(data.selected);target.motion=data.motion!==false;
          target.particlesEnabled=data.particlesEnabled===undefined?target.particlesEnabled:Boolean(data.particlesEnabled);
          target.metalThumb=data.metalThumb===undefined?target.metalThumb:Boolean(data.metalThumb);
          target.retroFinish=Math.round(asNumber(data.retroFinish,target.retroFinish,0,3));
          target.xNorm=asNumber(data.xNorm,.48,0,1);
          target.yNorm=asNumber(data.yNorm,.49,0,1);
          stylePresets[style][type.id]=target;
        }
      }
      for(const style of ['liquid','oldschool'])unifyStyleLook(style,saved.activeStyle===style? saved.active || 'bubble':'bubble');
      currentStyle=[3,4,5,6].includes(saved.schemaVersion)&&saved.activeStyle==='oldschool'?'oldschool':'liquid';
      presets=stylePresets[currentStyle];
      if(TYPES.some(t=>t.id===saved.active))currentType=saved.active;
      if(['landscape','typography','grid','aero'].includes(saved.background))background=saved.background;
      if(saved.schemaVersion===6 && saved.effects){
        for(const style of ['liquid','oldschool']){
          const o=saved.effects[style];if(!o)continue;
          const out=fxProfiles[style];
          for(const k of ['particleEnabled','audioEnabled','mixEnabled'])
            if(typeof o[k]==='boolean')out[k]=o[k];
          for(const k of ['intensity','blend','volume'])
            out[k]=asNumber(o[k],out[k],0,100);
          for(const k of ['primary','secondary'])
            if(k==='secondary'&&o[k]==='none'||window.GlassLabAudio?.byGroup[o[k]])out[k]=o[k];
        }
      }
    }catch(err){console.warn('Preset storage unavailable',err);}
  }
  let saveTimer=null;
  function store(){
    if(saveTimer)clearTimeout(saveTimer);
    saveTimer=setTimeout(()=>{
      try{localStorage.setItem('glasslab-v6-presets',JSON.stringify({
        schemaVersion:6,activeStyle:currentStyle,active:currentType,
        background,styles:stylePresets,effects:fxProfiles
      }));}catch(err){console.warn('Cannot persist presets',err);}
      saveTimer=null;
    },140);
  }
  function currentTypeInfo(){return TYPES.find(t=>t.id===currentType)||TYPES[0];}
  function widthBounds(){
    // The editing panel lives beside the optics in short landscape mode.
    const side=w/h>1.35 && h<630;
    const panelRect=controls.getBoundingClientRect();
    previewW=side?Math.max(230,w-panelRect.width-32):w;
    previewH=side?h:Math.max(260,h-panelRect.height-16);
    minY=67;
    maxY=previewH-12;
  }
  function sizeBase(){
    const base=Math.max(34,Math.min(previewW*.21,previewH*.23));
    return base*(.65+p().size*.0061);
  }
  function geometry(){
    const r=sizeBase(),type=currentType,retro=currentStyle==='oldschool';
    let bw=2*r,bh=2*r,corner=r;
    if(type==='square'){corner=r*(retro?.12:.34);}
    else if(type==='pill'){bw=r*3.45;bh=r*1.16;corner=retro?bh*.18:bh*.5;}
    else if(type==='icon'){bw=bh=r*1.43;corner=retro?bw*.18:bw*.5;}
    else if(type==='chip'){bw=r*2.75;bh=r*.84;corner=retro?bh*.20:bh*.5;}
    else if(type==='card'){bw=r*3.15;bh=r*1.77;corner=retro?r*.12:r*.39;}
    else if(type==='switch'){bw=r*2.75;bh=r*1.12;corner=retro?bh*.20:bh*.5;}
    else if(type==='slider'){bw=r*4.05;bh=r*.54;corner=retro?bh*.2:bh*.5;}
    else if(type==='scrollbar'){bw=r*.64;bh=r*3.2;corner=retro?bw*.18:bw*.5;}
    else if(type==='tabs'){bw=r*4.22;bh=r*.92;corner=retro?bh*.14:bh*.5;}
    const available=previewW-25;
    if(bw>available){const shrink=available/bw;bw*=shrink;bh*=shrink;corner*=shrink;}
    if(bh>previewH-minY-24){const shrink=Math.max(.25,(previewH-minY-24)/bh);bw*=shrink;bh*=shrink;corner*=shrink;}
    return {w:bw,h:bh,r:corner};
  }
  function constrain(){
    widthBounds();const b=geometry();
    const lowX=b.w*.5+9,highX=Math.max(lowX,previewW-b.w*.5-9);
    const lowY=minY+b.h*.5+10,highY=Math.max(lowY,maxY-b.h*.5-10);
    cx=Math.max(lowX,Math.min(highX,cx||previewW*.48));
    cy=Math.max(lowY,Math.min(highY,cy||((lowY+highY)*.5)));
    p().xNorm=cx/Math.max(previewW,1);p().yNorm=cy/Math.max(previewH,1);
  }
  function geometryFor(type,style,data){
    const base=Math.max(34,Math.min(previewW*.21,previewH*.23));
    const r=base*(.65+data.size*.0061),retro=style==='oldschool';
    let bw=2*r,bh=2*r,corner=r;
    if(type==='square'){corner=r*(retro?.12:.34);}
    else if(type==='pill'){bw=r*3.45;bh=r*1.16;corner=retro?bh*.18:bh*.5;}
    else if(type==='icon'){bw=bh=r*1.43;corner=retro?bw*.18:bw*.5;}
    else if(type==='chip'){bw=r*2.75;bh=r*.84;corner=retro?bh*.20:bh*.5;}
    else if(type==='card'){bw=r*3.15;bh=r*1.77;corner=retro?r*.12:r*.39;}
    else if(type==='switch'){bw=r*2.75;bh=r*1.12;corner=retro?bh*.20:bh*.5;}
    else if(type==='slider'){bw=r*4.05;bh=r*.54;corner=retro?bh*.2:bh*.5;}
    else if(type==='scrollbar'){bw=r*.64;bh=r*3.2;corner=retro?bw*.18:bw*.5;}
    else if(type==='tabs'){bw=r*4.22;bh=r*.92;corner=retro?bh*.14:bh*.5;}
    const available=previewW-25;
    if(bw>available){const shrink=available/bw;bw*=shrink;bh*=shrink;corner*=shrink;}
    if(bh>previewH-minY-24){const shrink=Math.max(.25,(previewH-minY-24)/bh);
      bw*=shrink;bh*=shrink;corner*=shrink;}
    return {w:bw,h:bh,r:corner};
  }
  function geometryAt(x,y,wid,hei,rad,optical=.9,opacity=1,kind='surface'){
    return {x,y,w:wid,h:hei,r:rad,optical,opacity,kind};
  }
  function visualParts(){
    const b=geometry(),parts=[];
    const add=(x,y,wid,hei,rad,optical,opacity,kind,trailX=0,trailY=0,press=0)=>
      parts.push({...geometryAt(x,y,wid,hei,rad,optical,opacity,kind),trailX,trailY,press});
    // Only free-form draggables have a viscoelastic tail. Pressable controls
    // instead compress on contact, with no tug when the finger presses down.
    if(['bubble','square','pill','icon','chip','card'].includes(currentType)){
      const gel=currentStyle==='liquid' && dragBody() && p().motion;
      add(cx,cy,b.w,b.h,b.r,1,1,'body',gel?motion.dragX:0,gel?motion.dragY:0,
          pressable()?motion.press*clamp(p().pressDepth/60,0,1.6):0);
      return parts;
    }
    if(currentType==='slider'){
      const thumbR=b.h*.92;
      add(cx,cy,b.w,b.h,b.r,.34,.83,'track');
      const x=cx-b.w*.5+thumbR+(b.w-2*thumbR)*springValue;
      add(x,cy,thumbR*2,thumbR*2,thumbR,1.32,1,'thumb',
          clamp(springSpeed*(currentStyle==='liquid'?1.35:.38),-7,7),0);
    }else if(currentType==='scrollbar'){
      // Intentionally keeps its original overhanging thumb for affordance.
      const thumbH=b.h*.29,thumbW=b.w*1.3;
      add(cx,cy,b.w,b.h,b.r,.28,.79,'track');
      const y=cy-b.h*.5+thumbH*.5+(b.h-thumbH)*springValue;
      add(cx,y,thumbW,thumbH,b.w*.41,1.4,1,'thumb',0,
          clamp(springSpeed*(currentStyle==='liquid'?1.35:.4),-8,8));
    }else if(currentType==='switch'){
      const thumbR=b.h*.42;
      add(cx,cy,b.w,b.h,b.r,.40,.81,'track');
      const x=cx-b.w*.5+b.h*.5+(b.w-b.h)*springValue;
      add(x,cy,thumbR*2,thumbR*2,thumbR,1.43,1,'thumb',
          clamp(springSpeed*(currentStyle==='liquid'?1.2:.4),-7,7),0);
    }else if(currentType==='tabs'){
      const per=b.w/3;
      add(cx,cy,b.w,b.h,b.r,.38,.77,'track');
      const tabWidth=per-8;
      const x=cx-b.w*.5+per*.5+(b.w-per)*springValue;
      add(x,cy,tabWidth,b.h-9,Math.min((b.h-9)*.5,b.r),1.29,.97,'thumb');
    }
    return parts;
  }
  function contrastFor(x,y){
    // Sample the ORIGINAL scene behind each label, not an arbitrary black
    // drop shadow. Local luminance switches ink for bright/dark backgrounds.
    if(!g2||!scene.width)return 'ink-light';
    try{
      const pixel=g2.getImageData(clamp(Math.round(x*dpr),0,scene.width-1),
        clamp(Math.round(y*dpr),0,scene.height-1),1,1).data;
      const luminance=(.2126*pixel[0]+.7152*pixel[1]+.0722*pixel[2])/255;
      return luminance>.68?'ink-dark':'ink-light';
    }catch{return 'ink-light';}
  }
  function renderLabels(parts){
    const type=currentType,b=geometry(),retro=currentStyle==='oldschool';
    const markup=[];
    const label=(x,y,html,cls='',scale=1)=>{
      const ink=retro?([1,3].includes(p().retroFinish)?'ink-dark':'ink-light'):contrastFor(x,y),glyph=Math.round(clamp(Math.min(b.h,b.w)*.31,23,49)*scale);
      const font=Math.round(clamp(b.h*.20,13,20));
      const press=pressable()?motion.press*clamp(p().pressDepth/60,0,1.6):0;
      const transform=press?`translate(-50%,-50%) translateY(${(press*1.5).toFixed(1)}px) scale(${(1-press*.025).toFixed(3)})`:'translate(-50%,-50%)';
      markup.push(`<div class="piece-text ${cls} ${ink}" style="left:${x.toFixed(1)}px;top:${y.toFixed(1)}px;--glyph-size:${glyph}px;--label-size:${font}px;transform:${transform}">${html}</div>`);
    };
    if(type==='bubble'){label(cx,cy,'<span class="glyph">⌂</span><span>Home</span>');}
    if(type==='square'){label(cx,cy,'<span class="glyph">▢</span><span>Glass</span>');}
    if(type==='pill'){label(cx,cy,'<span class="glyph">▶</span><span>Play Minecraft</span>');}
    if(type==='icon'){label(cx,cy,'<span class="glyph">⚙</span>','',1.1);}
    if(type==='chip'){label(cx,cy,'<span class="glyph">✓</span><span>Selecionado</span>',p().selected?'active':'dim');}
    if(type==='card'){label(cx,cy-5,'<span class="glyph">◈</span><span>Glass Card</span>');}
    if(type==='slider')label(cx,cy+b.h+25,`<span class="small">VALOR • ${Math.round(springValue*100)}%</span>`);
    if(type==='scrollbar')label(cx+b.w*.5+56,cy,`<span class="small">SCROLL<br>${Math.round(springValue*100)}%</span>`,'readout');
    if(type==='switch')label(cx,cy+b.h+26,`<span class="small">${p().value>.5?'LIGADO':'DESLIGADO'}</span>`);
    if(type==='tabs'){
      ['Home','Mods','Shaders'].forEach((name,i)=>{
        const x=cx-b.w*.5+b.w/6+i*b.w/3;
        label(x,cy,name,Math.round(springValue*2)===i?'active tab-current':'dim');
      });
      // Thin optical underline, not an opaque selected tab capsule.
      const selected=(cx-b.w*.5)+(Math.round(springValue*2)+.5)*(b.w/3);
      markup.push(`<div class="tab-underline" style="left:${selected.toFixed(1)}px;top:${(cy+b.h*.30).toFixed(1)}px"></div>`);
    }
    overlay.innerHTML=markup.join('');
  }
  function uniformsAndDraw(time){
    if(!shaderReady)return;
    const conf=p(),parts=visualParts();
    const packed=new Float32Array(16),meta=new Float32Array(16),fills=new Float32Array(16);
    // Contrast is selective. Buttons and selected glass tabs STAY CLEAR.
    // User-approved scrollbar geometry remains unchanged. Matte white-ish
    // semi-transparent thumb is distinct from its subtle channel.
    const controlWithTrack=['slider','scrollbar','switch','tabs'].includes(currentType);
    const contrast=conf.trackContrast/100,indicator=conf.indicatorOpacity/100;
    const dynamics=new Float32Array(16);
    for(let i=0;i<parts.length && i<4;i++){
      const a=parts[i],j=i*4;
      packed[j]=a.x*dpr;packed[j+1]=(h-a.y)*dpr;
      packed[j+2]=a.w*.5*dpr;packed[j+3]=a.h*.5*dpr;
      meta[j]=a.r*dpr;meta[j+1]=a.optical;meta[j+2]=a.opacity;
      meta[j+3]=(currentStyle==='oldschool'&&conf.metalThumb&&a.kind==='thumb'
        &&['scrollbar','slider'].includes(currentType))?1:0;
      dynamics[j]=(a.trailX||0)*dpr;
      dynamics[j+1]=-(a.trailY||0)*dpr;
      dynamics[j+2]=a.press||0;
      dynamics[j+3]=(a.kind==='thumb'||a.kind==='body')?motion.feedback:0;
      const retro=currentStyle==='oldschool';
      let material=[0,0,0,0];
      if(controlWithTrack&&a.kind==='track'){
        material=retro?[.035,.04,.055,.06+contrast*.13]
          :[.13,.14,.155,.05+contrast*.18];
      }else if(controlWithTrack&&a.kind==='thumb'){
        if(currentType==='tabs'){
          material=retro?[.92,.94,.96,.035]:[1,1,1,.015]; // transparent selected lens
        }else{
          const white=retro?.96:.96;
          material=[white,white,Math.min(1,white+.012),indicator*(retro?.23:.62)];
        }
      }
      fills.set(material,j);
    }
    gl.useProgram(program);gl.viewport(0,0,canvas.width,canvas.height);
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
    gl.uniform2f(uniforms.Res,canvas.width,canvas.height);
    gl.uniform1i(uniforms.Count,parts.length);
    gl.uniform4fv(uniforms['Parts[0]'],packed);
    gl.uniform4fv(uniforms['Meta[0]'],meta);
    gl.uniform4fv(uniforms['Fill[0]'],fills);
    gl.uniform4fv(uniforms['Dynamics[0]'],dynamics);
    gl.uniform1i(uniforms.Style,currentStyle==='oldschool'?1:0);
    const angle=conf.lightAngle*Math.PI/180;
    const drift=(currentStyle==='liquid'&&conf.motion?Math.sin(time*.00038)*.025:0);
    gl.uniform2f(uniforms.Light,Math.cos(angle+drift),Math.sin(angle+drift));
    gl.uniform1f(uniforms.Elevation,.28+conf.lightElevation*.014);
    gl.uniform1f(uniforms.Strength,(conf.strength/100)*1.65);
    gl.uniform1f(uniforms.Roll,(6+conf.thickness*.36)*dpr);
    gl.uniform1f(uniforms.Chroma,conf.chromatic*.034*dpr);
    gl.uniform1f(uniforms.Blur,conf.blur*.028*dpr);
    gl.uniform1f(uniforms.Shine,conf.shine*.018);
    gl.uniform1f(uniforms.Depth,conf.depth/100);
    gl.uniform1f(uniforms.Fresnel,conf.fresnel*.021);
    gl.uniform1f(uniforms.Gloss,conf.gloss/100);
    gl.uniform1f(uniforms.Bloom,conf.bloom/100);
    gl.uniform1f(uniforms.Spill,conf.spill/100);
    gl.uniform1f(uniforms.Tint,conf.tint/100);
    gl.uniform1f(uniforms.Shadow,conf.shadow/100);
    gl.uniform1f(uniforms.Compare,compare?1:0);
    gl.uniform1i(uniforms.RetroFinish,conf.retroFinish||0);
    gl.uniform1f(uniforms.RetroMetal,conf.retroMetal/100);
    gl.uniform1f(uniforms.RetroGrain,conf.retroGrain/100);
    gl.uniform1f(uniforms.RetroAero,conf.retroAero/100);
    gl.uniform1f(uniforms.RetroChrome,conf.retroChrome/100);
    gl.uniform1f(uniforms.RetroEdge,conf.retroEdge/100);
    gl.uniform1f(uniforms.RetroAccent,conf.retroAccent/100);
    gl.uniform1f(uniforms.Time,time*.001);
    gl.drawArrays(gl.TRIANGLES,0,6);
    renderLabels(parts);
    overlay.style.visibility=compare?'hidden':'visible';
  }
  // Exact underdamped harmonic oscillator integration, independent of frame rate.
  // Interruption retains velocity; unlike easing curves, scrolling remains soft
  // when the user reverses direction. No long-running animation if settled.
  function springStep(position,velocity,target,stiffness,zeta,dt){
    const omega=Math.sqrt(stiffness);
    const z=clamp(zeta,.45,.995);
    const damping=z*omega;
    const wd=omega*Math.sqrt(1-z*z);
    const e=Math.exp(-damping*dt);
    const y=position-target;
    const c=Math.cos(wd*dt),si=Math.sin(wd*dt);
    const next=target+e*(y*c+(velocity+damping*y)/wd*si);
    const vel=e*(velocity*c-(damping*velocity+omega*omega*y)/wd*si);
    if(Math.abs(next-target)<.00010&&Math.abs(vel)<.001)return [target,0];
    return [next,vel];
  }
  function animate(now){
    requestAnimationFrame(animate);
    const dt=Math.min(.045,Math.max(.001,(now-(prevFrame||now-16))/1000));prevFrame=now;
    const conf=p(),retro=currentStyle==='oldschool';
    const integrate=(name,velocity,target,k,c)=>{
      let pos=motion[name],vel=motion[velocity];
      vel+=(target-pos)*k*dt;
      vel*=Math.exp(-c*dt);
      pos+=vel*dt;
      if(Math.abs(pos-target)<.002&&Math.abs(vel)<.02){pos=target;vel=0;}
      motion[name]=pos;motion[velocity]=vel;
      if(vel||Math.abs(pos-target)>.003)dirty=true;
    };
    if(tracking()){
      const desired=currentType==='tabs'?conf.tabIndex/2:conf.value;
      if(conf.motion){
        // Scrollbars receive a soft, low-energy gel spring; switches keep a
        // precise snap but do not become rigid. Tabs use a calm focus glide.
        const scroll=currentType==='scrollbar';
        const slide=currentType==='slider';
        const speed=conf.speed/100;
        let stiffness,zeta;
        if(scroll){stiffness=retro?53+speed*60:42+speed*56;zeta=retro?.82:.76;}
        else if(slide){stiffness=retro?75+speed*85:62+speed*82;zeta=retro?.82:.76;}
        else if(currentType==='switch'){
          stiffness=retro?140+speed*95:120+speed*88;zeta=retro?.79:.73;
        }else{stiffness=retro?92+speed*70:83+speed*68;zeta=retro?.90:.82;}
        // Bounce and viscosity nudge the material, not amplify it by 100%.
        zeta=clamp(zeta+(conf.viscosity-50)*.00085-(conf.bounce-30)*.001,.67,.94);
        [springValue,springSpeed]=springStep(springValue,springSpeed,desired,stiffness,zeta,dt);
        springValue=clamp(springValue,-.022,1.022);
        if(Math.abs(springSpeed)>.0007||Math.abs(desired-springValue)>.0001)dirty=true;
      }else{springValue=desired;springSpeed=0;}
    }
    if(conf.motion){
      // Old School has tactile travel + damped return, without liquid tail.
      const pressStiffness=retro?170:240;
      integrate('press','pressV',pressable()?motion.pressTarget:0,
        pressStiffness,retro?20.5:22);
      const k=retro?185:(85+conf.speed*1.4);
      const c=retro?23:(7+conf.viscosity*.20-conf.bounce*.025);
      integrate('dragX','vx',0,k,c);
      integrate('dragY','vy',0,k,c);
    }else{
      motion.dragX=motion.dragY=motion.vx=motion.vy=0;
      motion.press=0;motion.pressV=0;
    }
    // Momentary directional focus response on console thumbs.
    if(motion.feedback>.0001){motion.feedback*=Math.exp(-(retro?7.5:9.5)*dt);dirty=true;}
    else motion.feedback=0;
    if(motion.pressTarget||dragging)dirty=true;
    // A separate transparent canvas makes spark updates cheap: WebGL shader
    // only redraws when optics change, not on each particle frame.
    window.GlassLabParticles?.tick(dt);
    if(dirty){dirty=false;uniformsAndDraw(now);}
  }
  function resize(){
    const prevW=previewW||0,prevH=previewH||0;
    w=canvas.clientWidth;h=canvas.clientHeight;
    dpr=Math.min(window.devicePixelRatio||1,2);
    canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
    scene.width=canvas.width;scene.height=canvas.height;
    window.GlassLabParticles?.resize(w,h,dpr);
    widthBounds();
    if(prevW && prevH){cx=cx/prevW*previewW;cy=cy/prevH*previewH;}
    else{cx=p().xNorm*previewW;cy=p().yNorm*previewH;}
    constrain();
    if(gl)gl.viewport(0,0,canvas.width,canvas.height);
    drawBackground();dirty=true;
  }
  function typeChange(id,savePrevious=true){
    if(!TYPES.some(t=>t.id===id))return;
    if(savePrevious){p().xNorm=cx/Math.max(previewW,1);p().yNorm=cy/Math.max(previewH,1);}
    currentType=id;
    cx=p().xNorm*previewW;cy=p().yNorm*previewH;
    constrain();
    springValue=currentType==='tabs'?p().tabIndex/2:p().value;
    springSpeed=0;motion.dragX=motion.dragY=motion.vx=motion.vy=0;motion.pressTarget=0;motion.press=0;
    const current=currentTypeInfo();
    $('previewName').textContent=current.subtitle;$('previewHelp').textContent=current.hint;
    document.querySelectorAll('.type-chip').forEach(b=>b.classList.toggle('selected',b.dataset.type===id));
    syncSliders();syncFX();store();dirty=true;
  }
  function setVal(v){
    if(currentType==='tabs'){
      p().tabIndex=Math.round(Math.min(2,Math.max(0,v*2)));p().value=p().tabIndex/2;
    }else p().value=Math.min(1,Math.max(0,v));
    store();dirty=true;
  }
  function pointerPos(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}
  function updateFromPoint(pt){
    const b=geometry();
    if(currentType==='slider'){
      const thumb=b.h*.92;
      setVal((pt.x-(cx-b.w*.5+thumb))/(b.w-2*thumb));
    }else if(currentType==='scrollbar'){
      const thumbH=b.h*.29;
      setVal((pt.y-(cy-b.h*.5+thumbH*.5))/(b.h-thumbH));
    }else if(currentType==='switch'){
      // Physical toggle: two stable endpoints, no press squish.
      setVal(pt.x>=cx?.999:.001);
    }else if(currentType==='tabs'){
      setVal(Math.round(clamp((pt.x-(cx-b.w*.5))/b.w*3-.5,0,2))/2);
    }
  }
  canvas.addEventListener('pointerdown',e=>{
    if(e.pointerType==='mouse'&&e.button!==0)return;
    const pos=pointerPos(e),b=geometry();
    const near=Math.abs(pos.x-cx)<b.w*.5+19 && Math.abs(pos.y-cy)<b.h*.5+19;
    if(!near)return;
    dragging=true;pointerDown=true;motion.dragMoved=false;
    lastPoint={...pos,time:performance.now()};
    canvas.classList.add('dragging');canvas.setPointerCapture(e.pointerId);
    sfx('press');
    if(tracking()){ updateFromPoint(pos);motion.feedback=.70; }
    else if(currentType==='chip') motion.pressTarget=1;
    else{
      dragOffset={x:cx-pos.x,y:cy-pos.y};
      if(pressable())motion.pressTarget=1;
    }
    dirty=true;
  });
  canvas.addEventListener('pointermove',e=>{
    if(!pointerDown||!dragging)return;
    const pt=pointerPos(e),now=performance.now();
    const dx=lastPoint?pt.x-lastPoint.x:0,dy=lastPoint?pt.y-lastPoint.y:0;
    lastPoint={...pt,time:now};
    if(Math.hypot(pt.x-(cx-dragOffset.x),pt.y-(cy-dragOffset.y))>7 && currentType==='chip')motion.dragMoved=true;
    if(currentType!=='chip'&&Math.hypot(dx,dy)>1.4)motion.dragMoved=true;
    if(tracking()){
      const prior=p().value;
      updateFromPoint(pt);motion.feedback=.50;
      if(Math.abs(p().value-prior)>.008){
        sfx('slide');
        const part=visualParts().find(x=>x.kind==='thumb');
        if(part){
          const px=currentType==='scrollbar'?cx+part.w*.28:part.x;
          particleEmit({x:px,y:part.y},dx,dy);
        }
      }
    }
    else if(dragBody()){
      cx=pt.x+dragOffset.x;cy=pt.y+dragOffset.y;constrain();
      if(p().motion&&currentStyle==='liquid'){
        const viscosity=(.22+(100-p().viscosity)*.0035);
        const maximum=clamp(11+p().stretch*.26,10,38);
        // Pointer delta adds directed impulse, NEVER symmetric scaling.
        motion.dragX=clamp(motion.dragX+dx*viscosity,-maximum,maximum);
        motion.dragY=clamp(motion.dragY+dy*viscosity,-maximum,maximum);
        motion.vx=clamp(motion.vx+dx*36,-700,700);
        motion.vy=clamp(motion.vy+dy*36,-700,700);
      }
      // Once a body is being dragged, it is not also being pressed.
      if(motion.dragMoved)motion.pressTarget=0;
    }
    dirty=true;
  });
  function stopPointer(){
    if(!pointerDown)return;
    if(currentType==='chip'&&!motion.dragMoved){p().selected=!p().selected;store();}
    pointerDown=false;dragging=false;motion.pressTarget=0;
    motion.feedback=Math.max(motion.feedback,.72);
    sfx(currentType==='tabs'?'tab':currentType==='switch'?'toggle':'release');
    if(p().particlesEnabled && pressable())particleEmit({x:cx+geometry().w*.35,y:cy-geometry().h*.25},6,-6);
    canvas.classList.remove('dragging');store();dirty=true;
  }
  canvas.addEventListener('pointerup',stopPointer);
  canvas.addEventListener('pointercancel',stopPointer);
  canvas.addEventListener('lostpointercapture',stopPointer);
  canvas.addEventListener('wheel',e=>{
    if(currentType!=='scrollbar')return;
    e.preventDefault();setVal(p().value+Math.sign(e.deltaY)*.08);
    sfx('tick');particleEmit({x:cx+geometry().w*.35,y:cy+(p().value-.5)*geometry().h*.7},3,Math.sign(e.deltaY)*12);
  },{passive:false});
  function syncFX(){
    if(!$('fxPanel'))return;
    const cfg=fx(),pref=p();
    $('fxStyleEnabled').checked=cfg.particleEnabled;
    $('fxComponentEnabled').checked=pref.particlesEnabled;
    $('fxComponentEnabled').disabled=!cfg.particleEnabled;
    $('metalThumbRow').hidden=currentStyle!=='oldschool'||!['slider','scrollbar'].includes(currentType);
    $('metalThumb').checked=pref.metalThumb;
    $('fxIntensity').value=cfg.intensity;
    $('fxIntensityValue').textContent=cfg.intensity+'%';
    $('audioEnabled').checked=cfg.audioEnabled;
    $('soundPrimary').value=cfg.primary;
    $('soundSecondary').value=cfg.secondary;
    $('soundMix').checked=cfg.mixEnabled;
    $('soundSecondary').disabled=!cfg.mixEnabled;
    $('soundBlend').disabled=!cfg.mixEnabled;
    $('soundBlend').value=cfg.blend;
    $('soundBlendValue').textContent=cfg.blend+'%';
    $('soundVolume').value=cfg.volume;
    $('soundVolumeValue').textContent=cfg.volume+'%';
    const count=(window.GLASSLAB_SOUND_CATALOG||[]).length;
    $('soundStatus').textContent=count+' efeitos · grupos independentes';
  }
  function bindFX(){
    const groups=window.GlassLabAudio?.groupTitles||{};
    const options=Object.entries(groups).map(([key,label])=>
      `<option value="${key}">${label}</option>`).join('');
    $('soundPrimary').innerHTML=options;
    $('soundSecondary').innerHTML='<option value="none">Sem mistura</option>'+options;
    const bools={fxStyleEnabled:'particleEnabled',audioEnabled:'audioEnabled',soundMix:'mixEnabled'};
    for(const [id,key] of Object.entries(bools)){
      $(id).addEventListener('change',e=>{fx()[key]=e.target.checked;syncFX();store();});
    }
    $('fxComponentEnabled').addEventListener('change',e=>{p().particlesEnabled=e.target.checked;store();dirty=true;});
    $('metalThumb').addEventListener('change',e=>{p().metalThumb=e.target.checked;store();dirty=true;});
    for(const [id,key] of [['fxIntensity','intensity'],['soundBlend','blend'],['soundVolume','volume']]){
      $(id).addEventListener('input',e=>{fx()[key]=asNumber(e.target.value,fx()[key],0,100);
        $(id+'Value').textContent=fx()[key]+'%';store();});
    }
    for(const [id,key] of [['soundPrimary','primary'],['soundSecondary','secondary']]){
      $(id).addEventListener('change',e=>{fx()[key]=e.target.value;store();syncFX();sfx('select',true);});
    }
    $('soundPreview').addEventListener('click',()=>sfx('select',true));
    // Menu interactions get a single restrained sound; continuous sliders do
    // not beep for each animation frame.
    document.addEventListener('click',e=>{
      const button=e.target.closest?.('button');
      if(!button||button.id==='soundPreview')return;
      sfx('select');
    });
    syncFX();
  }
  function buildControls(){
    $('switchStyle').addEventListener('click',switchStyle);
    $('componentPicker').innerHTML=TYPES.map(t=>`<button type="button" role="tab" aria-selected="false" data-type="${t.id}" class="type-chip"><span class="symbol">${t.symbol}</span>${t.name}</button>`).join('');
    document.querySelectorAll('[data-type]').forEach(b=>b.addEventListener('click',()=>typeChange(b.dataset.type)));
    $('advancedGrid').innerHTML=PARAMS.map(d=>`<label class="parameter" for="${d.id}">${d.label} <output id="${d.id}Value"></output>${d.hint?`<span class="hint">${d.hint}</span>`:''}<input id="${d.id}" type="range" min="${d.min}" max="${d.max}" step="1" value="${d.default}" /></label>`).join('');
    [{id:'strength',min:0,max:100},...PARAMS].forEach(d=>{
      $(d.id).addEventListener('input',e=>{
        const num=asNumber(e.target.value,p()[d.id],d.min,d.max);
        if(!setGlobalLook(currentStyle,d.id,num))p()[d.id]=num;
        $(d.id+'Value').textContent=num+(d.unit||'%');
        if(GLOBAL_LOOK.has(d.id))$('globalLookStatus').textContent='Aplicado aos 10 componentes de '+STYLES[currentStyle].name;
        constrain();store();dirty=true;
      });
    });
    $('motionEnabled').addEventListener('change',e=>{p().motion=e.target.checked;store();dirty=true;});
    $('retroFinish').addEventListener('change',e=>{
      setGlobalLook(currentStyle,'retroFinish',Math.round(asNumber(e.target.value,0,0,3)));store();dirty=true;
    });
    $('resetCurrent').addEventListener('click',()=>{
      const look=sharedLook(currentStyle);
      presets[currentType]={...makePreset(currentType,currentStyle),...look};
      springValue=currentType==='tabs'?0:p().value;springSpeed=0;
      cx=p().xNorm*previewW;cy=p().yNorm*previewH;constrain();syncSliders();store();dirty=true;
    });
    $('resetAll').addEventListener('click',()=>{
      stylePresets={liquid:makeStylePresets('liquid'),oldschool:makeStylePresets('oldschool')};
      currentStyle='liquid';presets=stylePresets.liquid;applyStyle();
      fxProfiles={liquid:makeFX('liquid'),oldschool:makeFX('oldschool')};
      typeChange('bubble',false);background='landscape';setBackgroundButtons();drawBackground();store();
    });
  }
  function syncSliders(){
    for(const d of [{id:'strength'},...PARAMS]){
      $(d.id).value=p()[d.id];
      $(d.id+'Value').textContent=p()[d.id]+((PARAMS.find(x=>x.id===d.id)?.unit)||'%');
    }
    // These settings apply only to controls with a separate track and thumb.
    const hasThumb=['slider','scrollbar','switch','tabs'].includes(currentType);
    for(const id of ['indicatorOpacity','trackContrast']) $(id).closest('.parameter').hidden=!hasThumb;
    $('motionEnabled').checked=p().motion;
    $('retroFinish').value=String(p().retroFinish||0);
    $('globalLookStatus').textContent='Aparência compartilhada nos 10 componentes · '+STYLES[currentStyle].name;
    document.querySelectorAll('[data-type]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.type===currentType)));
  }
  function setBackgroundButtons(){
    document.querySelectorAll('[data-scene]').forEach(b=>b.classList.toggle('selected',b.dataset.scene===background));
    $('photo').classList.toggle('selected',background==='photo');
  }
  function bindScenes(){
    document.querySelectorAll('[data-scene]').forEach(b=>b.addEventListener('click',()=>{
      background=b.dataset.scene;setBackgroundButtons();drawBackground();store();
    }));
    $('photo').addEventListener('click',()=>$('photoFile').click());
    $('photoFile').addEventListener('change',e=>{
      const f=e.target.files?.[0];if(!f||!f.type.startsWith('image/'))return;
      const url=URL.createObjectURL(f),img=new Image();
      img.onload=()=>{userPhoto=img;background='photo';URL.revokeObjectURL(url);setBackgroundButtons();drawBackground();};
      img.onerror=()=>URL.revokeObjectURL(url);img.src=url;
    });
    $('compare').addEventListener('click',()=>{compare=!compare;
      $('compare').classList.toggle('active',compare);
      $('compare').textContent=compare?'Mostrar vidro':'Comparar';
      $('compareMark').hidden=!compare;dirty=true;
    });
  }
  function exportData(style=currentStyle,typeId=currentType){
    const type=TYPES.find(t=>t.id===typeId)||TYPES[0],data=stylePresets[style][type.id],props={};
    for(const key of Object.keys(DEFAULTS))props[key]=data[key];
    const b=geometryFor(type.id,style,data);
    const shaderUniforms={strength:props.strength/100*1.65,roll_px_per_css_scale:6+props.thickness*.36,
      depthSigned:props.depth/100,chromatic_px_per_css_scale:props.chromatic*.034,
      blur_px_per_css_scale:props.blur*.028,shine:props.shine*.018,
      lightDirection:[Math.cos(props.lightAngle*Math.PI/180),Math.sin(props.lightAngle*Math.PI/180)],
      lightElevation:.28+props.lightElevation*.014,fresnel:props.fresnel*.021,
      gloss:props.gloss/100,bloom:props.bloom/100,spill:props.spill/100,
      tint:props.tint/100,shadow:props.shadow/100};
    return {
      format:'GLASS_LAB_PRESET_V6',schemaVersion:6,name:$('presetName').value.trim()||type.subtitle,
      style:{id:style,name:STYLES[style].name},
      createdAt:new Date().toISOString(),app:'Glass Lab 6.0',sourceProject:'Horizon / experiments/glass-lab',
      component:{type:type.id,label:type.subtitle,interaction:type.hint,
        geometryCss:{width:b.w,height:b.h,cornerRadius:b.r},
        centerNormalized:[data.xNorm,data.yNorm],value:data.value,
        switchOn:type.id==='switch'?data.value>.5:null,
        tabIndex:type.id==='tabs'?data.tabIndex:null,
        chipSelected:type.id==='chip'?data.selected:null},
      opticalParameters:props,
      particleEffects:{enabled:data.particlesEnabled,globalEnabled:fxProfiles[style].particleEnabled,
        intensity:fxProfiles[style].intensity,kind:style==='oldschool'?'spark':'glint',
        metalThumb:Boolean(data.metalThumb)},
      soundProfile:{...fxProfiles[style],assetsReference:'audio/files/*.ogg',
        attribution:'Nathan Gibson (CC BY 4.0), JDSherbert (royalty-free, credit required)'},
      consoleMaterial:{finish:data.retroFinish||0,metalness:props.retroMetal/100,brushing:props.retroGrain/100,lightSpill:props.retroAero/100,chrome:props.retroChrome/100,bevel:props.retroEdge/100,accent:props.retroAccent/100,shading:'GLSL per-pixel chrome normal/refraction/metal microfacets'},
      globalAppearance:{scope:'all-10-components-in-style',sharedParameters:sharedLook(style),otherStyleIndependent:true},
      animation:{enabled:data.motion,elasticity:props.stretch,speed:props.speed,
        viscosity:props.viscosity,bounce:props.bounce,pressDepth:props.pressDepth,
        type:style==='oldschool'?'console-dark-aero-chrome-spring':
          ['slider','scrollbar','switch','tabs'].includes(type.id)?'axis-locked-spring':
          type.id==='bubble'?'directional-viscoelastic-gel':'press-depth-or-directional-gel',
        physics:{mass:1,dragStiffness:85+props.speed*1.4,
          dragDamping:7+props.viscosity*.2-props.bounce*.025,
          pressStiffness:240,pressDamping:22,
          trackStiffness:'component dependent 42–235',trackDamping:'underdamped exact solution with damping ratio .67–.94'},
        notes:'Arrastar gera impulso tangencial com cauda apenas na direção contrária; tocar comprime apenas botões; indicadores deslizam no eixo da trilha.'},
      background:{type:background,photoEmbedded:false,
        note:'Fotos locais não são exportadas para preservar privacidade.'},
      rendering:{engine:'WebGL2 GLSL ES 3.00',shaderRevision:'GLASS_LAB_PBR_PARTICLES_SFX_V6',
        framebufferOrigin:'bottom-left',geometryCoordinate:'CSS pixels top-left, converted using dpr',
        depthConvention:'>0 convex positive curvature; <0 concave negative; 0 flat',
        uniformValues:shaderUniforms,material:{indicatorOpacity:props.indicatorOpacity,trackContrast:props.trackContrast,glassButtonsRemainClear:true},
        stackedParts:['slider','scrollbar','switch','tabs'].includes(type.id)?'base track + separately refracting moving thumb':'single optical body',
        note:'O GLSL abaixo está incluído para portabilidade. No Horizon Rust/WGSL, reimplementar amostragem sobre backdrop, coordenadas, uniforms e animações.'},
      glslFragmentSource:FRAG,
    };
  }
  function exportPayload(style=currentStyle,type=currentType){
    return 'GLASS_LAB_PRESET_V6\n# Glass Lab 6.0 — materiais, partículas e sons por estilo\n# Cada componente é exportado separadamente, com o shader e seus valores.\n\n'
      +JSON.stringify(exportData(style,type),null,2)+'\n';
  }
  function filenameForPreset(){
    const slug=($('presetName').value||currentType).toLowerCase().normalize('NFD')
      .replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,45)||'vidro';
    return 'GlassLab_'+currentType+'_'+slug+'.txt';
  }
  function showExportFeedback(msg){$('exportFeedback').textContent=msg;}
  function showExport(){
    $('presetName').value='Vidro '+currentTypeInfo().name;
    $('exportTitle').textContent='Exportar '+currentTypeInfo().name;
    showExportFeedback('');$('exportDialog').hidden=false;
  }
  function hideExport(){$('exportDialog').hidden=true;}
  function browserDownload(filename,payload){
    const blob=new Blob([payload],{type:'text/plain;charset=utf-8'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),3000);
  }
  function crc32(bytes){
    let crc=0xffffffff;
    for(const byte of bytes){
      crc^=byte;
      for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);
    }
    return (crc^0xffffffff)>>>0;
  }
  function makeZip(files){
    // ZIP32 stored (method 0) is supported by Android, Windows and Python.
    const utf8=new TextEncoder(),locals=[],centrals=[];
    let offset=0;
    for(const file of files){
      if(!/^[a-zA-Z0-9_./-]+$/.test(file.name)||file.name.includes('..'))throw Error('Caminho ZIP inválido');
      const name=utf8.encode(file.name),bytes=utf8.encode(file.body);
      const crc=crc32(bytes),local=new Uint8Array(30+name.length),ld=new DataView(local.buffer);
      ld.setUint32(0,0x04034b50,true);ld.setUint16(4,20,true);ld.setUint16(6,0x0800,true);
      ld.setUint16(8,0,true);ld.setUint16(10,0,true);ld.setUint16(12,0,true);
      ld.setUint32(14,crc,true);ld.setUint32(18,bytes.length,true);
      ld.setUint32(22,bytes.length,true);ld.setUint16(26,name.length,true);
      local.set(name,30);locals.push(local,bytes);
      const central=new Uint8Array(46+name.length),cd=new DataView(central.buffer);
      cd.setUint32(0,0x02014b50,true);cd.setUint16(4,20,true);cd.setUint16(6,20,true);
      cd.setUint16(8,0x0800,true);cd.setUint16(10,0,true);
      cd.setUint32(16,crc,true);cd.setUint32(20,bytes.length,true);
      cd.setUint32(24,bytes.length,true);cd.setUint16(28,name.length,true);
      cd.setUint32(42,offset,true);central.set(name,46);centrals.push(central);
      offset+=local.length+bytes.length;
    }
    const centralLength=centrals.reduce((sum,c)=>sum+c.length,0);
    const end=new Uint8Array(22),ed=new DataView(end.buffer);
    ed.setUint32(0,0x06054b50,true);
    ed.setUint16(8,files.length,true);ed.setUint16(10,files.length,true);
    ed.setUint32(12,centralLength,true);ed.setUint32(16,offset,true);
    return new Blob([...locals,...centrals,end],{type:'application/zip'});
  }
  function packFiles(){
    const now=new Date().toISOString();
    const files=[{
      name:'README.txt',body:[
        'GLASS LAB 5.0 — PACOTE COMPLETO DE COMPONENTES',
        'Inclui TODOS os 10 componentes de cada um dos 2 estilos (20 presets).',
        'Os componentes não modificados entram com valores padrão.',
        'Alterações no MATERIAL aplicam-se a todos os botões do mesmo estilo;',
        'tamanho, interação e parâmetros físicos de cada componente são individuais.',
        'Liquid Glass e Old School são estilos independentes.',
        'SHADER GLSL REAL (WebGL2) incluído em shaders/glasslab-v6.frag.glsl.',
        'Envie este ZIP inteiro ao ChatGPT para portar ao launcher Horizon.',
        'Uma foto de fundo da galeria NUNCA é incluída neste arquivo.',
        'Gerado: '+now,
      ].join('\n')+'\n'
    },{
      name:'shaders/glasslab-v6.frag.glsl',body:FRAG+'\n'
    },{
      name:'shaders/glasslab-v6.vert.glsl',body:VERT+'\n'
    }];
    const manifest={format:'GLASS_LAB_PACK_V6',schemaVersion:6,app:'Glass Lab 6.0',
      generatedAt:now,styles:['liquid','oldschool'],globalMaterialPerStyle:true,
      independentGeometryAndMotionPerComponent:true,componentCount:TYPES.length*2,
      components:TYPES.map(t=>t.id),sharedAppearance:{liquid:sharedLook('liquid'),oldschool:sharedLook('oldschool')},
      shader:'shaders/glasslab-v6.frag.glsl',photoEmbedded:false,
      particleEffects:true,soundProfiles:fxProfiles,audioCatalog:'audio/catalog.json',
      note:'Android export includes all 66 transcoded SFX samples in audio/files; browser export has manifest and mappings.'};
    files.push({name:'manifest.json',body:JSON.stringify(manifest,null,2)+'\n'});
    files.push({name:'effects/per-style.json',body:JSON.stringify(fxProfiles,null,2)+'\n'});
    files.push({name:'audio/catalog.json',body:JSON.stringify(window.GLASSLAB_SOUND_CATALOG||[],null,2)+'\n'});
    files.push({name:'audio/CREDITS.txt',body:'Nathan Gibson / Cyrex Studios — Universal UI Soundpack (CC BY 4.0)\nhttps://cyrex-studios.itch.io/universal-ui-soundpack\nJDSherbert — Ultimate UI SFX Pack (royalty-free; credit mandatory)\nhttps://jdsherbert.itch.io/ultimate-ui-sfx-pack\nDo not redistribute sound samples on their own.\n'});
    for(const style of ['liquid','oldschool']){
      files.push({name:'styles/'+style+'/material-global.json',
        body:JSON.stringify(sharedLook(style),null,2)+'\n'});
      for(const type of TYPES){
        const filename='presets/'+style+'/'+type.id+'.txt';
        files.push({name:filename,body:exportPayload(style,type.id)});
      }
    }
    return {files,blob:makeZip(files)};
  }
  async function downloadPack(){
    const btn=$('downloadPack');btn.disabled=true;
    const prior=btn.textContent;btn.textContent='Preparando ZIP…';
    try{
      const {blob,files}=packFiles();
      const name='GlassLab_Pack_Completo_V6.zip';
      if(window.GlassLabExport&&typeof window.GlassLabExport.savePack==='function'){
        // Android's native SAF file picker; Blob downloads do not work reliably
        // from file:///android_asset on all WebView releases.
        const buffer=new Uint8Array(await blob.arrayBuffer());
        const chunk=0x6000;let binary='';
        for(let i=0;i<buffer.length;i+=chunk)
          binary+=String.fromCharCode(...buffer.subarray(i,i+chunk));
        window.GlassLabExport.savePack(name,btoa(binary));
        $('presetStatus').textContent='Salvar pack: escolha uma pasta · 20 presets + SFX';
      }else{
        const url=URL.createObjectURL(blob),a=document.createElement('a');
        a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();
        setTimeout(()=>URL.revokeObjectURL(url),12000);
        $('presetStatus').textContent='ZIP completo preparado: 20 presets e shader GLSL';
      }
    }catch(error){
      console.error('Pack ZIP:',error);
      $('presetStatus').textContent='Falha no ZIP: '+error.message;
    }finally{btn.disabled=false;btn.textContent=prior;}
  }
  if(location.search.includes('test=1')){
    window.__glassLabV6={packFiles,makeZip,sharedLook,setGlobalLook,
      getStyles:()=>stylePresets,exportData,globalKeys:[...GLOBAL_LOOK],getFX:()=>fxProfiles};
  }
  function bindExport(){
    $('exportPreset').addEventListener('click',showExport);
    $('downloadPack').addEventListener('click',downloadPack);
    $('closeExport').addEventListener('click',hideExport);
    $('exportDialog').addEventListener('click',e=>{if(e.target===$('exportDialog'))hideExport();});
    $('saveTxt').addEventListener('click',()=>{
      const txt=exportPayload(),name=filenameForPreset();
      try{
        if(window.GlassLabExport && typeof window.GlassLabExport.savePreset==='function'){
          window.GlassLabExport.savePreset(name,txt);
          showExportFeedback('Escolha a pasta e confirme o salvamento do arquivo TXT.');
        }else{
          browserDownload(name,txt);
          showExportFeedback('O navegador iniciou o download do TXT.');
        }
      }catch(err){showExportFeedback('Erro ao exportar: '+err.message);}
    });
    $('copyPreset').addEventListener('click',async()=>{
      const txt=exportPayload();
      try{
        if(navigator.clipboard && navigator.clipboard.writeText){await navigator.clipboard.writeText(txt);}
        else{const ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);ta.select();
          if(!document.execCommand('copy'))throw Error('Área de transferência indisponível');ta.remove();}
        showExportFeedback('Preset copiado. Envie o código ou o TXT.');
      }catch(err){showExportFeedback('Não foi possível copiar. Use Salvar TXT.');}
    });
    $('importButton').addEventListener('click',()=>$('importFile').click());
    $('importFile').addEventListener('change',async e=>{
      const f=e.target.files?.[0];if(!f)return;
      try{
        const txt=await f.text();const start=txt.indexOf('{');
        if(start<0)throw Error('O arquivo não contém JSON');
        const imported=JSON.parse(txt.slice(start));
        if(!(['GLASS_LAB_PRESET_V2','GLASS_LAB_PRESET_V3','GLASS_LAB_PRESET_V4','GLASS_LAB_PRESET_V5','GLASS_LAB_PRESET_V6'].includes(imported.format)) || ![2,3,4,5,6].includes(imported.schemaVersion))
          throw Error('Formato do preset incompatível');
        const type=imported.component?.type;
        if(!TYPES.some(x=>x.id===type))throw Error('Tipo de componente não reconhecido');
        const style=[3,4,5,6].includes(imported.schemaVersion)&&imported.style?.id==='oldschool'?'oldschool':'liquid';
        const obj=makePreset(type,style),src=imported.opticalParameters||{};
        for(const d of [{id:'strength',min:0,max:100},...PARAMS]){
          obj[d.id]=asNumber(src[d.id],obj[d.id],d.min,d.max);
        }
        obj.motion=imported.animation?.enabled!==false;
        obj.retroFinish=Math.round(asNumber(imported.consoleMaterial?.finish,0,0,3));
        obj.value=asNumber(imported.component?.value,obj.value,0,1);
        obj.tabIndex=Math.round(asNumber(imported.component?.tabIndex,obj.tabIndex,0,2));
        obj.selected=Boolean(imported.component?.chipSelected);
        const center=imported.component?.centerNormalized||[.48,.49];
        obj.xNorm=asNumber(center[0],.48,0,1);obj.yNorm=asNumber(center[1],.49,0,1);
        stylePresets[style][type]=obj;
        for(const key of GLOBAL_LOOK)setGlobalLook(style,key,obj[key]);
        if(imported.particleEffects){
          obj.particlesEnabled=Boolean(imported.particleEffects.enabled);
          obj.metalThumb=Boolean(imported.particleEffects.metalThumb);
          stylePresets[style][type]=obj;
        }
        if(imported.soundProfile && imported.schemaVersion===6){
          const data=imported.soundProfile;
          const into=fxProfiles[style];
          for(const key of ['audioEnabled','mixEnabled','particleEnabled'])
            if(typeof data[key]==='boolean')into[key]=data[key];
          for(const key of ['blend','volume','intensity'])into[key]=asNumber(data[key],into[key],0,100);
          for(const key of ['primary','secondary'])
            if(data[key]==='none'||window.GlassLabAudio?.byGroup[data[key]])into[key]=data[key];
        }
        currentStyle=style;presets=stylePresets[style];applyStyle();typeChange(type,false);store();
        $('presetName').value=imported.name||'Preset importado';
        showExportFeedback('Preset '+type+' importado com sucesso.');
      }catch(err){showExportFeedback('Falha ao importar: '+err.message);}
      e.target.value='';
    });
  }
  window.glassLabOnExport=function(ok,message){
    showExportFeedback(ok?'Arquivo TXT salvo com sucesso.':(message||'Exportação cancelada.'));
  };
  function start(){
    restore();buildControls();bindFX();applyStyle();bindScenes();bindExport();initGL();
    resize();typeChange(currentType);setBackgroundButtons();
    requestAnimationFrame(animate);
    window.addEventListener('resize',resize);
    window.addEventListener('orientationchange',()=>setTimeout(resize,240));
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)dirty=true;});
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();shaderReady=false;badge.textContent='GPU reiniciando';});
    canvas.addEventListener('webglcontextrestored',()=>{initGL();resize();});
  }
  start();
})();
