/* Glass Lab 2.1: clear optical lenses and accessible material contrast. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const canvas = $('view'), stage = $('stage'), overlay = $('componentUi');
  const controls = document.querySelector('.controls'), badge = $('gpu');
  const TYPES = [
    { id:'bubble', name:'Bolha', symbol:'◯', subtitle:'Bolha circular', hint:'Arraste a lente sobre o texto e observe a borda.' },
    { id:'square', name:'Quadrado', symbol:'▢', subtitle:'Quadrado arredondado', hint:'Borda com curvatura ajustável e vidro em toda a superfície.' },
    { id:'pill', name:'Cápsula', symbol:'▬', subtitle:'Botão cápsula', hint:'Uma peça de vidro horizontal, arrastável.' },
    { id:'icon', name:'Ícone', symbol:'⌂', subtitle:'Botão de ícone', hint:'Lente compacta como os controles do iOS.' },
    { id:'slider', name:'Slider', symbol:'↔', subtitle:'Controle deslizante', hint:'Arraste o indicador horizontal para alterar o valor.' },
    { id:'scrollbar', name:'Scroll', symbol:'↕', subtitle:'Barra de rolagem', hint:'Arraste o indicador vertical ou role a tela sobre ele.' },
    { id:'switch', name:'Switch', symbol:'⏻', subtitle:'Ligar / desligar', hint:'Toque ou arraste a bolinha; o vidro acompanha o movimento.' },
    { id:'tabs', name:'Abas', symbol:'▤', subtitle:'Navegação por abas', hint:'Toque Home, Mods ou Shaders para mover a seleção.' },
    { id:'chip', name:'Chip', symbol:'◒', subtitle:'Chip de seleção', hint:'Toque para selecionar; o botão responde elasticamente.' },
    { id:'card', name:'Card', symbol:'▣', subtitle:'Cartão de vidro', hint:'Teste o volume e a distorção nas quatro bordas.' },
  ];
  const PARAMS = [
    {id:'thickness',label:'Espessura da borda',min:0,max:100,default:73},
    {id:'depth',label:'Profundidade ±',min:-100,max:100,default:48,hint:'− côncava · + convexa'},
    {id:'lightAngle',label:'Direção da luz',min:0,max:360,default:305,unit:'°'},
    {id:'lightElevation',label:'Altura da luz',min:0,max:100,default:65},
    {id:'shine',label:'Reflexo especular',min:0,max:100,default:62},
    {id:'fresnel',label:'Reflexão Fresnel',min:0,max:100,default:45},
    {id:'gloss',label:'Polimento / nitidez',min:0,max:100,default:70},
    {id:'bloom',label:'Bloom da borda',min:0,max:100,default:35},
    {id:'spill',label:'Vazamento de luz',min:0,max:100,default:42},
    {id:'chromatic',label:'Aberração cromática',min:0,max:100,default:45},
    {id:'blur',label:'Dispersão / desfoque',min:0,max:100,default:12},
    {id:'tint',label:'Coloração do vidro',min:0,max:100,default:11},
    {id:'shadow',label:'Sombra de contato',min:0,max:100,default:40},
    {id:'size',label:'Tamanho do componente',min:0,max:100,default:52},
    {id:'stretch',label:'Elasticidade / esticar',min:0,max:100,default:38},
    {id:'speed',label:'Velocidade da animação',min:0,max:100,default:65},
    {id:'indicatorOpacity',label:'Opacidade do indicador',min:30,max:100,default:93,hint:'Indicadores sólidos; não altera a bolha de vidro'},
    {id:'trackContrast',label:'Contraste da trilha',min:0,max:100,default:65,hint:'Diferencia o canal do indicador'},
  ];
  const DEFAULTS = Object.freeze({strength:68,...Object.fromEntries(PARAMS.map(p=>[p.id,p.default]))});
  const makePreset = (id) => ({...DEFAULTS,
    size: id==='scrollbar'?43:id==='card'?62:id==='tabs'?55:52,
    depth:id==='scrollbar'?38:48,
    motion:true, value: id==='switch'?1:.52, tabIndex:0,selected:false,
    xNorm:.48,yNorm:.49,
  });
  let presets = Object.fromEntries(TYPES.map(t=>[t.id,makePreset(t.id)]));
  let currentType = 'bubble', background='landscape', userPhoto=null, compare=false;
  let w=0,h=0,dpr=1,cx=0,cy=0,previewW=0,previewH=0,minY=0,maxY=0;
  let dragging=false,pointerDown=false,dragOffset={x:0,y:0},lastPoint=null,velocity=0;
  let springValue=.52, springSpeed=0, pulse=0, squash=0,dirty=true,prevFrame=0;
  let gl,program,texture,buffers={},uniforms={},shaderReady=false;
  const p=()=>presets[currentType];
  const scene=document.createElement('canvas');
  const g2=scene.getContext('2d',{alpha:false});
  try{gl=canvas.getContext('webgl2',{alpha:false,antialias:true,powerPreference:'high-performance'});}catch(err){gl=null;}
  const VERT=`#version 300 es
precision highp float;
in vec2 position;
void main(){gl_Position=vec4(position,0.0,1.0);}`;
  const FRAG=`#version 300 es
precision highp float;
out vec4 fragColor;
uniform sampler2D uImage;
uniform vec2 uRes;
uniform int uCount;
uniform vec4 uParts[4]; // centre.xy and halfExtent.zw in framebuffer pixels (bottom-left origin)
uniform vec4 uMeta[4];  // cornerRadius, opticalFactor, opacity, unused
uniform vec4 uFill[4];  // selective material pigmentation + opacity
uniform vec2 uLight;
uniform float uElevation;
uniform float uStrength;
uniform float uRoll;
uniform float uChroma;
uniform float uBlur;
uniform float uShine;
uniform float uDepth;
uniform float uFresnel;
uniform float uGloss;
uniform float uBloom;
uniform float uSpill;
uniform float uTint;
uniform float uShadow;
uniform float uCompare;
vec3 sampleScene(vec2 xy){
  return texture(uImage, clamp(xy/uRes, vec2(.001), vec2(.999))).rgb;
}
vec2 normalFor(vec2 loc,vec2 halfSize,float radius){
  vec2 q=abs(loc)-halfSize+vec2(radius);
  vec2 ext=max(q,vec2(0.));
  if(length(ext)>.0001) return normalize(ext)*sign(loc);
  if(q.x>q.y) return vec2(sign(loc.x),0.);
  return vec2(0.,sign(loc.y));
}
void main(){
  vec2 pos=gl_FragCoord.xy;
  vec3 src=sampleScene(pos);
  if(uCompare>.5){fragColor=vec4(src,1.);return;}
  vec3 accum=src;
  for(int i=0;i<4;i++){
    if(i>=uCount)break;
    vec2 center=uParts[i].xy;
    vec2 halfSize=max(uParts[i].zw,vec2(1.));
    float radius=clamp(uMeta[i].x,.5,min(halfSize.x,halfSize.y));
    vec2 loc=pos-center;
    vec2 q=abs(loc)-halfSize+vec2(radius);
    float d=length(max(q,vec2(0.)))+min(max(q.x,q.y),0.)-radius;
    if(d>34.) continue;
    float aa=max(fwidth(d),.90);
    float mask=1.-smoothstep(-aa,aa,d);
    vec2 outward=normalFor(loc,halfSize,radius);
    float strength=uStrength*uMeta[i].y;
    float haloR=7.+uBloom*13.;
    float shade=max(d,0.);
    float keyAngle=max(dot(outward,uLight),0.);
    float fillAngle=max(dot(outward,-uLight),0.);
    float glow=exp(-pow(shade/max(haloR,.5),2.))*pow(keyAngle,8.)*(uBloom*.24);
    float shadow=exp(-shade/9.)*.29*uShadow*(1.-smoothstep(18.,33.,shade));
    if(mask<.001){
      accum=clamp(accum*(1.-shadow)+vec3(.68,.87,1.)*glow,0.,1.);
      continue;
    }
    float depth=max(-d,0.);
    float roll=max(1.,min(radius*.98,uRoll));
    float curved=pow(clamp(1.-depth/roll,0.,1.),.71);
    float front=sqrt(max(1.-curved*curved,.0007));
    // Concave presets reverse the lateral surface normal and ray deflection.
    float polarity=abs(uDepth)<.008 ? 0. : sign(uDepth);
    vec3 surfaceNormal=normalize(vec3(outward*curved*polarity,front));
    vec3 ray=refract(vec3(0.,0.,-1.),surfaceNormal,1./1.48);
    float signedDepth=abs(uDepth);
    float medium=(roll*.64+4.)*(.38+signedDepth*.96);
    vec2 bend=ray.xy/max(-ray.z,.16)*medium*strength;
    bend-=loc/max(halfSize,vec2(1.))*(1.-curved)*strength*1.05*polarity;
    float maxBend=min(min(halfSize.x,halfSize.y)*.73,11.+strength*38.);
    bend*=min(1.,maxBend/max(length(bend),.001));
    vec2 lookup=pos+bend;
    vec3 col=sampleScene(lookup);
    float blur=uBlur*(.12+curved*curved)*1.25;
    if(blur>.20){
      vec2 offs=vec2(blur,blur*.66);
      col=col*.40+(sampleScene(lookup+offs)+sampleScene(lookup-offs)
       +sampleScene(lookup+vec2(offs.x,-offs.y))
       +sampleScene(lookup+vec2(-offs.x,offs.y)))*.15;
    }
    float fringe=uChroma*curved*curved;
    if(fringe>.07){
      vec2 chroma=outward*fringe;
      col.r=mix(col.r,sampleScene(lookup+chroma).r,.78);
      col.b=mix(col.b,sampleScene(lookup-chroma).b,.78);
    }
    float fresnel=.038+.962*pow(1.-max(front,0.),5.);
    vec3 environment=sampleScene(pos+outward*(7.+roll*.14));
    col=mix(col,mix(vec3(.66,.81,.92),environment,.50),clamp(fresnel*uFresnel*.82,0.,.62));
    vec3 key=normalize(vec3(uLight,uElevation));
    vec3 fill=normalize(vec3(-uLight*.7,.82));
    vec3 h1=normalize(key+vec3(0.,0.,1.));
    vec3 h2=normalize(fill+vec3(0.,0.,1.));
    float exponent=mix(20.,180.,uGloss);
    float spec=pow(max(dot(surfaceNormal,h1),0.),exponent)*.48
      +pow(max(dot(surfaceNormal,h2),0.),exponent*1.55)*.24;
    float edgeBright=pow(keyAngle,8.)*exp(-depth/3.2)*.54;
    float caustic=exp(-pow((depth-roll*.57)/max(1.,roll*.18),2.))
      *pow(fillAngle,3.)*.14;
    vec3 bleed=sampleScene(pos+outward*max(4.,roll*.39));
    col+=bleed*(curved*curved*.07+caustic*.15)*uSpill;
    float highlight=clamp((spec+edgeBright+caustic)*uShine,0.,.82);
    col=mix(col,vec3(.97,.988,1.),highlight);
    col=mix(col,vec3(.75,.87,.95),curved*.13*uTint);
    // Only functional tracks/indicators receive pigment; free glass buttons
    // retain their original transparent refraction. Apply prior to compositing
    // so the thumb is drawn in front of its track, never merged into the glass.
    col=mix(col,uFill[i].rgb,clamp(uFill[i].a,0.,1.)*(1.-.11*curved));
    float opacity=clamp(uMeta[i].z,0.,1.);
    accum=mix(accum,col,mask*opacity);
    accum=clamp(accum-accum*shadow*(1.-mask),0.,1.);
    accum=clamp(accum+vec3(.62,.80,1.)*glow*(1.-mask),0.,1.);
  }
  fragColor=vec4(clamp(accum,0.,1.),1.);
}`;
  function compileShader(type,code){
    const shader=gl.createShader(type);
    gl.shaderSource(shader,code);gl.compileShader(shader);
    if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(shader));
    return shader;
  }
  function initGL(){
    shaderReady=false;
    if(!gl){badge.textContent='WebGL2 indisponível';return;}
    try{
      const vs=compileShader(gl.VERTEX_SHADER,VERT),fs=compileShader(gl.FRAGMENT_SHADER,FRAG);
      program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);
      gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
      gl.useProgram(program);
      const names=['Image','Res','Count','Parts[0]','Meta[0]','Fill[0]','Light','Elevation','Strength','Roll','Chroma','Blur','Shine','Depth','Fresnel','Gloss','Bloom','Spill','Tint','Shadow','Compare'];
      for(const id of names){uniforms[id]=gl.getUniformLocation(program,'u'+id);}
      buffers.quad=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffers.quad);
      gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
      const attr=gl.getAttribLocation(program,'position');gl.enableVertexAttribArray(attr);
      gl.vertexAttribPointer(attr,2,gl.FLOAT,false,0,0);
      texture=gl.createTexture();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.uniform1i(uniforms.Image,0);
      shaderReady=true;badge.textContent='GPU · WebGL2';dirty=true;
    }catch(err){console.error('Glass Lab GLSL:',err);badge.textContent='Erro no shader';}
  }

  function gradientRect(c,x,y,w,h,colors){let g=c.createLinearGradient(x,y,x,y+h);for(let i=0;i<colors.length;i++)g.addColorStop(i/(colors.length-1),colors[i]);c.fillStyle=g;c.fillRect(x,y,w,h);}
  function landscape(c,w,h){
    gradientRect(c,0,0,w,h,['#8cb6d5','#c2d6cf','#c7bd98','#527b73']);
    // Haze and clouds are drawn as overlapping soft elliptical gradients, not sprites.
    const glow=c.createRadialGradient(w*.74,h*.31,5,w*.74,h*.31,w*.63);
    glow.addColorStop(0,'#fff6db9a');glow.addColorStop(.25,'#fff1d042');glow.addColorStop(1,'#fff6d000');
    c.fillStyle=glow;c.fillRect(0,0,w,h);
    for(let i=0;i<20;i++){
      const xx=w*(.03+(i*67%101)/101),yy=h*(.14+(i*27%47)/130),rx=w*(.045+(i%5)*.015);
      c.save();c.translate(xx,yy);c.scale(1,.31);
      let cg=c.createRadialGradient(0,0,0,0,0,rx);cg.addColorStop(0,'#ffffff59');cg.addColorStop(.8,'#f8ffff11');cg.addColorStop(1,'#ffffff00');c.fillStyle=cg;c.beginPath();c.arc(0,0,rx,0,Math.PI*2);c.fill();c.restore();
    }
    function ridge(base, amp, freq, color){c.beginPath();c.moveTo(0,h);
      for(let x=0;x<=w+4;x+=4){let n=Math.sin(x/w*freq*6.28)*amp+Math.sin(x/w*freq*13.2)*amp*.3;
        const yy=h*(base+n);if(x===0)c.lineTo(0,yy);else c.lineTo(x,yy)}
      c.lineTo(w,h);c.closePath();c.fillStyle=color;c.fill();}
    ridge(.49,.06,1.3,'#71898a');ridge(.59,.045,2.2,'#446b63');ridge(.71,.06,2.7,'#315d46');
    c.save();c.beginPath();c.moveTo(w*.31,h);c.bezierCurveTo(w*.53,h*.72,w*.67,h*.59,w*.74,h*.59);
    c.bezierCurveTo(w*.69,h*.74,w*.66,h*.81,w*.79,h);c.closePath();
    let river=c.createLinearGradient(0,h*.6,w,h);river.addColorStop(0,'#457882');river.addColorStop(.48,'#b4c8b2');river.addColorStop(1,'#2c5c65');c.fillStyle=river;c.fill();
    c.clip();for(let k=0;k<50;k++){const y=h*(.59+.41*k/50),x=w*(.4+(Math.sin(k*.7)*.18)),ww=w*(.04+(k/50)*.12);
      c.strokeStyle=`rgba(222,239,224,${.025+(.13*k/50)})`;c.lineWidth=1+k/50*1.5;c.beginPath();c.moveTo(x-ww/2,y);c.lineTo(x+ww/2,y);c.stroke();}c.restore();
    // Trees are soft organic masses, no voxel/pixel texture.
    for(let i=0;i<48;i++){
      const x=w*((i*37%103)/103),y=h*(.59+.13*Math.sin(i*2.7)*.5),r=h*(.035+(i%7)*.004);
      c.fillStyle='rgba(26,64,49,.20)';c.fillRect(x-r*.08,y,r*.16,r*1.4);
      const foliage=c.createRadialGradient(x-r*.2,y-r*.14,r*.02,x,y,r);
      foliage.addColorStop(0,'#70996c');foliage.addColorStop(.65,'#456b4f');foliage.addColorStop(1,'#26513c00');
      c.fillStyle=foliage;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();
    }
    const vignette=c.createRadialGradient(w*.5,h*.46,h*.11,w*.5,h*.45,h*.95);vignette.addColorStop(0,'#10262900');vignette.addColorStop(1,'#091726a6');c.fillStyle=vignette;c.fillRect(0,0,w,h);
  }
  function typography(c,w,h){
    gradientRect(c,0,0,w,h,['#121c2c','#101727','#1a3040']);
    let g=c.createRadialGradient(w*.6,h*.48,0,w*.5,h*.45,w*.75);g.addColorStop(0,'#548eb548');g.addColorStop(1,'#0c152000');c.fillStyle=g;c.fillRect(0,0,w,h);
    c.textAlign='center';
    for(let j=0;j<6;j++){
      let y=h*(.20+j*.11);c.fillStyle=j===2?'rgba(238,249,255,.94)':'rgba(215,238,248,.36)';
      c.font=`${Math.min(65,w*.095)}px system-ui, sans-serif`;
      c.fillText(['REFRAÇÃO REAL','ARRASTE A LENTE','A LUZ MUDA DE DIREÇÃO','SEM IMAGEM PRONTA','O FUNDO SE DEFORMA','GLASS LAB'][j],w*.50,y);
    }
  }
  function grid(c,w,h){
    gradientRect(c,0,0,w,h,['#0c1526','#111f32','#16293b']);
    c.lineWidth=1;
    const step=Math.min(58,Math.max(30,w/13));
    for(let x=0;x<w;x+=step){c.beginPath();c.strokeStyle='rgba(201,237,255,.30)';c.moveTo(x,0);c.lineTo(x,h);c.stroke();}
    for(let y=0;y<h;y+=step){c.beginPath();c.strokeStyle='rgba(201,237,255,.30)';c.moveTo(0,y);c.lineTo(w,y);c.stroke();}
    for(let x=step;x<w;x+=step*2){for(let y=step;y<h;y+=step*2){c.strokeStyle='#d0efff66';c.strokeRect(x-5,y-5,10,10);}}
    c.lineWidth=2;c.strokeStyle='rgba(183,225,245,.6)';c.beginPath();c.moveTo(w*.13,h*.45);c.lineTo(w*.87,h*.45);c.moveTo(w*.5,h*.09);c.lineTo(w*.5,h*.77);c.stroke();
    c.textAlign='center';c.font=`600 ${Math.max(19,Math.min(48,w/16))}px system-ui`;c.fillStyle='#eef9ff';
    c.fillText('TESTE DE DISTORÇÃO',w/2,h*.29);
  }
  function drawBackground(){
    if(!g2)return;
    const w=scene.width,h=scene.height;
    if(background==='typography')typography(g2,w,h);
    else if(background==='grid')grid(g2,w,h);
    else if(userPhoto&&background==='photo'){
      const i=userPhoto,scale=Math.max(w/i.width,h/i.height),sw=i.width*scale,sh=i.height*scale;
      g2.fillStyle='#162334';g2.fillRect(0,0,w,h);g2.drawImage(i,(w-sw)/2,(h-sh)/2,sw,sh);
      const ov=g2.createLinearGradient(0,0,0,h);ov.addColorStop(0,'#040a168a');ov.addColorStop(.22,'#0611240e');ov.addColorStop(1,'#0108166a');g2.fillStyle=ov;g2.fillRect(0,0,w,h);
    } else landscape(g2,w,h);
    // Calibration typography really lives in the source texture, behind the lens.
    if(background==='landscape'||background==='photo'){
      g2.textAlign='center';g2.textBaseline='middle';
      g2.shadowColor='rgba(0,0,0,.39)';g2.shadowBlur=9*dpr;g2.shadowOffsetY=2*dpr;
      g2.font=`700 ${Math.round(Math.max(23,Math.min(46,w*.065)))}px system-ui`;
      g2.fillStyle='rgba(252,254,255,.89)';g2.fillText('O VIDRO DEFORMA O FUNDO',w*.50,h*.42,w*.92);
      g2.font=`500 ${Math.round(Math.max(11,Math.min(19,w*.026)))}px system-ui`;
      g2.fillStyle='rgba(254,254,255,.81)';g2.fillText('Passe a lente por estas letras e pelas margens da paisagem',w*.50,h*.50,w*.90);
      g2.shadowColor='transparent';g2.shadowBlur=0;g2.shadowOffsetY=0;
    }
    if(gl&&program){
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,scene);
    }
    dirty=true;
  }
  function asNumber(v,fallback,min,max){
    const n=Number(v);return Number.isFinite(n)?Math.min(max,Math.max(min,n)):fallback;
  }
  function restore(){
    try{
      const saved=JSON.parse(localStorage.getItem('glasslab-v2-presets')||'null');
      if(!saved||saved.schemaVersion!==2)return;
      for(const type of TYPES){
        const data=saved.presets?.[type.id];if(!data)continue;
        const target=makePreset(type.id);
        for(const def of [{id:'strength',min:0,max:100,default:68},...PARAMS]){
          target[def.id]=asNumber(data[def.id],target[def.id],def.min,def.max);
        }
        target.value=asNumber(data.value,target.value,0,1);
        target.tabIndex=Math.round(asNumber(data.tabIndex,0,0,2));
        target.selected=Boolean(data.selected);
        target.motion=data.motion!==false;
        target.xNorm=asNumber(data.xNorm,.48,0,1);
        target.yNorm=asNumber(data.yNorm,.49,0,1);
        presets[type.id]=target;
      }
      if(TYPES.some(t=>t.id===saved.active))currentType=saved.active;
      if(['landscape','typography','grid'].includes(saved.background))background=saved.background;
    }catch(err){console.warn('Preset storage unavailable',err);}
  }
  let saveTimer=null;
  function store(){
    if(saveTimer)clearTimeout(saveTimer);
    saveTimer=setTimeout(()=>{
      try{localStorage.setItem('glasslab-v2-presets',JSON.stringify({schemaVersion:2,active:currentType,background,presets}));}
      catch(err){console.warn('Cannot persist presets',err);}
      saveTimer=null;
    },140);
  }
  function currentTypeInfo(){return TYPES.find(t=>t.id===currentType)||TYPES[0];}
  function widthBounds(){
    // The editing panel lives beside the optics in short landscape mode.
    const side=w/h>1.35 && h<630;
    const panelRect=controls.getBoundingClientRect();
    previewW=side?Math.max(230,w-panelRect.width-32):w;
    previewH=side?h:Math.max(260,h-panelRect.height-16);
    minY=67;
    maxY=previewH-12;
  }
  function sizeBase(){
    const base=Math.max(34,Math.min(previewW*.21,previewH*.23));
    return base*(.65+p().size*.0061);
  }
  function geometry(){
    const r=sizeBase(),type=currentType;
    let bw=2*r,bh=2*r,corner=r;
    if(type==='square'){corner=r*.34;}
    else if(type==='pill'){bw=r*3.45;bh=r*1.16;corner=bh*.5;}
    else if(type==='icon'){bw=bh=r*1.43;corner=bw*.5;}
    else if(type==='chip'){bw=r*2.75;bh=r*.84;corner=bh*.5;}
    else if(type==='card'){bw=r*3.15;bh=r*1.77;corner=r*.39;}
    else if(type==='switch'){bw=r*2.75;bh=r*1.12;corner=bh*.5;}
    else if(type==='slider'){bw=r*4.05;bh=r*.54;corner=bh*.5;}
    else if(type==='scrollbar'){bw=r*.64;bh=r*3.2;corner=bw*.5;}
    else if(type==='tabs'){bw=r*4.22;bh=r*.92;corner=bh*.5;}
    const available=previewW-25;
    if(bw>available){const shrink=available/bw;bw*=shrink;bh*=shrink;corner*=shrink;}
    if(bh>previewH-minY-24){const shrink=Math.max(.25,(previewH-minY-24)/bh);bw*=shrink;bh*=shrink;corner*=shrink;}
    return {w:bw,h:bh,r:corner};
  }
  function constrain(){
    widthBounds();const b=geometry();
    const lowX=b.w*.5+9,highX=Math.max(lowX,previewW-b.w*.5-9);
    const lowY=minY+b.h*.5+10,highY=Math.max(lowY,maxY-b.h*.5-10);
    cx=Math.max(lowX,Math.min(highX,cx||previewW*.48));
    cy=Math.max(lowY,Math.min(highY,cy||((lowY+highY)*.5)));
    p().xNorm=cx/Math.max(previewW,1);p().yNorm=cy/Math.max(previewH,1);
  }
  function geometryAt(x,y,wid,hei,rad,optical=.9,opacity=1,kind='surface'){
    return {x,y,w:wid,h:hei,r:rad,optical,opacity,kind};
  }
  function visualParts(){
    const b=geometry();
    const dragScale=(dragging&&p().motion)?Math.min(1.0,Math.abs(velocity)*p().stretch*.00008):0;
    const tapScale=p().motion?pulse*.055:0;
    const stretch=(dragScale+tapScale);
    const parts=[];
    const add=(x,y,wid,hei,rad,optical,opacity,kind)=>parts.push(geometryAt(x,y,wid,hei,rad,optical,opacity,kind));
    if(['bubble','square','pill','icon','chip','card'].includes(currentType)){
      add(cx,cy,b.w*(1+stretch),b.h*(1-stretch*.58),b.r,1,1,'body');
      return parts;
    }
    // Track first, moving thumb second; both have separate SDF and refraction.
    if(currentType==='slider'){
      const thumbR=b.h*.92;
      add(cx,cy,b.w,b.h,b.r,.34,.82,'track');
      const x=cx-b.w*.5+thumbR+(b.w-2*thumbR)*springValue;
      add(x,cy,thumbR*2*(1+stretch*.28),thumbR*2*(1-stretch*.10),thumbR,1.32,1,'thumb');
    }else if(currentType==='scrollbar'){
      const thumbH=b.h*.29,thumbW=b.w*1.3;
      add(cx,cy,b.w,b.h,b.r,.28,.78,'track');
      const y=cy-b.h*.5+thumbH*.5+(b.h-thumbH)*springValue;
      add(cx,y,thumbW,thumbH,b.w*.41,1.4,1,'thumb');
    }else if(currentType==='switch'){
      const thumbR=b.h*.42;
      add(cx,cy,b.w,b.h,b.r,.40,.80,'track');
      const x=cx-b.w*.5+b.h*.5+(b.w-b.h)*springValue;
      add(x,cy,thumbR*2*(1+stretch*.20),thumbR*2*(1-stretch*.09),thumbR,1.43,1,'thumb');
    }else if(currentType==='tabs'){
      const per=b.w/3;
      add(cx,cy,b.w,b.h,b.r,.38,.86,'track');
      const tabWidth=per-8;
      const x=cx-b.w*.5+per*.5+(b.w-per)*springValue;
      add(x,cy,tabWidth,b.h-9,Math.min((b.h-9)*.5,b.r),1.29,.99,'thumb');
    }
    return parts;
  }
  function renderLabels(parts){
    const type=currentType,b=geometry();
    const markup=[];
    const label=(x,y,html,cls='')=>markup.push(`<div class="piece-text ${cls}" style="left:${x.toFixed(1)}px;top:${y.toFixed(1)}px">${html}</div>`);
    if(type==='bubble'){label(cx,cy,'<span class="glyph">⌂</span><span>Home</span>','');}
    if(type==='square'){label(cx,cy,'<span class="glyph">▢</span><span>Glass</span>');}
    if(type==='pill'){label(cx,cy,'<span class="glyph">▶</span><span>Play Minecraft</span>');}
    if(type==='icon'){label(cx,cy,'<span class="glyph">⚙</span>');}
    if(type==='chip'){label(cx,cy,'<span class="glyph">✓</span><span>Selecionado</span>',p().selected?'active':'dim');}
    if(type==='card'){label(cx,cy-5,'<span class="glyph">◈</span><span>Glass Card</span>');}
    if(type==='slider'){
      label(cx,cy+b.h+25,`<span class="small">VALOR • ${Math.round(springValue*100)}%</span>`);
    }
    if(type==='scrollbar'){
      label(cx+b.w*.5+56,cy,`<span class="small">SCROLL<br>${Math.round(springValue*100)}%</span>`,'readout');
    }
    if(type==='switch'){
      label(cx,cy+b.h+26,`<span class="small">${p().value>.5?'LIGADO':'DESLIGADO'}</span>`);
    }
    if(type==='tabs'){
      ['Home','Mods','Shaders'].forEach((name,i)=>{
        const x=cx-b.w*.5+b.w/6+i*b.w/3;
        label(x,cy,name,Math.round(springValue*2)===i?'active':'dim');
      });
    }
    overlay.innerHTML=markup.join('');
  }
  function uniformsAndDraw(time){
    if(!shaderReady)return;
    const conf=p(),parts=visualParts();
    const packed=new Float32Array(16),meta=new Float32Array(16),fills=new Float32Array(16);
    // The track is a contrasting satin channel, and each thumb is a legible
    // independent material. The scrollbar keeps its intentional OVERHANG.
    const controlWithTrack=['slider','scrollbar','switch','tabs'].includes(currentType);
    const contrast=conf.trackContrast/100,indicator=conf.indicatorOpacity/100;
    for(let i=0;i<parts.length && i<4;i++){
      const a=parts[i],j=i*4;
      packed[j]=a.x*dpr;packed[j+1]=(h-a.y)*dpr;
      packed[j+2]=a.w*.5*dpr;packed[j+3]=a.h*.5*dpr;
      meta[j]=a.r*dpr;meta[j+1]=a.optical;meta[j+2]=a.opacity;meta[j+3]=0;
      let material=[0,0,0,0]; // zero tint = truly refracting glass
      if(controlWithTrack && a.kind==='track') {
        // Dark, transparent slate makes the track visible over busy photos.
        material=[.045,.105,.145,.15+contrast*.52];
      } else if(controlWithTrack && a.kind==='thumb') {
        // Slider / switch knobs are satin, not see-through. Tabs have a
        // slightly darker thumb so their white names stay readable.
        material=currentType==='tabs'
          ? [.16,.29,.37,indicator*.85]
          : currentType==='scrollbar'
            ? [.70,.87,.93,indicator*.94]
            : [.76,.90,.95,indicator];
      }
      fills.set(material,j);
    }
    gl.useProgram(program);gl.viewport(0,0,canvas.width,canvas.height);
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
    gl.uniform2f(uniforms.Res,canvas.width,canvas.height);
    gl.uniform1i(uniforms.Count,parts.length);
    gl.uniform4fv(uniforms['Parts[0]'],packed);
    gl.uniform4fv(uniforms['Meta[0]'],meta);
    gl.uniform4fv(uniforms['Fill[0]'],fills);
    const angle=conf.lightAngle*Math.PI/180;
    const drift=(conf.motion?Math.sin(time*.00038)*.045:0);
    gl.uniform2f(uniforms.Light,Math.cos(angle+drift),Math.sin(angle+drift));
    gl.uniform1f(uniforms.Elevation,.28+conf.lightElevation*.014);
    gl.uniform1f(uniforms.Strength,(conf.strength/100)*1.65);
    gl.uniform1f(uniforms.Roll,(6+conf.thickness*.36)*dpr);
    gl.uniform1f(uniforms.Chroma,conf.chromatic*.034*dpr);
    gl.uniform1f(uniforms.Blur,conf.blur*.028*dpr);
    gl.uniform1f(uniforms.Shine,conf.shine*.018);
    gl.uniform1f(uniforms.Depth,conf.depth/100);
    gl.uniform1f(uniforms.Fresnel,conf.fresnel*.021);
    gl.uniform1f(uniforms.Gloss,conf.gloss/100);
    gl.uniform1f(uniforms.Bloom,conf.bloom/100);
    gl.uniform1f(uniforms.Spill,conf.spill/100);
    gl.uniform1f(uniforms.Tint,conf.tint/100);
    gl.uniform1f(uniforms.Shadow,conf.shadow/100);
    gl.uniform1f(uniforms.Compare,compare?1:0);
    gl.drawArrays(gl.TRIANGLES,0,6);
    renderLabels(parts);
    overlay.style.visibility=compare?'hidden':'visible';
  }
  function animate(now){
    requestAnimationFrame(animate);
    const dt=Math.min(.04,Math.max(.001,(now-(prevFrame||now-16))/1000));prevFrame=now;
    const conf=p();
    if(['slider','switch','scrollbar','tabs'].includes(currentType)){
      const desired=currentType==='tabs'?conf.tabIndex/2:conf.value;
      if(conf.motion){
        const stiffness=65+conf.speed*2.2;
        const damping=10+(100-conf.stretch)*.10;
        springSpeed+=(desired-springValue)*stiffness*dt;
        springSpeed*=Math.exp(-damping*dt);
        springValue+=springSpeed*dt;
        if(Math.abs(springValue-desired)<.0001 && Math.abs(springSpeed)<.002){springValue=desired;springSpeed=0;}
        if(Math.abs(springSpeed)>.001||Math.abs(desired-springValue)>.001)dirty=true;
      }else{springValue=desired;springSpeed=0;}
    }
    pulse=Math.max(0,pulse-dt*(1.1+conf.speed/80));
    if(pulse>0||dragging)dirty=true;
    if(dirty || now-prevFrame>200){
      dirty=false;
      uniformsAndDraw(now);
    }
  }
  function resize(){
    const prevW=previewW||0,prevH=previewH||0;
    w=canvas.clientWidth;h=canvas.clientHeight;
    dpr=Math.min(window.devicePixelRatio||1,2);
    canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
    scene.width=canvas.width;scene.height=canvas.height;
    widthBounds();
    if(prevW && prevH){cx=cx/prevW*previewW;cy=cy/prevH*previewH;}
    else{cx=p().xNorm*previewW;cy=p().yNorm*previewH;}
    constrain();
    if(gl)gl.viewport(0,0,canvas.width,canvas.height);
    drawBackground();dirty=true;
  }
  function typeChange(id){
    if(!TYPES.some(t=>t.id===id))return;
    p().xNorm=cx/Math.max(previewW,1);p().yNorm=cy/Math.max(previewH,1);
    currentType=id;
    cx=p().xNorm*previewW;cy=p().yNorm*previewH;
    constrain();
    springValue=currentType==='tabs'?p().tabIndex/2:p().value;
    springSpeed=0;pulse=.38;
    const current=currentTypeInfo();
    $('previewName').textContent=current.subtitle;$('previewHelp').textContent=current.hint;
    document.querySelectorAll('.type-chip').forEach(b=>b.classList.toggle('selected',b.dataset.type===id));
    syncSliders();store();dirty=true;
  }
  function setVal(v){
    if(currentType==='tabs'){
      p().tabIndex=Math.round(Math.min(2,Math.max(0,v*2)));p().value=p().tabIndex/2;
    }else p().value=Math.min(1,Math.max(0,v));
    store();pulse=.75;dirty=true;
  }
  function pointerPos(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}
  function updateFromPoint(pt){
    const b=geometry();
    if(currentType==='slider'){
      const thumb=b.h*.92;
      const left=cx-b.w*.5+thumb;
      setVal((pt.x-left)/(b.w-2*thumb));
    }else if(currentType==='scrollbar'){
      const thumbH=b.h*.29;
      setVal((pt.y-(cy-b.h*.5+thumbH*.5))/(b.h-thumbH));
    }else if(currentType==='switch'){
      setVal(pt.x>=cx?.999:.001);
    }else if(currentType==='tabs'){
      setVal(Math.round(Math.min(2,Math.max(0,(pt.x-(cx-b.w*.5))/b.w*3-.5)))/2);
    }else if(currentType==='chip'){
      p().selected=!p().selected;pulse=.95;store();dirty=true;
    }
  }
  canvas.addEventListener('pointerdown',e=>{
    if(e.pointerType==='mouse'&&e.button!==0)return;
    const pos=pointerPos(e),b=geometry();
    const near=Math.abs(pos.x-cx)<b.w*.5+19 && Math.abs(pos.y-cy)<b.h*.5+19;
    dragging=true;pointerDown=true;lastPoint={...pos,time:performance.now()};
    canvas.classList.add('dragging');canvas.setPointerCapture(e.pointerId);
    if(['slider','scrollbar','switch','tabs','chip'].includes(currentType)){
      if(near)updateFromPoint(pos);
      else dragging=false;
    }else{
      dragOffset=near?{x:cx-pos.x,y:cy-pos.y}:{x:0,y:0};
      cx=pos.x+dragOffset.x;cy=pos.y+dragOffset.y;constrain();
      pulse=.40;
    }
    dirty=true;
  });
  canvas.addEventListener('pointermove',e=>{
    if(!pointerDown||!dragging)return;
    const pt=pointerPos(e);
    if(lastPoint){
      const dt=Math.max(9,performance.now()-lastPoint.time);
      velocity=.75*velocity+.25*Math.hypot(pt.x-lastPoint.x,pt.y-lastPoint.y)/dt*1000;
      lastPoint={...pt,time:performance.now()};
    }
    if(['slider','scrollbar','switch','tabs'].includes(currentType))updateFromPoint(pt);
    else if(currentType!=='chip'){
      cx=pt.x+dragOffset.x;cy=pt.y+dragOffset.y;constrain();
    }
    dirty=true;
  });
  const stopPointer=e=>{if(!pointerDown)return;pointerDown=false;dragging=false;velocity=0;pulse=.75;
    canvas.classList.remove('dragging');store();dirty=true;};
  canvas.addEventListener('pointerup',stopPointer);
  canvas.addEventListener('pointercancel',stopPointer);
  canvas.addEventListener('lostpointercapture',stopPointer);
  canvas.addEventListener('wheel',e=>{
    if(currentType!=='scrollbar')return;
    e.preventDefault();setVal(p().value+Math.sign(e.deltaY)*.08);
  },{passive:false});
  function buildControls(){
    $('componentPicker').innerHTML=TYPES.map(t=>`<button type="button" role="tab" aria-selected="false" data-type="${t.id}" class="type-chip"><span class="symbol">${t.symbol}</span>${t.name}</button>`).join('');
    document.querySelectorAll('[data-type]').forEach(b=>b.addEventListener('click',()=>typeChange(b.dataset.type)));
    $('advancedGrid').innerHTML=PARAMS.map(d=>`<label class="parameter" for="${d.id}">${d.label} <output id="${d.id}Value"></output>${d.hint?`<span class="hint">${d.hint}</span>`:''}<input id="${d.id}" type="range" min="${d.min}" max="${d.max}" step="1" value="${d.default}" /></label>`).join('');
    [{id:'strength',min:0,max:100},...PARAMS].forEach(d=>{
      $(d.id).addEventListener('input',e=>{
        const num=asNumber(e.target.value,p()[d.id],d.min,d.max);
        p()[d.id]=num;
        $(d.id+'Value').textContent=num+(d.unit||'%');
        constrain();store();dirty=true;
      });
    });
    $('motionEnabled').addEventListener('change',e=>{p().motion=e.target.checked;store();dirty=true;});
    $('resetCurrent').addEventListener('click',()=>{
      presets[currentType]=makePreset(currentType);
      springValue=currentType==='tabs'?0:p().value;springSpeed=0;
      cx=p().xNorm*previewW;cy=p().yNorm*previewH;constrain();syncSliders();store();dirty=true;
    });
    $('resetAll').addEventListener('click',()=>{
      presets=Object.fromEntries(TYPES.map(t=>[t.id,makePreset(t.id)]));
      typeChange('bubble');background='landscape';setBackgroundButtons();drawBackground();store();
    });
  }
  function syncSliders(){
    for(const d of [{id:'strength'},...PARAMS]){
      $(d.id).value=p()[d.id];
      $(d.id+'Value').textContent=p()[d.id]+((PARAMS.find(x=>x.id===d.id)?.unit)||'%');
    }
    // These settings apply only to controls with a separate track and thumb.
    const hasThumb=['slider','scrollbar','switch','tabs'].includes(currentType);
    for(const id of ['indicatorOpacity','trackContrast']) $(id).closest('.parameter').hidden=!hasThumb;
    $('motionEnabled').checked=p().motion;
    document.querySelectorAll('[data-type]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.type===currentType)));
  }
  function setBackgroundButtons(){
    document.querySelectorAll('[data-scene]').forEach(b=>b.classList.toggle('selected',b.dataset.scene===background));
    $('photo').classList.toggle('selected',background==='photo');
  }
  function bindScenes(){
    document.querySelectorAll('[data-scene]').forEach(b=>b.addEventListener('click',()=>{
      background=b.dataset.scene;setBackgroundButtons();drawBackground();store();
    }));
    $('photo').addEventListener('click',()=>$('photoFile').click());
    $('photoFile').addEventListener('change',e=>{
      const f=e.target.files?.[0];if(!f||!f.type.startsWith('image/'))return;
      const url=URL.createObjectURL(f),img=new Image();
      img.onload=()=>{userPhoto=img;background='photo';URL.revokeObjectURL(url);setBackgroundButtons();drawBackground();};
      img.onerror=()=>URL.revokeObjectURL(url);img.src=url;
    });
    $('compare').addEventListener('click',()=>{compare=!compare;
      $('compare').classList.toggle('active',compare);
      $('compare').textContent=compare?'Mostrar vidro':'Comparar';
      $('compareMark').hidden=!compare;dirty=true;
    });
  }
  function exportData(){
    const type=currentTypeInfo(),data=p(),props={};
    for(const key of Object.keys(DEFAULTS))props[key]=data[key];
    const b=geometry();
    const shaderUniforms={strength:props.strength/100*1.65,roll_px_per_css_scale:6+props.thickness*.36,
      depthSigned:props.depth/100,chromatic_px_per_css_scale:props.chromatic*.034,
      blur_px_per_css_scale:props.blur*.028,shine:props.shine*.018,
      lightDirection:[Math.cos(props.lightAngle*Math.PI/180),Math.sin(props.lightAngle*Math.PI/180)],
      lightElevation:.28+props.lightElevation*.014,fresnel:props.fresnel*.021,
      gloss:props.gloss/100,bloom:props.bloom/100,spill:props.spill/100,
      tint:props.tint/100,shadow:props.shadow/100};
    return {
      format:'GLASS_LAB_PRESET_V2',schemaVersion:2,name:$('presetName').value.trim()||type.subtitle,
      createdAt:new Date().toISOString(),app:'Glass Lab 2.1',sourceProject:'Horizon / experiments/glass-lab',
      component:{type:type.id,label:type.subtitle,interaction:type.hint,
        geometryCss:{width:b.w,height:b.h,cornerRadius:b.r},
        centerNormalized:[data.xNorm,data.yNorm],value:data.value,
        switchOn:type.id==='switch'?data.value>.5:null,
        tabIndex:type.id==='tabs'?data.tabIndex:null,
        chipSelected:type.id==='chip'?data.selected:null},
      opticalParameters:props,
      animation:{enabled:data.motion,elasticity:props.stretch,
        speed:props.speed,type:['switch','slider','scrollbar','tabs'].includes(type.id)?'damped-spring':'stretch-and-release',
        spring:{stiffness:65+props.speed*2.2,damping:10+(100-props.stretch)*.10},
        notes:'Movimento com indicador interpolado; pequenas deformações elásticas durante o toque.'},
      background:{type:background,photoEmbedded:false,
        note:'Fotos locais não são exportadas para preservar privacidade.'},
      rendering:{engine:'WebGL2 GLSL ES 3.00',shaderRevision:'GLASS_LAB_GLASS_READABILITY_V2_1',
        framebufferOrigin:'bottom-left',geometryCoordinate:'CSS pixels top-left, converted using dpr',
        depthConvention:'>0 convex positive curvature; <0 concave negative; 0 flat',
        uniformValues:shaderUniforms,material:{indicatorOpacity:props.indicatorOpacity,trackContrast:props.trackContrast,glassButtonsRemainClear:true},
        stackedParts:['slider','scrollbar','switch','tabs'].includes(type.id)?'base track + separately refracting moving thumb':'single optical body',
        note:'O GLSL abaixo está incluído para portabilidade. No Horizon Rust/WGSL, reimplementar amostragem sobre backdrop, coordenadas, uniforms e animações.'},
      glslFragmentSource:FRAG,
    };
  }
  function exportPayload(){
    return 'GLASS_LAB_PRESET_V2\n# Configuração exportada pelo Glass Lab 2.0\n# O JSON abaixo inclui os valores, estados e código GLSL para adaptação.\n\n'
      +JSON.stringify(exportData(),null,2)+'\n';
  }
  function filenameForPreset(){
    const slug=($('presetName').value||currentType).toLowerCase().normalize('NFD')
      .replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,45)||'vidro';
    return 'GlassLab_'+currentType+'_'+slug+'.txt';
  }
  function showExportFeedback(msg){$('exportFeedback').textContent=msg;}
  function showExport(){
    $('presetName').value='Vidro '+currentTypeInfo().name;
    $('exportTitle').textContent='Exportar '+currentTypeInfo().name;
    showExportFeedback('');$('exportDialog').hidden=false;
  }
  function hideExport(){$('exportDialog').hidden=true;}
  function browserDownload(filename,payload){
    const blob=new Blob([payload],{type:'text/plain;charset=utf-8'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),3000);
  }
  function bindExport(){
    $('exportPreset').addEventListener('click',showExport);
    $('closeExport').addEventListener('click',hideExport);
    $('exportDialog').addEventListener('click',e=>{if(e.target===$('exportDialog'))hideExport();});
    $('saveTxt').addEventListener('click',()=>{
      const txt=exportPayload(),name=filenameForPreset();
      try{
        if(window.GlassLabExport && typeof window.GlassLabExport.savePreset==='function'){
          window.GlassLabExport.savePreset(name,txt);
          showExportFeedback('Escolha a pasta e confirme o salvamento do arquivo TXT.');
        }else{
          browserDownload(name,txt);
          showExportFeedback('O navegador iniciou o download do TXT.');
        }
      }catch(err){showExportFeedback('Erro ao exportar: '+err.message);}
    });
    $('copyPreset').addEventListener('click',async()=>{
      const txt=exportPayload();
      try{
        if(navigator.clipboard && navigator.clipboard.writeText){await navigator.clipboard.writeText(txt);}
        else{const ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);ta.select();
          if(!document.execCommand('copy'))throw Error('Área de transferência indisponível');ta.remove();}
        showExportFeedback('Preset copiado. Envie o código ou o TXT.');
      }catch(err){showExportFeedback('Não foi possível copiar. Use Salvar TXT.');}
    });
    $('importButton').addEventListener('click',()=>$('importFile').click());
    $('importFile').addEventListener('change',async e=>{
      const f=e.target.files?.[0];if(!f)return;
      try{
        const txt=await f.text();const start=txt.indexOf('{');
        if(start<0)throw Error('O arquivo não contém JSON');
        const imported=JSON.parse(txt.slice(start));
        if(imported.format!=='GLASS_LAB_PRESET_V2'||imported.schemaVersion!==2)
          throw Error('Formato do preset incompatível');
        const type=imported.component?.type;
        if(!TYPES.some(x=>x.id===type))throw Error('Tipo de componente não reconhecido');
        const obj=makePreset(type),src=imported.opticalParameters||{};
        for(const d of [{id:'strength',min:0,max:100},...PARAMS]){
          obj[d.id]=asNumber(src[d.id],obj[d.id],d.min,d.max);
        }
        obj.motion=imported.animation?.enabled!==false;
        obj.value=asNumber(imported.component?.value,obj.value,0,1);
        obj.tabIndex=Math.round(asNumber(imported.component?.tabIndex,obj.tabIndex,0,2));
        obj.selected=Boolean(imported.component?.chipSelected);
        const center=imported.component?.centerNormalized||[.48,.49];
        obj.xNorm=asNumber(center[0],.48,0,1);obj.yNorm=asNumber(center[1],.49,0,1);
        presets[type]=obj;typeChange(type);store();
        $('presetName').value=imported.name||'Preset importado';
        showExportFeedback('Preset '+type+' importado com sucesso.');
      }catch(err){showExportFeedback('Falha ao importar: '+err.message);}
      e.target.value='';
    });
  }
  window.glassLabOnExport=function(ok,message){
    showExportFeedback(ok?'Arquivo TXT salvo com sucesso.':(message||'Exportação cancelada.'));
  };
  function start(){
    restore();buildControls();bindScenes();bindExport();initGL();
    resize();typeChange(currentType);setBackgroundButtons();
    requestAnimationFrame(animate);
    window.addEventListener('resize',resize);
    window.addEventListener('orientationchange',()=>setTimeout(resize,240));
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)dirty=true;});
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();shaderReady=false;badge.textContent='GPU reiniciando';});
    canvas.addEventListener('webglcontextrestored',()=>{initGL();resize();});
  }
  start();
})();
