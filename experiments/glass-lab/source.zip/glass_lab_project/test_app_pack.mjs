// Actual Glass Lab app integration smoke, no browser or third-party dependencies.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { mkdtempSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { execFileSync } from 'node:child_process';
const script=fs.readFileSync(new URL('./web-demo/app.js',import.meta.url),'utf8');
const gradient=()=>({addColorStop(){}});
const ctx2d=new Proxy({}, {get(target,key){
  if(key==='createLinearGradient'||key==='createRadialGradient')return gradient;
  if(key==='getImageData')return ()=>({data:new Uint8ClampedArray([50,70,90,255])});
  return target[key]??(()=>{});
},set(target,key,value){target[key]=value;return true;}});
class Element {
  constructor(id){this.id=id;this.innerHTML='';this.value='';this.textContent='';this.style={};this.dataset={};this.hidden=false;this.checked=true;this.classList={add(){},remove(){},toggle(){}};this.clientWidth=id==='view'?1280:350;this.clientHeight=id==='view'?720:680;}
  addEventListener(){} setAttribute(){} closest(){return new Element('closest');}
  getBoundingClientRect(){return {width:350,height:680,left:0,top:0};}
  getContext(name){return name==='webgl2'?null:ctx2d;}
  getBoundingClientRect(){return {width:350,height:480,left:0,top:0};}
  setPointerCapture(){}
}
const elements=new Map();const el=id=>{if(!elements.has(id))elements.set(id,new Element(id));return elements.get(id);};
const document={getElementById:el,querySelector(){return el('controls');},querySelectorAll(){return []},addEventListener(){},createElement(tag){return new Element(tag)},body:el('body')};
const win={location:{search:'?test=1'},devicePixelRatio:1,addEventListener(){}};
const localStorage={getItem(){return null},setItem(){}};
const sandbox={document,window:win,location:win.location,localStorage,console,
  TextEncoder,Blob,Uint8Array,Uint8ClampedArray,Float32Array,DataView,
  performance:{now:()=>16},requestAnimationFrame(){},setTimeout(){return 0},clearTimeout(){},
  URL,Math,Date,Number,JSON,Array,Object,Map,Set,Error,Image:function(){},
};
vm.createContext(sandbox);vm.runInContext(script,sandbox,{timeout:12000});
assert.ok(win.__glassLabV5,'missing test bridge');
const app=win.__glassLabV5;
assert.equal(Object.keys(app.getStyles().oldschool).length,10);
const previous=app.getStyles().liquid.bubble.retroChrome;
app.setGlobalLook('oldschool','retroChrome',99);
for(const state of Object.values(app.getStyles().oldschool))assert.equal(state.retroChrome,99);
assert.equal(app.getStyles().liquid.bubble.retroChrome,previous);
const {blob,files}=app.packFiles();
assert.ok(blob.size>20000);assert.equal(files.length,26);
const folder=mkdtempSync(join(tmpdir(),'glasslab-real-app-'));
const file=join(folder,'bundle.zip');fs.writeFileSync(file,new Uint8Array(await blob.arrayBuffer()));
execFileSync('unzip',['-t',file],{stdio:'pipe'});
const names=execFileSync('unzip',['-Z','-1',file],{encoding:'utf8'}).trim().split('\n');
assert.equal(names.filter(n=>n.startsWith('presets/')).length,20);
const manifest=JSON.parse(execFileSync('unzip',['-p',file,'manifest.json'],{encoding:'utf8'}));
assert.equal(manifest.componentCount,20);
const scroll=execFileSync('unzip',['-p',file,'presets/oldschool/scrollbar.txt'],{encoding:'utf8'});
assert.match(scroll,/GLASS_LAB_PRESET_V5/);
assert.match(scroll,/"type": "scrollbar"/);
assert.ok(scroll.includes('"retroChrome": 99'));
console.log('Glass Lab V5: 20 presets em ZIP válido; aparência global sincronizada e estilos isolados.');
