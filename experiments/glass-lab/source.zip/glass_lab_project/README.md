# Glass Lab 6.0 — Particle & SFX Studio

Standalone Android app (`com.glasslab.optics`), **not part of Horizon**. Two fully independent style profiles: Liquid Glass and Old School / Dark Aero. All 10 controls share the optical look within their current style, while preserving independent size, motion, and particle activation.

## Changes

- Dark Aero / Old School `scrollbar` and `slider` thumbs can use **opaque brushed-metal shading** computed in real time in the existing WebGL2 GLSL material (`effectiveFinish=3`). The track remains independently shaded and the approved scrollbar thumb geometry stays intact.
- New minimal **physical particle layer**, hardware-accelerated canvas with bounded particle counts (max 28), velocity/damping/gravity, reduced-motion support, only emitted during real user interaction; per-style master enable and per-component enable.
- 66 user-provided sound effects organized into **eight groups**: Modern, Minimalist, Retro, Abstract, African, Coffee, Wood Block, Ultimate UI HD. Sounds are transcoded to compact Ogg Opus samples for offline local Android playback.
- Per-style sound bank settings: enabled, primary group, second group, mix on/off, mix percentage, volume. No automatic music/sounds without user action. Slide audio is rate-limited. Defaults: Liquid Glass=Modern, Old School=Retro.
- `Baixar pack` includes all 20 updated/unedited optical presets, both shaders, per-style particle and sound configuration, sound catalog, and credits. On Android, the native SAF export appends all **66 bundled sounds** under `audio/files/` to the portable ZIP.
- Each TXT exports `GLASS_LAB_PRESET_V6` with the component's optics, real-time GLSL, particle settings, and per-style sound profile. Older V2–V5 TXT files and V3–V5 settings are supported.

## Security and accessibility

- No internet, network permissions, account access, Horizon saves, or media storage access. Photos use the Android system document picker; sound files load only from bundled app assets.
- Effects are optional with a global style switch and local component switch. `prefers-reduced-motion` suppresses particle animation, and all controls have visible labels.
- Audio volume is deliberately conservative. `audio.js` never initiates playback unless the user interacts.
- Do not distribute third-party audio files as a standalone library; see `CREDITS_SFX.md` for credits/license references.

## Build and test

Java 17, Android SDK 35, Gradle 8.9:

```bash
node --check web-demo/app.js
node test_app_pack.mjs
node test_pack_runtime.cjs
node test_physics.mjs
node test_effects.cjs
gradle :app:assembleDebug
```

GitHub Actions additionally validates the GLSL ES 3.00 shader through `glslangValidator` and attaches the APK to the workflow run. Local host Chromium can run the HTML demo via a simple HTTP server if WebGL2 is available.
