# Glass Lab 2.0 — Preset Studio

Aplicativo **independente do Horizon**, rodando inteiramente offline no Android ou em navegadores com WebGL2. Permite experimentar um material óptico de vidro, com refração em tempo real, e **exportar presets autocontidos em TXT** para posterior implementação no launcher.

## Componentes (cada um guarda suas próprias configurações)

- **Bolha**: lente esférica transparente arrastável.
- **Quadrado**: botão de vidro quadrado com cantos arredondados.
- **Cápsula**: botão alongado de vidro.
- **Ícone**: controle circular compacto.
- **Slider**: trilho refrativo com indicador arrastável na horizontal.
- **Scroll**: trilho refrativo vertical com indicador arrastável; roda do mouse funciona no navegador.
- **Switch**: interruptor on/off com bolinha deslizante e animação spring.
- **Abas**: seletor segmentado de três áreas com indicador animado.
- **Chip**: botão com seleção alternável e animação de toque.
- **Card**: vidro retangular para testar bordas mais amplas.

## Ajustes

Além da intensidade, há 16 parâmetros: espessura, profundidade **positiva (convexa) ou negativa (côncava)**, direção da iluminação, altura da luz, reflexo, Fresnel, polimento, bloom, vazamento de luz, aberração cromática, desfoque, tonalidade, sombra, tamanho, elasticidade e velocidade. O shader usa quatro camadas possíveis para os componentes compostos; cada trilho e cada indicador têm refração separada.

Escolha Paisagem / Texto / Grade ou sua própria foto, arraste ou altere o componente e use **Comparar** para ver o fundo sem a lente. O estado individual fica no armazenamento local do aplicativo. Fotos próprias nunca são incluídas no arquivo exportado nem enviadas para a rede.

## Exportar preset

1. Selecione o componente (Bolha, Switch, Scroll, Abas etc.).
2. Modifique os sliders e, quando aplicável, teste a posição do indicador.
3. Toque em **Exportar preset**, no canto superior direito.
4. Nomeie e escolha **Salvar arquivo .TXT**. No Android o seletor de arquivos do sistema deixa escolher a pasta e confirma a gravação, **sem permissões de armazenamento**.
5. Envie o TXT para implementação no Horizon. Para restaurar um experimento, use **Importar preset já salvo**.

O TXT possui cabeçalho `GLASS_LAB_PRESET_V2` e JSON estruturado: `component`, `opticalParameters`, `animation`, `rendering.uniformValues`, `rendering.shaderRevision` e `glslFragmentSource` (shader GLSL ES 3.00 exato). Valores de coordenadas estão em CSS px com escalonamento por densidade de pixels; a implementação em Rust/WGSL precisa de adaptação, não é possível apenas colar o TXT no Horizon.

## Compilar

Projeto Android em `glass_lab_project/`: Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK 35, Java 17.

```shell
cd glass_lab_project
gradle :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk` — package `com.glasslab.optics`, `versionCode 2`, `versionName 2.0`. Instala como **atualização do Glass Lab 1.0 apenas se a assinatura Android for igual**; builds de debug compiladas em ambientes diferentes podem precisar de desinstalação prévia da versão antiga, o que apaga os presets armazenados localmente. Nesse caso, exporte os TXT antes de desinstalar.

## Privacidade e limitações

Nenhuma permissão de internet, nenhum acesso aos mods, contas, mundos ou arquivos do Horizon. Fotos e configurações ficam no próprio dispositivo. O app usa hardware acceleration em WebView e exige WebGL2. Não é uma medição física precisa da óptica de materiais reais; é um shader de interface com equações de Snell simplificadas e geometria SDF. A aparência precisa ser conferida em GPU Android.

## Glass Lab 2.1 — Legibilidade seletiva
- Mantidas geometria, controles e animações do 2.0. Nenhum indicador foi reposicionado.
- Trilha dos componentes deslizantes: acabamento escuro e opacidade ajustável por controle.
- Indicadores: acabamento acetinado opaco e opacidade independente da lente.
- Botões de vidro transparentes preservados; textos com contraste reforçado.
- TXT V2 permanece importável/exportável, com campos `indicatorOpacity` e `trackContrast`.
