# Glass Lab 1.0 — experimento independente (Android + navegador)

Um aplicativo **separado do Horizon** que testa refração de vidro em tempo real. É um laboratório óptico, não uma simulação com PNG ou uma alteração do Minecraft.

## Teste

1. Abra o APK `GlassLab-debug.apk` se disponível, ou `app/src/main/assets/index.html` em navegador Chrome/Edge/WebView que ofereça WebGL2.
2. Arraste a bolha por cima do texto, das nuvens e da paisagem. O texto *atrás* da bolha muda de posição e de cor conforme o ângulo da parede de vidro.
3. Mova a barra **Intensidade** de 0 a 100. Compare ativando **Ver sem vidro**.
4. Troque o fundo entre **Paisagem**, **Texto** e **Grade**, ou selecione sua própria foto do celular.
5. Toque em **Forma: bolha** para testar também uma cápsula. Abra **Controles avançados** para mudar espessura, aberração cromática, blur, reflexos e tamanho.

O shader WebGL2 processa textura do fundo **a cada quadro**, com deslocamento óptico baseado na curvatura de uma lente arredondada, refração vetorial (Snell simplificado), Fresnel, dispersão cromática, iluminação direcional e sombra de contato. A cena inicial é uma pintura procedural suave (não pixel art). Fotos escolhidas na galeria permanecem apenas na memória do dispositivo; não são enviadas a servidores.

## Compilação

Android Studio / terminal com SDK Android 35 e JDK 17:

```sh
gradle :app:assembleDebug
```

O APK será `app/build/outputs/apk/debug/app-debug.apk`. Em GitHub Actions, o workflow independente faz a compilação e anexa um artefato chamado `GlassLab-Android-APK`.

**Segurança e independência:** pacote Android `com.glasslab.optics`, sem permissão de internet, sem acesso às contas, mods ou dados do Horizon. `allowBackup=false`, aplicativo 100% offline.

## Crédito da paisagem

Cenário inicial procedural criado para este teste. Nenhuma imagem de terceiros é redistribuída no APK.
