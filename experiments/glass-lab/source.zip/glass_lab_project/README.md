# Glass Lab 4.0 — Retro Optics & Soft Scroll

Standalone Android WebView/WebGL2 optical material laboratory. NOT a Horizon modification.

## Changes
- Separate old-school shading model calculated on GPU each frame: Snell refracted scene, environment reflection, Fresnel-Schlick, microfaceted highlights, anisotropic grooves and dynamic press shading. Four optical materials: Graphite satin / PS3 pearl / clear Aero / brushed silver chrome.
- Frame-rate-independent damped harmonic oscillator for slider, scroll bar, switch and tabs; scrollbar remains visually overhanging as requested.
- Old-school controls get mechanically attenuated press response, soft focus glints and velocity-dependent highlights. Liquid Glass lens stays unchanged aside from smoothing the tracking response.
- Distinct per-style, per-component optical parameter persistence. Export `GLASS_LAB_PRESET_V4`, import V3+V4, plus migration from localStorage V2/V3.
- On GPU failure, status displays shader error rather than falsely claiming success.

## Android
`gradle :app:assembleDebug` (Android SDK 35; Java 17). Independent application ID `com.glasslab.optics`.

## Performance and accessibility
Keep lens opacity perceptual, minimal bloom; avoid fullscreen blur. `prefers-reduced-motion` honored for UI transitions; advanced controls have labels. Photo background never included in exported TXT.
