# Glass Lab 7.0 — Component Sound Library

- 10 controls in Liquid Glass and Old School, both retained and GPU-shaded.
- Eight expandable sound groups with 66 bundled Ogg Opus samples.
- Every component has exactly **one** selected file, independently per style.
- Tap a ▶ preview on any sample; selection uses a radio control. “Sem som” supported.
- One sound plays at gesture completion; no randomization, mixing or layers; prior playback stops.
- Particle visuals were removed at user request; chrome indicator rendering retained.
- Volume and mute shared per style. All material settings remain shared per style.
- TXT V7 and complete pack ZIP include independent component selections; prior V2–V6 TXT imports supported.
- App is separate from Horizon. Assets are offline and selected via Android system file picker.
- Preserved creator credits in CREDITS_SFX.md.
