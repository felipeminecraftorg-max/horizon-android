# Glass Lab 3.0 — Motion & Materials

**Standalone Android app.** This project does not modify, depend on, or request access to the Horizon launcher or any Minecraft data.

## Two separate visual systems

- **Liquid Glass:** optically refracting glass with Fresnel, directional highlights, and locally adaptive white/dark labels. Transparent control backgrounds, including the selected tab lens.
- **Old School:** independently stored grayscale presets, squared console-style buttons, satin silver/graphite material shader, small chamfers, and more mechanical animation responses. It is not Liquid Glass with a color filter.

Switch styles with the `Liquid Glass / Old School` button at the upper right. Each style stores independent values for every component. Settings are migrated from local `glasslab-v2-presets` to `glasslab-v3-presets` when possible.

## Physics-driven interaction prototypes

- **Bubble**: dragging causes directional viscoelastic lag at the *trailing edge*; release recovers through a damped second-order oscillator. There is no symmetric squish.
- **Square, pill, icon, card**: resting state is transparent in Liquid Glass; tap pushes the surface inward with a spring; dragging transitions to directional trailing deformation. Old School uses mechanical press with no gel tail.
- **Slider and scrollbar**: constrained 1D spring travel along the intended axis, rather than press animation. The scrollbar's intentionally overhanging indicator geometry is unchanged.
- **Switch**: a two-endpoint spring with separately tunable rebound; no generic press squash.
- **Tabs**: selected lens glides along the rail. Liquid Glass selection remains transparent and adds a small visible underline instead of an opaque colored capsule.
- **Chip**: pressing has inward depth feedback; selection toggles on release.

The physical interactions are analytical spring-damper models for GUI feedback, not a full deformable-body fluid solver. Parameters are tunable. Shader lag and depth are transmitted in a per-part `uDynamics[4]` array. The model is accelerated using WebGL2 and runs offline.

## Visual readability

- Larger icons and text proportional to component geometry; more readable controls and labels.
- Minimal shadowing; text ink adapts to local source-image luminance.
- Selective satin white translucent control thumbs; transparent tabs and glass buttons.
- Neutral black/graphite/silver Old School colors. No forced saturated blue material.
- Selector, scrollbar and track geometry remains as approved in 2.1.

## Presets and compatibility

Export `GLASS_LAB_PRESET_V3` as TXT, containing `style.id`, component kind, independent optical values, animation parameters, physical coefficients, and GLSL source. Import accepts both legacy `GLASS_LAB_PRESET_V2` (as Liquid Glass) and V3. Android's system document picker handles the actual save; photos aren't exported or uploaded.

## Compile

Java 17, Android SDK 35, Gradle 8.9 (Google Maven via CI). Use `gradle :app:assembleDebug`. The Debug APK has unique package `com.glasslab.optics`, `versionCode 4` and `versionName 3.0`, independent of Horizon.

The GitHub workflow validates JavaScript, GLSL ES 3.00 and APK compilation. Visual performance and shader behavior still require an Android test, as computer/browser automation in the authoring environment cannot use hardware WebGL2.
